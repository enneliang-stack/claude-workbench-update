'use strict';

(() => {
  const $ = (sel, root = document) => root.querySelector(sel);
  const TOKEN = window.__GUI_TOKEN__;

  // ------------------------------------------------------------ 状态

  const S = {
    folders: [],
    settings: {
      defaultPermissionMode: 'bypassPermissions', defaultModel: '', defaultModelChoice: '',
      defaultEffort: '', envEffort: '', effortLevels: []
    },
    app: {},
    conv: null,
    currentFolder: null,
    running: false,
    runningIds: new Set(),
    currentRun: null,
    collapsed: new Set(JSON.parse(localStorage.getItem('collapsedFolders') || '[]')),
    search: '',
    stick: true,
    // 重绘会话时浏览器会因清空/重建内容触发 scroll 事件，短时间内不要把它当成用户上滑
    scrollGuardUntil: 0,
    loadSeq: 0,
    pendingPerm: null,
    menuEl: null,
    pendingImages: [],
    imageSeq: 0,
    pendingFiles: [],
    fileSeq: 0,
    // 待发送的文字引用：只带选中的原文和出处，不读取来源对话的其它内容
    pendingQuotes: [],
    quoteSeq: 0,
    contextTokens: 0,
    // 上下文提醒/轮内保护
    ctxEpoch: 0,                 // 当前会话压缩次数（至少用于区分第一次/第二次到 850K）
    guardWarned: false,          // 900K 轮内警告是否已弹过
    guardStopRequested: false,   // 是否已请求停止当前轮
    guardStopConvId: null,       // 请求停止的会话 id
    guardAutoResumeCount: 0,     // 连续自动续跑次数（最多 2 次）
    guardAutoResuming: false,    // 当前 send 是否是自动续跑
    ctxPreview: false,           // 提醒按钮预览模式（Ctrl+Alt+H）
    ctxPreviewTimer: 0,
    switchBuf: null,
    askIds: new Set(),
    pendingAsk: null,
    attention: new Set(),
    attentionInfo: new Map(),
    // 1.1.0 新增
    pendingRefs: [],
    // 时间分隔条：上一条用户消息的时间/日期，用来判断是否属于同一段连续聊天
    chatTime: { lastUserTs: 0, lastDay: '' },
    compacting: false,
    compactConvId: null,
    compactWaiter: null,
    compactPostTokens: 0,
    manualCompact: false,
    manualCompactConvId: null,
    cliCompacting: false,
    cliCompactConvId: null,
    appVersion: '',
    updateInfo: null,
    updateBusy: false,
    refSel: new Map(),
    refSearch: '',
    // 每个对话独立的输入草稿（文字 / 待发图片 / 引用），切换对话时不串台
    drafts: new Map(),
    // 侧栏预览：任务完成后用助手结论覆盖掉用户提问，并持久化到本机
    previewOverrides: new Map(),
    extData: null,
    extTab: 'skills',
    plugins: null,
    pluginLoading: false,
    pluginSearch: '',
    pluginShowAll: false,
    pluginBusy: ''
  };

  try {
    const savedPreviews = JSON.parse(localStorage.getItem('convPreviews') || '{}');
    if (savedPreviews && typeof savedPreviews === 'object' && !Array.isArray(savedPreviews)) {
      S.previewOverrides = new Map(Object.entries(savedPreviews));
    }
  } catch { /* 缓存损坏时忽略 */ }

  const messagesEl = $('#messages');
  const transcriptEl = $('#transcript');
  // 自动跟随必须是瞬时的：smooth 滚动会和用户向上滚动手势打架，
  // 运行中连续输出时甚至会把页面一直粘在底部。
  transcriptEl.style.scrollBehavior = 'auto';
  // 关掉滚动锚定：自动进度行插入/移除时浏览器会改 scrollTop，看起来像用户上滚，
  // 之前会导致出现「自动」进度后整页不再跟随到底部。
  transcriptEl.style.overflowAnchor = 'none';
  const inputEl = $('#input');
  const sendBtn = $('#sendBtn');
  const stopBtn = $('#stopBtn');
  const attachStrip = $('#attachStrip');

  // 上下文到 90 万 token 左右时自动压缩。
  // deepseek-flash[1m] 的硬上限是 1,048,576，且还要给 32k 输出预留空间。
  const AUTO_COMPACT_AT = 900000;
  // 已经压缩过一次、再次到 85 万时，提醒开新对话（只提示，不强制）
  const CTX_REMIND_AT = 850000;
  // 30 万时给一次成本提醒：上下文只增不减，后续调用会反复重读
  const CTX_COST_HINT_AT = 300000;
  // 轮内兜底：单个 turn 内 CLI 来不及压缩时，客户端在 93 万停止本轮并压缩
  const CTX_GUARD_WARN = 900000;
  const CTX_GUARD_STOP = 930000;
  // 轮内兜底压缩完成后自动续跑；连续自动续跑最多 2 次，之后交回用户确认
  const AUTO_CONTINUE_PROMPT = '继续刚才的任务。上一个回合因为上下文接近 1M 被中止，并已自动压缩；请从中断处继续，不要重复已经完成的内容。';

  // 850K 提醒按钮：index.html 可能被只读 ACL 锁住，统一由 app.js 注入 DOM 和样式
  ensureCtxHintDom();

  // ref-digest.js 由本脚本动态加载（index.html 可能被只读 ACL 锁住，不能直接加 script 标签）
  const digestReady = (() => {
    if (window.ClaudeRefDigest) return Promise.resolve(window.ClaudeRefDigest);
    return new Promise(resolve => {
      const s = document.createElement('script');
      s.src = '/ref-digest.js';
      s.onload = () => resolve(window.ClaudeRefDigest || null);
      s.onerror = () => resolve(null);
      document.head.appendChild(s);
    });
  })();

  // ------------------------------------------------------------ 工具函数

  const escapeHtml = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));

  function timeAgo(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    const diff = Date.now() - d.getTime();
    if (diff < 60e3) return '刚刚';
    if (diff < 3600e3) return Math.floor(diff / 60e3) + ' 分钟前';
    if (diff < 86400e3) return Math.floor(diff / 3600e3) + ' 小时前';
    if (diff < 7 * 86400e3) return Math.floor(diff / 86400e3) + ' 天前';
    return `${d.getMonth() + 1}-${String(d.getDate()).padStart(2, '0')}`;
  }

  function toast(msg, type) {
    const t = document.createElement('div');
    t.className = 'toast' + (type === 'error' ? ' error' : '');
    t.textContent = msg;
    $('#toasts').appendChild(t);
    setTimeout(() => {
      t.style.transition = 'opacity .2s';
      t.style.opacity = '0';
      setTimeout(() => t.remove(), 220);
    }, type === 'error' ? 4200 : 2200);
  }

  function setStatus(text, kind) {
    const line = $('#statusLine');
    line.className = 'status-line' + (kind ? ' ' + kind : '');
    $('#appStatus').textContent = text;
  }

  // 告诉桌面客户端是否有任务在跑，供托盘退出时确认
  function notifyDesktopBusy() {
    try { window.guiDesktop?.setBusy?.(S.runningIds.size > 0); } catch { /* ignore */ }
  }

  // ------------------------------------------------------------ 提醒 / 角标
  // 每个“有未读内容”的对话算 1：待回答问题、待确认权限、任务完成/出错。
  // 主进程据此设置任务栏叠加图标的数字和托盘图标角标，并在窗口不在前台时弹通知。

  let lastAttentionCount = -1;
  let lastAttentionSummary = '';

  function isWindowActive() {
    return !document.hidden && document.hasFocus();
  }

  function convTitleOf(id) {
    const all = S.folders.flatMap(f => f.conversations || []);
    const c = all.find(x => x.id === id);
    return (c && c.title) || (S.conv && S.conv.id === id && S.conv.title) || '对话';
  }

  function refreshAttention() {
    const count = S.attention.size;
    const summary = [...S.attentionInfo.values()]
      .filter(Boolean)
      .slice(0, 3)
      .join(' / ');
    renderFolders();
    if (count === lastAttentionCount && summary === lastAttentionSummary) return;
    lastAttentionCount = count;
    lastAttentionSummary = summary;
    // 便于排查角标状态（不影响界面）
    document.documentElement.dataset.attention = String(count);
    document.documentElement.dataset.attentionSummary = summary;
    try { window.guiDesktop?.setAttention?.(count, summary); } catch { /* ignore */ }
  }

  function attentionAdd(id, text) {
    if (!id) return;
    S.attention.add(id);
    if (text) S.attentionInfo.set(id, text);
    refreshAttention();
  }

  /** 页面加载/重新连接后，从 bootstrap 的 waiting 标记恢复角标 */
  function primeAttentionFromFolders() {
    const all = S.folders.flatMap(f => f.conversations || []);
    let changed = false;
    for (const c of all) {
      if (!c.waiting) continue;
      if (isWindowActive() && S.conv && S.conv.id === c.id) continue;
      if (!S.attention.has(c.id)) { S.attention.add(c.id); changed = true; }
      if (!S.attentionInfo.has(c.id)) {
        S.attentionInfo.set(c.id, c.asking ? '等你回答问题' : '等你确认操作');
      }
    }
    if (changed) refreshAttention();
  }

  function attentionRemove(id) {
    if (!id) return;
    const changed = S.attention.delete(id);
    S.attentionInfo.delete(id);
    if (changed) refreshAttention();
  }

  function clearCurrentAttention() {
    if (S.conv && isWindowActive()) attentionRemove(S.conv.id);
  }

  function notifyDesktop(title, body, convId) {
    try {
      window.guiDesktop?.notify?.({
        title,
        body: String(body || '').slice(0, 280),
        convId: convId || ''
      });
    } catch { /* ignore */ }
  }

  async function api(path, opts = {}) {
    const res = await fetch('/api' + path, {
      ...opts,
      headers: {
        'content-type': 'application/json',
        'x-gui-token': TOKEN,
        ...(opts.headers || {})
      }
    });
    let data = null;
    try { data = await res.json(); } catch { /* ignore */ }
    if (!res.ok) throw new Error((data && data.error) || `请求失败 (${res.status})`);
    return data;
  }

  // ------------------------------------------------------------ 图标

  const ICON = {
    chev: '<svg class="chev" viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg>',
    folder: '<svg class="ficon" viewBox="0 0 24 24"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
    plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
    dots: '<svg viewBox="0 0 24 24"><circle cx="5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="19" cy="12" r="1.2"/></svg>',
    trash: '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13"/></svg>',
    pencil: '<svg viewBox="0 0 24 24"><path d="M4 20h4L20 8l-4-4L4 16z"/></svg>',
    external: '<svg viewBox="0 0 24 24"><path d="M14 4h6v6"/><path d="M20 4l-8.5 8.5"/><path d="M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4"/></svg>',
    terminal: '<svg viewBox="0 0 24 24"><path d="M5 7l5 5-5 5"/><path d="M12 17h7"/></svg>',
    file: '<svg viewBox="0 0 24 24"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>',
    search: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4 4"/></svg>',
    globe: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3.5 3.6 3.5 14.4 0 18M12 3c-3.5 3.6-3.5 14.4 0 18"/></svg>',
    task: '<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><path d="M16 4a3 3 0 0 1 0 6"/><path d="M18 14c2.2.8 3 2.6 3 4"/></svg>',
    gear: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1"/></svg>',
    spark: '<svg class="spark" viewBox="0 0 24 24"><path d="M12 3l2.2 5.6L20 10l-5.8 1.4L12 17l-2.2-5.6L4 10l5.8-1.4z"/></svg>'
  };

  function toolIcon(name) {
    const n = String(name || '').toLowerCase();
    if (/bash|shell|powershell|terminal/.test(n)) return ICON.terminal;
    if (/read|write|edit|notebook|file/.test(n)) return ICON.file;
    if (/glob|grep|search|ls/.test(n)) return ICON.search;
    if (/webfetch|websearch|fetch|http/.test(n)) return ICON.globe;
    if (/task|agent/.test(n)) return ICON.task;
    return ICON.gear;
  }

  // ------------------------------------------------------------ Markdown

  function inline(s) {
    let t = s;
    t = t.replace(/`([^`\n]+)`/g, (_, c) => `<code>${c}</code>`);
    t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    t = t.replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>');
    t = t.replace(/~~([^~]+)~~/g, '<del>$1</del>');
    t = t.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    return t;
  }

  function renderCode(lang, code) {
    return `<div class="code-block"><div class="code-head"><span>${escapeHtml(lang || 'text')}</span><button class="copy" data-copy>复制</button></div><pre><code>${escapeHtml(code)}</code></pre></div>`;
  }

  const isBlockStart = line =>
    /^\s*```/.test(line) ||
    /^#{1,6}\s+/.test(line) ||
    /^\s*>\s?/.test(line) ||
    /^\s*([-*+]|\d+\.)\s+/.test(line) ||
    /^\s*([-*_])\s*\1\s*\1[\s-*_]*$/.test(line);

  function buildList(items) {
    let html = '';
    const stack = [];
    for (const it of items) {
      while (stack.length && it.indent < stack[stack.length - 1].indent) {
        const s = stack.pop();
        html += `</li></${s.ordered ? 'ol' : 'ul'}>`;
      }
      if (!stack.length || it.indent > stack[stack.length - 1].indent) {
        const tag = it.ordered ? 'ol' : 'ul';
        html += `<${tag}>`;
        stack.push({ ordered: it.ordered, indent: it.indent });
      } else {
        html += '</li>';
      }
      html += `<li>${inline(escapeHtml(it.text))}`;
    }
    while (stack.length) {
      const s = stack.pop();
      html += `</li></${s.ordered ? 'ol' : 'ul'}>`;
    }
    return html;
  }

  function renderList(lines, start) {
    const items = [];
    let i = start;
    while (i < lines.length) {
      const line = lines[i];
      const m = line.match(/^(\s*)([-*+]|\d+\.)\s+(.*)$/);
      if (m) {
        items.push({
          indent: m[1].replace(/\t/g, '  ').length,
          ordered: /\d/.test(m[2]),
          text: m[3]
        });
        i++;
      } else if (line.trim() && /^\s{2,}\S/.test(line) && items.length) {
        items[items.length - 1].text += ' ' + line.trim();
        i++;
      } else break;
    }
    return { html: buildList(items), next: i };
  }

  function splitRow(line) {
    let s = line.trim();
    if (s.startsWith('|')) s = s.slice(1);
    if (s.endsWith('|')) s = s.slice(0, -1);
    return s.split('|').map(c => c.trim());
  }

  function md(src) {
    const lines = String(src || '').replace(/\r\n/g, '\n').split('\n');
    let out = '';
    let i = 0;

    while (i < lines.length) {
      const line = lines[i];

      const fence = line.match(/^\s*```([\w+#.-]*)\s*$/);
      if (fence) {
        const lang = fence[1] || '';
        const buf = [];
        i++;
        while (i < lines.length && !/^\s*```\s*$/.test(lines[i])) { buf.push(lines[i]); i++; }
        i++;
        out += renderCode(lang, buf.join('\n'));
        continue;
      }

      if (!line.trim()) { i++; continue; }

      const h = line.match(/^(#{1,6})\s+(.*)$/);
      if (h) {
        const lvl = Math.min(h[1].length, 4);
        out += `<h${lvl}>${inline(escapeHtml(h[2]))}</h${lvl}>`;
        i++;
        continue;
      }

      if (/^\s*([-*_])\s*\1\s*\1[\s-*_]*$/.test(line)) {
        out += '<hr>';
        i++;
        continue;
      }

      if (/^\s*>\s?/.test(line)) {
        const buf = [];
        while (i < lines.length && /^\s*>\s?/.test(lines[i])) {
          buf.push(lines[i].replace(/^\s*>\s?/, ''));
          i++;
        }
        out += `<blockquote>${md(buf.join('\n'))}</blockquote>`;
        continue;
      }

      if (line.includes('|') && i + 1 < lines.length && /^\s*\|?[\s:|-]*-[-\s:|]*$/.test(lines[i + 1])) {
        const head = splitRow(line);
        const aligns = splitRow(lines[i + 1]).map(c =>
          c.startsWith(':') && c.endsWith(':') ? 'center' : c.endsWith(':') ? 'right' : 'left');
        i += 2;
        const rows = [];
        while (i < lines.length && lines[i].includes('|') && lines[i].trim()) {
          rows.push(splitRow(lines[i]));
          i++;
        }
        out += '<table><thead><tr>' +
          head.map((c, k) => `<th style="text-align:${aligns[k] || 'left'}">${inline(escapeHtml(c))}</th>`).join('') +
          '</tr></thead><tbody>' +
          rows.map(r => '<tr>' + head.map((_, k) => `<td>${inline(escapeHtml(r[k] || ''))}</td>`).join('') + '</tr>').join('') +
          '</tbody></table>';
        continue;
      }

      if (/^\s*([-*+]|\d+\.)\s+/.test(line)) {
        const { html, next } = renderList(lines, i);
        out += html;
        i = next;
        continue;
      }

      const buf = [];
      while (i < lines.length && lines[i].trim() && !isBlockStart(lines[i])) {
        if (lines[i].includes('|') && i + 1 < lines.length && /^\s*\|?[\s:|-]*-[-\s:|]*$/.test(lines[i + 1])) break;
        buf.push(lines[i]);
        i++;
      }
      if (!buf.length) { i++; continue; }
      out += `<p>${buf.map(l => inline(escapeHtml(l))).join('<br>')}</p>`;
    }

    return out;
  }

  // ------------------------------------------------------------ 消息渲染

  function createAssistantEl() {
    const row = document.createElement('div');
    row.className = 'msg assistant';
    row.innerHTML = '<div class="avatar">✳</div><div class="body"></div>';
    messagesEl.appendChild(row);
    return { row, body: row.querySelector('.body') };
  }

  function clearEmpty() {
    const empty = messagesEl.querySelector('.empty');
    if (empty) empty.remove();
  }

  function imageDataUrl(img) {
    return img.url || `data:${img.media_type};base64,${img.data}`;
  }

  // ------------------------------------------------------------ 消息时间分隔条

  function pad2(n) { return String(n).padStart(2, '0'); }

  function dayKeyOf(d) {
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
  }

  function chatTimeLabel(d) {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const that = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
    const diff = Math.round((today - that) / 86400000);
    const hm = pad2(d.getHours()) + ':' + pad2(d.getMinutes());
    const wd = d.getDay();
    const wdFull = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'][wd];
    const wdShort = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][wd];
    if (diff <= 0) return '今天 ' + hm;
    if (diff === 1) return '昨天 ' + hm;
    if (diff < 7) return wdFull + ' ' + hm;
    return (d.getMonth() + 1) + '月' + d.getDate() + '日 ' + wdShort + ' ' + hm;
  }

  function resetChatTime() {
    S.chatTime = { lastUserTs: 0, lastDay: '' };
  }

  /** 插话也要算进“连续聊天”，但不单独显示时间 */
  function noteChatActivityTime(ts) {
    const d = new Date(ts);
    if (!isFinite(d.getTime())) return;
    S.chatTime.lastUserTs = d.getTime();
    S.chatTime.lastDay = dayKeyOf(d);
  }

  /** 在用户消息前插入时间条；同一段连续聊天只插在第一条前面 */
  function maybeAddChatTime(ts) {
    const d = new Date(ts);
    if (!isFinite(d.getTime())) return;
    const day = dayKeyOf(d);
    const t = d.getTime();
    const last = S.chatTime;
    if (!last.lastUserTs || t - last.lastUserTs > CHAT_TIME_GAP || day !== last.lastDay) {
      const el = document.createElement('div');
      el.className = 'time-divider';
      el.textContent = chatTimeLabel(d);
      messagesEl.appendChild(el);
    }
    last.lastUserTs = t;
    last.lastDay = day;
  }

  // 长消息（例如一整段 App 日志）默认收起，避免一条消息占满整屏。
  const LONG_USER_TEXT_CHARS = 1200;
  const LONG_USER_TEXT_LINES = 16;

  /** 引用小框只显示前 5 个字，悬停时用浮框展示全文 */
  function quotePreview(text) {
    const s = String(text || '').replace(/\s+/g, ' ').trim();
    const chars = Array.from(s);
    return chars.slice(0, 5).join('') + (chars.length > 5 ? '…' : '');
  }

  function quoteRoleLabel(role) {
    if (role === 'user') return '我的消息';
    if (role === 'assistant') return 'Claude 回复';
    return '';
  }

  function quoteSourceLabel(q) {
    const src = String((q && q.source) || '').trim();
    const role = quoteRoleLabel(q && q.role);
    return '引自「' + (src || '未知对话') + '」' + (role ? ' · ' + role : '');
  }

  /** 去掉消息里的结构化引用块，并解析出引用内容 */
  function splitQuoteBlocks(text) {
    const src = String(text || '');
    const re = /<gui-quote>\s*\r?\n([^\n]*)\r?\n([\s\S]*?)<\/gui-quote>/g;
    const quotes = [];
    let out = '';
    let last = 0;
    let m;
    while ((m = re.exec(src))) {
      out += src.slice(last, m.index);
      let meta = {};
      try { meta = JSON.parse(m[1]) || {}; } catch { meta = {}; }
      const t = m[2].replace(/\r\n?/g, '\n').trim();
      if (t) {
        quotes.push({
          text: t,
          source: String(meta.source || ''),
          sourceId: String(meta.conv || ''),
          role: String(meta.role || '')
        });
      }
      last = re.lastIndex;
    }
    out += src.slice(last);
    return { text: out.trim(), quotes };
  }

  function buildBubbleQuote(q) {
    const box = document.createElement('div');
    box.className = 'bubble-quote';
    const text = document.createElement('div');
    text.className = 'bubble-quote-text';
    text.textContent = quotePreview(q.text);
    const src = document.createElement('div');
    src.className = 'bubble-quote-src';
    src.textContent = quoteSourceLabel(q);
    box.append(text, src);
    box.addEventListener('mouseenter', () => showQuoteTip(box, q));
    box.addEventListener('mouseleave', hideQuoteTip);
    return box;
  }

  function createUserBubble(text, images, opts = {}) {
    const bubble = document.createElement('div');
    bubble.className = 'bubble';

    if (opts.steer) {
      bubble.classList.add('steer');
      const tag = document.createElement('div');
      tag.className = 'steer-tag';
      tag.textContent = '插话';
      bubble.appendChild(tag);
    }

    if (images && images.length) {
      bubble.classList.add('has-images');
      const strip = document.createElement('div');
      strip.className = 'bubble-images';
      images.forEach((img, i) => {
        const wrap = document.createElement('div');
        wrap.className = 'bubble-image';
        const el = document.createElement('img');
        el.src = imageDataUrl(img);
        el.alt = `第 ${i + 1} 张图片`;
        el.loading = 'lazy';
        el.decoding = 'async';
        const num = document.createElement('span');
        num.className = 'img-num';
        num.textContent = i + 1;
        wrap.append(el, num);
        strip.appendChild(wrap);
      });
      bubble.appendChild(strip);
    }

    const digest = window.ClaudeRefDigest;
    const hadRefs = !!(digest && digest.hasBlock && digest.hasBlock(text));
    const displayText = digest && digest.stripBlock ? digest.stripBlock(text) : text;
    if (hadRefs) {
      const tag = document.createElement('div');
      tag.className = 'bubble-ref';
      tag.textContent = '引用对话 · 已按问题筛选';
      bubble.appendChild(tag);
    }
    // 结构化引用块换成小引用框，正文只保留用户自己打的字
    const parsed = splitQuoteBlocks(displayText);
    for (const q of parsed.quotes) bubble.appendChild(buildBubbleQuote(q));
    const bodyText = parsed.text;
    if (bodyText) {
      const t = document.createElement('div');
      t.className = 'bubble-text';
      t.textContent = bodyText;
      const longText = bodyText.length > LONG_USER_TEXT_CHARS ||
        bodyText.split('\n').length > LONG_USER_TEXT_LINES;
      if (longText) {
        t.classList.add('collapsed');
        const toggle = document.createElement('button');
        toggle.type = 'button';
        toggle.className = 'bubble-expand';
        const label = `展开全部 · ${bodyText.length.toLocaleString('zh-CN')} 字`;
        toggle.textContent = label;
        toggle.addEventListener('click', () => {
          const collapsed = t.classList.toggle('collapsed');
          toggle.textContent = collapsed ? label : '收起';
          if (S.stick) scrollToBottom();
        });
        bubble.appendChild(t);
        bubble.appendChild(toggle);
      } else {
        bubble.appendChild(t);
      }
    }
    return bubble;
  }

  function addUserBubble(text, images, opts = {}) {
    clearEmpty();
    const row = document.createElement('div');
    row.className = 'msg user';
    row.appendChild(createUserBubble(text, images, opts));
    messagesEl.appendChild(row);
  }

  function isCompactSummaryMessage(msg) {
    if (!msg) return false;
    const text = String(msg.text || '');
    // 只有完整、独立成行的引用块才算引用；摘要正文里可能只是提到这个标签，
    // 不能因此把真正的压缩摘要当成引用消息显示。
    const refBlock = /(?:^|\n)<gui-reference-context>[ \t]*\r?\n[\s\S]*?\r?\n<\/gui-reference-context>[ \t]*(?=\r?\n|$)/i;
    if (refBlock.test(text)) return false;
    if (msg.compactSummary || msg.isCompactSummary) return true;
    return /^\s*(?:This session is being continued|The summary below covers)/i.test(text);
  }

  /** 压缩摘要在对话里只留一条分隔提示，不把整段总结当用户消息显示 */
  function addCompactDivider() {
    const last = messagesEl.lastElementChild;
    if (last && last.classList.contains('compact-divider')) return;
    const el = document.createElement('div');
    el.className = 'compact-divider';
    el.textContent = '上下文对话已压缩';
    messagesEl.appendChild(el);
    if (S.stick) scrollToBottom(true);
  }

  function makeSteerWrap(text, images) {
    const wrap = document.createElement('div');
    wrap.className = 'steer-inline';
    wrap.appendChild(createUserBubble(text, images, { steer: true }));
    return wrap;
  }

  /** 运行中插话：留在当前阶段性消息之间；收尾时再决定收起/展开时的位置 */
  function addInlineSteer(run, text, images) {
    const wrap = makeSteerWrap(text, images);
    run.body.insertBefore(wrap, run.progress && run.progress.parentNode === run.body ? run.progress : null);
    if (run.order) run.order.push({ type: 'steer', el: wrap });
    if (S.stick) scrollToBottom();
  }

  function toolSummary(name, input) {
    if (!input || typeof input !== 'object') return '';
    const pick = input.command || input.file_path || input.path || input.pattern ||
      input.url || input.query || input.description || input.prompt;
    if (typeof pick === 'string') return pick;
    try {
      const s = JSON.stringify(input);
      return s.length > 110 ? s.slice(0, 110) + '…' : s;
    } catch { return ''; }
  }

  function makeToolBlock(block) {
    const wrap = document.createElement('div');
    wrap.className = 'block tool';
    wrap.innerHTML = `
      <button class="tool-head">
        ${ICON.chev}
        <span class="tool-icon">${toolIcon(block.name)}</span>
        <span class="tool-name"></span>
        <span class="tool-summary"></span>
        <span class="tool-status"></span>
      </button>
      <div class="tool-body" hidden>
        <div class="sec-input">
          <div class="tool-label">参数</div>
          <pre class="tool-pre"></pre>
        </div>
        <div class="sec-result" hidden>
          <div class="tool-label">结果</div>
          <pre class="tool-pre"></pre>
        </div>
      </div>`;

    const head = wrap.querySelector('.tool-head');
    const body = wrap.querySelector('.tool-body');
    head.addEventListener('click', () => {
      wrap.classList.toggle('open');
      body.hidden = !wrap.classList.contains('open');
    });

    return {
      type: 'tool_use',
      key: 'tool:' + block.id,
      el: wrap,
      nameEl: wrap.querySelector('.tool-name'),
      summaryEl: wrap.querySelector('.tool-summary'),
      statusEl: wrap.querySelector('.tool-status'),
      inputEl: wrap.querySelector('.sec-input .tool-pre'),
      resultSec: wrap.querySelector('.sec-result'),
      resultEl: wrap.querySelector('.sec-result .tool-pre'),
      data: { name: block.name, input: block.input }
    };
  }

  function updateToolBlock(b, block) {
    if (block.name) {
      b.nameEl.textContent = block.name;
      b.el.querySelector('.tool-icon').innerHTML = toolIcon(block.name);
      b.data.name = block.name;
    }
    if (block.input !== undefined && block.input !== null) {
      b.data.input = block.input;
      b.summaryEl.textContent = toolSummary(block.name || b.data.name, block.input);
      let pretty = '';
      try { pretty = JSON.stringify(block.input, null, 2); } catch { pretty = String(block.input); }
      if (pretty && pretty !== '{}') b.inputEl.textContent = pretty;
      else b.el.querySelector('.sec-input').hidden = true;
    }
    updateProgressForBlock(b);
  }

  function setToolResult(b, content, isError) {
    b.resultSec.hidden = false;
    b.resultEl.textContent = content || '（无输出）';
    b.resultSec.classList.toggle('err', !!isError);
    b.statusEl.className = 'tool-status ' + (isError ? 'err' : 'ok');
    b.statusEl.textContent = isError ? '失败' : '';
    if (isError) {
      b.el.classList.add('open');
      b.el.querySelector('.tool-body').hidden = false;
    }
    if (isLiveBlock(b)) {
      const name = (b.data && b.data.name) || '工具';
      setRunProgress(S.currentRun, (isError ? '工具失败：' : '已完成 ') + name + '，等待下一步…',
        isError ? 'wait' : 'tool');
    }
  }

  function makeThinkingBlock(key) {
    const d = document.createElement('details');
    d.className = 'block thinking live';
    // 「过程」默认收起；思考块本身也只露一行摘要，手动展开时不会刷屏
    d.open = false;
    d.innerHTML = `
      <summary>${ICON.chev}${ICON.spark}<span>思考</span><span class="cnt">0 字</span></summary>
      <div class="think-body"></div>`;
    d.querySelector('summary').addEventListener('click', () => {
      const b = d._blk;
      if (b) b.userToggled = true;
    });
    return { type: 'thinking', key, el: d, body: d.querySelector('.think-body'), cnt: d.querySelector('.cnt'), text: '' };
  }

  function makeTextBlock(key) {
    const wrap = document.createElement('div');
    wrap.className = 'block text-block';
    wrap.innerHTML = '<div class="md"></div>';
    return { type: 'text', key, el: wrap, md: wrap.querySelector('.md'), text: '' };
  }

  // ------------------------------------------------------------ 过程折叠

  function buildActivityEl(open) {
    const d = document.createElement('details');
    d.className = 'block activity live';
    d.open = !!open;
    d.innerHTML = `
      <summary>${ICON.chev}${ICON.spark}<span class="act-title">过程</span><span class="act-count"></span><span class="act-files"></span><span class="act-meta"></span><span class="act-state"><span class="spin"></span></span></summary>
      <div class="activity-body"></div>`;
    const act = {
      el: d,
      body: d.querySelector('.activity-body'),
      cnt: d.querySelector('.act-count'),
      files: d.querySelector('.act-files'),
      meta: d.querySelector('.act-meta'),
      state: d.querySelector('.act-state'),
      userToggled: false
    };
    // 用户手动展开/收起后，运行中不再自动折叠
    d.querySelector('summary').addEventListener('click', () => { act.userToggled = true; });
    d.addEventListener('toggle', scheduleProcessCollapseUpdate);
    return act;
  }

  // ------------------------------------------------------------ deepseek-flash 计价与上下文

  // DeepSeek-V4.1-Flash 官方人民币价（元 / 百万 token）
  const DS_PRICES = {
    offpeak: { hit: 0.02, miss: 1, out: 4 },
    peak: { hit: 0.04, miss: 2, out: 8 }
  };
  const CONTEXT_LIMIT = 1048576;   // deepseek-flash[1m]

  /** 高峰时段：北京时间周一至周五 9:00-12:00、14:00-18:00（= UTC 01-04、06-10） */
  function isPeakTime(ts) {
    const d = ts ? new Date(ts) : new Date();
    if (isNaN(d.getTime())) return false;
    const day = d.getUTCDay();
    if (day === 0 || day === 6) return false;
    const mins = d.getUTCHours() * 60 + d.getUTCMinutes();
    return (mins >= 60 && mins < 240) || (mins >= 360 && mins < 600);
  }

  /** 按 deepseek-flash 官方价估算本轮费用（元） */
  function estimateCny(usage, ts) {
    if (!usage) return null;
    const hit = usage.cache_read_input_tokens || 0;
    const miss = (usage.input_tokens || 0) + (usage.cache_creation_input_tokens || 0);
    const out = usage.output_tokens || 0;
    if (!hit && !miss && !out) return null;
    const peak = isPeakTime(ts);
    const p = peak ? DS_PRICES.peak : DS_PRICES.offpeak;
    const cny = (hit * p.hit + miss * p.miss + out * p.out) / 1e6;
    return { cny, peak, hit, miss, out };
  }

  function fmtCny(n) {
    return n < 0.01 ? `¥${n.toFixed(3)}` : `¥${n.toFixed(2)}`;
  }

  function fmtDuration(ms) {
    if (typeof ms !== 'number' || !isFinite(ms) || ms < 0) return '';
    if (ms < 1000) return `${Math.round(ms)}ms`;
    const s = ms / 1000;
    if (s < 60) return `${s.toFixed(1)}s`;
    const m = Math.floor(s / 60);
    const rest = Math.round(s - m * 60);
    return `${m}m${rest ? ' ' + rest + 's' : ''}`;
  }

  /**
   * 把 { duration, usage, ts } 变成摘要文案和 tooltip
   * - meta.usage：本块自身的用量，用时和命中率按它算
   * - meta.totals：显示 tokens 和价钱时用的用量（整轮累计），不传就用 meta.usage
   * - meta.hideTokensCost：只显示用时和命中率（压缩前那一块）
   */
  function turnMetaInfo(meta) {
    if (!meta) return null;
    const bits = [];
    const detail = [];

    const dur = fmtDuration(meta.duration);
    if (dur) bits.push(`用时 ${dur}`);

    const u = meta.usage;
    const t = meta.totals || u;

    // 摘要里已经有命中率和费用；tooltip 只补充 token 拆分、有效新增和计价口径，避免重复。
    if (!meta.hideTokensCost && t) {
      const hitTok = t.cache_read_input_tokens || 0;
      const missTok = (t.input_tokens || 0) + (t.cache_creation_input_tokens || 0);
      const outTok = t.output_tokens || 0;
      const totalIn = hitTok + missTok;
      if (totalIn || outTok) {
        bits.push(`${fmtTok(totalIn + outTok)} tokens`);
        detail.push(`输入 ${fmtTok(totalIn)}（缓存命中 ${fmtTok(hitTok)} / 未命中 ${fmtTok(missTok)}）/ 输出 ${fmtTok(outTok)} tokens`);
        const newTok = missTok + outTok;
        const replay = newTok > 0 ? Math.round((totalIn + outTok) / newTok) : 0;
        if (replay > 1) {
          detail.push(`有效新增 ${fmtTok(newTok)} · 平均重放 ${replay}×（同一段上下文被后续调用反复读取）`);
        }
      }
    }

    if (u) {
      const hitTok = u.cache_read_input_tokens || 0;
      const missTok = (u.input_tokens || 0) + (u.cache_creation_input_tokens || 0);
      const totalIn = hitTok + missTok;
      if (totalIn > 0) {
        const pct = hitTok / totalIn * 100;
        // 以前四舍五入到整数，99.6% 会显示成 100%。现在保留一位小数，且非精确 100%
        // 向下取到 99.9，避免 99.96% 又被显示成 100.0%；精确 100 才显示 100.0。
        const rate = pct >= 100 ? '100.0'
          : pct > 0 && pct < 0.05 ? '<0.1'
            : (Math.floor(pct * 10) / 10).toFixed(1);
        bits.push(`命中率 ${rate}%`);
      }
    }

    if (!meta.hideTokensCost && t) {
      const est = estimateCny(t, meta.ts);
      if (est) {
        bits.push(`≈${fmtCny(est.cny)}`);
        detail.push(`按 deepseek-flash 官方价估算 · ${est.peak ? '高峰' : '空闲'}时段`);
      }
    }

    if (!bits.length) return null;
    return {
      text: bits.join(' · '),
      title: detail.join(' · ') || bits.join(' · '),
      detail: detail.slice()
    };
  }

  let metaTipEl = null;
  let metaTipTimer = 0;

  function ensureMetaTip() {
    if (metaTipEl) return metaTipEl;
    if (!document.getElementById('metaTipStyle')) {
      const style = document.createElement('style');
      style.id = 'metaTipStyle';
      style.textContent = `
.meta-tip {
  position: fixed; z-index: 9999;
  width: max-content; max-width: min(520px, calc(100vw - 24px));
  box-sizing: border-box;
  padding: 5px 8px; border: 1px solid var(--line-2); border-radius: 8px;
  background: var(--panel); box-shadow: 0 10px 28px rgba(0, 0, 0, .4);
  color: var(--fg-2); font-size: 11px; line-height: 1.45;
  font-variant-numeric: tabular-nums; white-space: normal;
  overflow-wrap: break-word; pointer-events: none;
  animation: metaTipIn .12s ease-out;
}
.meta-tip.multi {
  padding: 8px 10px; border-radius: 10px; line-height: 1.6;
}
.meta-tip[hidden] { display: none; }
.meta-tip-line + .meta-tip-line {
  margin-top: 3px; padding-top: 3px; border-top: 1px solid var(--line);
}
@keyframes metaTipIn {
  from { opacity: 0; transform: translateY(2px); }
  to { opacity: 1; transform: translateY(0); }
}`;
      document.head.appendChild(style);
    }
    metaTipEl = document.createElement('div');
    metaTipEl.className = 'meta-tip';
    metaTipEl.hidden = true;
    document.body.appendChild(metaTipEl);
    window.addEventListener('scroll', hideMetaTip, true);
    window.addEventListener('resize', hideMetaTip);
    document.addEventListener('pointerdown', hideMetaTip, true);
    return metaTipEl;
  }

  function hideMetaTip() {
    clearTimeout(metaTipTimer);
    if (metaTipEl) metaTipEl.hidden = true;
  }

  function showMetaTip(el, extraLines) {
    if (!el || !el.isConnected) return;
    const lines = Array.isArray(extraLines) ? extraLines : (el._metaTipLines || []);
    if (!lines.length) return;
    const tip = ensureMetaTip();
    tip.innerHTML = '';
    for (const line of lines) {
      const row = document.createElement('div');
      row.className = 'meta-tip-line';
      row.textContent = line;
      tip.appendChild(row);
    }
    tip.classList.toggle('multi', lines.length > 1);
    tip.hidden = false;
    const r = el.getBoundingClientRect();
    const tr = tip.getBoundingClientRect();
    let left = r.left + r.width / 2 - tr.width / 2;
    left = Math.max(8, Math.min(left, window.innerWidth - tr.width - 8));
    let top = r.top - tr.height - 8;
    if (top < 8) top = r.bottom + 8;
    if (top + tr.height > window.innerHeight - 8) {
      top = Math.max(8, window.innerHeight - tr.height - 8);
    }
    tip.style.left = Math.round(left) + 'px';
    tip.style.top = Math.round(top) + 'px';
  }

  /** 用应用内深色浮层替代浏览器原生 title 框。 */
  function bindMetaTip(el, info) {
    if (!el || !info) return;
    el.removeAttribute('title');
    const lines = Array.isArray(info.detail) ? info.detail.filter(Boolean) : [];
    el._metaTipLines = lines;
    if (!lines.length) {
      el.onmouseenter = null;
      el.onmouseleave = null;
      el.onblur = null;
      return;
    }
    el.onmouseenter = () => {
      clearTimeout(metaTipTimer);
      metaTipTimer = setTimeout(() => showMetaTip(el), 120);
    };
    el.onmouseleave = hideMetaTip;
    el.onblur = hideMetaTip;
  }

  // 所有普通 title 也走同一个应用内浮层；第一次悬停时把 title 摘掉，避免系统灰框再出现。
  let globalTipTarget = null;
  function onGlobalTipOver(e) {
    const el = e.target && e.target.closest
      ? e.target.closest('[title],[data-tip]') : null;
    if (!el || (el._metaTipLines && el._metaTipLines.length)) return;
    if (globalTipTarget === el) return;
    let text = el.getAttribute('title');
    if (text) {
      el.setAttribute('data-tip', text);
      el.removeAttribute('title');
    } else {
      text = el.getAttribute('data-tip');
    }
    const lines = String(text || '').split(/\r?\n/)
      .map(s => s.trim()).filter(Boolean);
    if (!lines.length) return;
    globalTipTarget = el;
    clearTimeout(metaTipTimer);
    metaTipTimer = setTimeout(() => {
      if (el.isConnected) showMetaTip(el, lines);
    }, 260);
  }
  function onGlobalTipOut(e) {
    const el = e.target && e.target.closest
      ? e.target.closest('[data-tip]') : null;
    if (!el) return;
    if (e.relatedTarget && el.contains(e.relatedTarget)) return;
    globalTipTarget = null;
    hideMetaTip();
  }
  document.addEventListener('mouseover', onGlobalTipOver, true);
  document.addEventListener('mouseout', onGlobalTipOut, true);

  // ------------------------------------------------------------ 上下文健康标识

  function usageContextTokens(u) {
    if (!u) return 0;
    return (u.input_tokens || 0) + (u.cache_creation_input_tokens || 0) + (u.cache_read_input_tokens || 0);
  }

  /** 一条 usage 的输入 + 缓存 + 输出总量，用于和整轮累计记录对账 */
  function usageTokenTotal(u) {
    if (!u) return 0;
    return usageContextTokens(u) + (u.output_tokens || 0);
  }

  // ------------------------------------------------------------ 上下文提醒 / 轮内保护

  function ensureCtxHintDom() {
    if ($('#ctxHintAction')) return;
    const titleBlock = document.querySelector('.title-block');
    if (!titleBlock) return;
    const pathBtn = titleBlock.querySelector('.path-btn');
    if (!pathBtn) return;
    // 动作按钮放到文件夹路径那一行，和 E:\AI_Claude 齐平
    const folderRow = document.createElement('div');
    folderRow.className = 'folder-row';
    pathBtn.parentNode.insertBefore(folderRow, pathBtn);
    folderRow.appendChild(pathBtn);
    const actionBtn = document.createElement('button');
    actionBtn.className = 'ctx-hint-action';
    actionBtn.id = 'ctxHintAction';
    actionBtn.type = 'button';
    actionBtn.textContent = '建议新开对话并引用';
    actionBtn.hidden = true;
    folderRow.appendChild(actionBtn);
    const style = document.createElement('style');
    style.textContent = `
      .folder-row{display:flex;align-items:center;gap:8px;min-width:0;flex-wrap:wrap}
      .folder-row .path-btn{min-width:0;flex:0 1 auto}
      .ctx-hint-action{border:1px solid rgba(224,112,112,.4);background:rgba(224,112,112,.08);color:#e07070;border-radius:999px;padding:2px 9px;font-size:10px;cursor:pointer;flex:0 0 auto;white-space:nowrap}
      .ctx-hint-action:disabled{opacity:.45;cursor:default}
      .ctx-handoff-text{font-size:13px;line-height:1.7;color:var(--fg-2)}
      .topbar.has-ctx-hint{height:auto;flex:0 0 auto;min-height:62px;padding-top:4px;padding-bottom:4px}
      @media (max-width: 720px){ .ctx-hint-action{font-size:9.5px;padding:1px 6px} .topbar.has-ctx-hint{min-height:56px;padding-top:2px;padding-bottom:2px} }
    `;
    document.head.appendChild(style);

    // 说明弹窗：点顶栏按钮先看说明，再决定是否新开对话
    const modal = document.createElement('div');
    modal.className = 'modal-backdrop';
    modal.id = 'ctxHandoffModal';
    modal.hidden = true;
    modal.innerHTML = `
      <div class="modal dialog" role="dialog" aria-modal="true" aria-labelledby="ctxHandoffTitle">
        <div class="modal-head">
          <b id="ctxHandoffTitle">建议新开对话并引用</b>
          <button class="icon-btn" id="ctxHandoffClose" title="关闭（Esc）">
            <svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>
          </button>
        </div>
        <div class="dialog-body">
          <div class="ctx-handoff-text" id="ctxHandoffText"></div>
          <div class="dialog-note">新对话只会带上最近一次压缩摘要和最近几十条消息（约 3–4K token），不会把当前长上下文整段发过去。</div>
          <div class="dialog-note" id="ctxHandoffPreview" hidden>（预览模式：不会真的创建对话）</div>
        </div>
        <div class="modal-foot dialog-foot">
          <button class="btn" id="ctxHandoffCancel">继续当前对话</button>
          <button class="btn primary" id="ctxHandoffOk">新开对话并引用</button>
        </div>
      </div>`;
    document.body.appendChild(modal);

    actionBtn.addEventListener('click', () => {
      if (actionBtn.disabled) return;
      openHandoffModal();
    });
    $('#ctxHandoffClose').addEventListener('click', closeHandoffModal);
    $('#ctxHandoffCancel').addEventListener('click', closeHandoffModal);
    $('#ctxHandoffOk').addEventListener('click', () => {
      if (modal.dataset.preview === '1') {
        closeHandoffModal();
        toast('这是预览模式；实际使用时点击才会新建对话并引用');
        return;
      }
      closeHandoffModal();
      startHandoffConversation();
    });
    modal.addEventListener('click', e => { if (e.target === modal) closeHandoffModal(); });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && !modal.hidden) closeHandoffModal();
    });
    window.addEventListener('keydown', e => {
      if (e.ctrlKey && e.altKey && !e.shiftKey && (e.key === 'h' || e.key === 'H')) {
        e.preventDefault();
        toggleCtxHintPreview();
      }
    });
    window.__previewCtxHint = toggleCtxHintPreview;
  }

  function openHandoffModal() {
    const modal = $('#ctxHandoffModal');
    if (!modal) return;
    const preview = !!S.ctxPreview;
    const epoch = S.ctxEpoch || 0;
    const text = $('#ctxHandoffText');
    if (text) {
      const base = epoch <= 1
        ? '这个对话已经压缩过 1 次。再压缩一次会丢失早期细节；长任务继续下去也更容易撞到 1M 上限。建议完成当前步骤后，开一个新对话并引用本对话继续。'
        : '这个对话已经压缩过多次，继续压缩会明显丢失早期上下文。建议开一个新对话并引用本对话继续。';
      text.textContent = (preview ? '（预览）' : '') + base;
    }
    const pv = $('#ctxHandoffPreview');
    if (pv) pv.hidden = !preview;
    modal.dataset.preview = preview ? '1' : '0';
    modal.hidden = false;
  }

  function closeHandoffModal() {
    const modal = $('#ctxHandoffModal');
    if (modal) modal.hidden = true;
  }

  /** 按钮预览：Ctrl+Alt+H 或控制台 __previewCtxHint()，不改变真实上下文 */
  function toggleCtxHintPreview() {
    S.ctxPreview = !S.ctxPreview;
    if (S.ctxPreviewTimer) { clearTimeout(S.ctxPreviewTimer); S.ctxPreviewTimer = 0; }
    if (S.ctxPreview) {
      updateContextBadge();
      S.ctxPreviewTimer = setTimeout(() => {
        S.ctxPreview = false;
        S.ctxPreviewTimer = 0;
        updateContextBadge();
      }, 20000);
      toast('按钮预览已显示：点击文件夹路径旁的红色按钮查看说明（20 秒后自动关闭）');
    } else {
      updateContextBadge();
    }
  }

  function updateCtxHint() {
    const action = $('#ctxHintAction');
    if (!action) return;
    const conv = S.conv;
    const n = S.contextTokens || 0;
    const epoch = S.ctxEpoch || 0;
    const preview = !!S.ctxPreview;
    const show = preview || (!!conv && !!conv.compacted && epoch > 0 && n >= CTX_REMIND_AT);
    const topbar = document.querySelector('.topbar');
    if (topbar) topbar.classList.toggle('has-ctx-hint', show);
    action.hidden = !show;
    if (!show) return;
    const running = preview ? false : (!!S.running || !!S.compacting || !!S.cliCompacting);
    action.disabled = running;
    action.title = preview
      ? '预览模式：点击查看说明，不会真的创建对话'
      : (running ? '当前这一轮结束后才能开新对话' : '查看说明并开新对话');
  }

  function maybeGuardContext(n) {
    if (!S.conv || !S.running || S.compacting || S.manualCompact || S.cliCompacting || S.compactWaiter) return;
    if (n >= CTX_COST_HINT_AT) {
      S.costHintedConvs = S.costHintedConvs || new Set();
      if (!S.costHintedConvs.has(S.conv.id)) {
        S.costHintedConvs.add(S.conv.id);
        const p = isPeakTime() ? DS_PRICES.peak : DS_PRICES.offpeak;
        const perCall = n * p.hit / 1e6;
        toast(`上下文已达 ${fmtTok(n)}，单次调用约 ¥${perCall < 0.01 ? perCall.toFixed(3) : perCall.toFixed(2)}；小改动建议开新对话并引用摘要`, 'warn');
      }
    }
    if (n >= CTX_GUARD_STOP && !S.guardStopRequested) {
      S.guardStopRequested = true;
      S.guardStopConvId = S.conv.id;
      setStatus('上下文接近 1M 上限，正在停止本轮并压缩…', 'warn');
      toast('上下文已达 ' + fmtTok(CTX_GUARD_STOP) + '，先停止本轮并自动压缩，避免撞到 1M 上限', 'warn');
      api('/stop', {
        method: 'POST',
        body: JSON.stringify({ id: S.conv.id })
      }).catch(() => {});
    } else if (n >= CTX_GUARD_WARN && !S.guardWarned) {
      S.guardWarned = true;
      toast('上下文已达 ' + fmtTok(CTX_GUARD_WARN) + '，到 ' + fmtTok(CTX_GUARD_STOP) + ' 会自动停止并压缩', 'warn');
    }
  }

  function updateContextBadge() {
    updateCtxHint();
    const el = $('#ctxBadge');
    if (!el) return;
    if (S.ctxPreview) {
      el.hidden = false;
      el.className = 'ctx-badge red';
      el.querySelector('.ctx-text').textContent = '上下文 850K / 1M · 81%';
      el.title = '提醒预览：模拟已压缩过一次、再次到 850K 的状态';
      return;
    }
    if (!S.conv) { el.hidden = true; return; }

    const compacting = (S.compacting && S.compactConvId === S.conv.id) ||
      (S.cliCompacting && S.cliCompactConvId === S.conv.id);
    if (compacting) {
      el.hidden = false;
      el.className = 'ctx-badge compacting';
      el.querySelector('.ctx-text').textContent = '正在压缩上下文…';
      el.title = '历史对话正在被总结成更短的上下文，请稍候；压缩完成后这里会显示新的占用';
      return;
    }

    const n = S.contextTokens || 0;
    if (n <= 0) { el.hidden = true; return; }

    const pct = Math.min(100, (n / CONTEXT_LIMIT) * 100);
    const level = pct >= 80 ? 'red' : pct >= 50 ? 'yellow' : 'green';
    el.hidden = false;
    el.className = 'ctx-badge ' + level;
    el.querySelector('.ctx-text').textContent =
      `上下文 ${fmtTok(n)} / 1M · ${pct < 1 ? pct.toFixed(1) : Math.round(pct)}%`;
    const usable = CONTEXT_LIMIT - 32000;
    const price = isPeakTime() ? DS_PRICES.peak : DS_PRICES.offpeak;
    const perCall = n * price.hit / 1e6;
    el.title =
      `估算当前上下文：${n.toLocaleString()} / ${CONTEXT_LIMIT.toLocaleString()} tokens（${pct.toFixed(1)}%）\n` +
      `按当前上下文，单次调用约 ¥${perCall < 0.01 ? perCall.toFixed(3) : perCall.toFixed(2)}（缓存命中价）；上下文只增不减，小改动建议开新对话并引用摘要\n` +
      `可用输入上限约 ${usable.toLocaleString()}（另给 32k 输出预留）\n` +
      `达到 ${AUTO_COMPACT_AT.toLocaleString()} 会自动压缩（CLI 边界 + 发送前兜底）\n` +
      `客户端轮内兜底：${CTX_GUARD_WARN.toLocaleString()} 提示，${CTX_GUARD_STOP.toLocaleString()} 停止本轮并压缩\n` +
      '绿 < 50% · 黄 50–80% · 红 ≥ 80%';
  }

  function setActivityMeta(act, meta) {
    if (!act || !act.meta) return;
    const info = turnMetaInfo(meta);
    if (!info) return;
    act.meta.textContent = info.text;
    bindMetaTip(act.meta, info);
  }

  function setActivitySummary(act, steps, files) {
    act.el.classList.toggle('has-process', steps > 0);
    act.cnt.textContent = steps > 0 ? `${steps} 步` : '';
    act.files.textContent = files > 0 ? `${files} 个文件` : '';
  }

  function refreshActivitySummary(run) {
    if (!run || !run.activity) return;
    let steps = 0;
    for (const b of run.blocks.values()) {
      if (b.type === 'thinking' || b.type === 'tool_use') steps++;
    }
    const files = aggregateEdits(collectRunEditRecords(run)).length;
    setActivitySummary(run.activity, steps, files);
  }

  /**
   * 收尾过程折叠：运行中显示所有临时结论；
   * 结束后把最后一个过程/插话之前的文字收回过程区，只留最终结论在外面。
   */
  function finalizeActivity(run, collapse) {
    const act = run.activity;
    if (!act) return [];

    const hasProcess = [...act.body.children].some(el => {
      const b = el._blk;
      return b && b.type !== 'text';
    });
    if (!hasProcess) {
      // 纯文字轮次：过程区里若有内容先搬回回复区，再移除空壳
      for (const el of [...act.body.children]) {
        run.body.insertBefore(el, run.progress && run.progress.parentNode === run.body ? run.progress : null);
      }
      act.el.remove();
      run.activity = null;
      run.activityBody = null;
      scheduleProcessCollapseUpdate();
      return [];
    }

    const items = (run.order || []).filter(it => {
      if (!it) return false;
      if (it.type === 'steer' || it.type === 'auto') return true;
      return it.key && run.blocks.get(it.key) === it;
    });
    let lastNonText = -1;
    items.forEach((it, i) => {
      if (it.type !== 'text') lastNonText = i;
    });
    const steerSummaries = [];
    for (let i = 0; i <= lastNonText; i++) {
      const it = items[i];
      if (it.type === 'steer') {
        // 展开时留在原步骤位置；收起时在过程块上方显示一份副本
        act.body.appendChild(it.el);
        const summary = it.el.cloneNode(true);
        summary.classList.add('steer-summary');
        steerSummaries.push(summary);
        continue;
      }
      act.body.appendChild(it.el);
    }
    // 最后一个步骤之后的文字是本轮最终结论，留在过程区外面
    for (let i = lastNonText + 1; i < items.length; i++) {
      const it = items[i];
      if (it.type !== 'text') continue;
      run.body.insertBefore(it.el, run.progress && run.progress.parentNode === run.body ? run.progress : null);
    }

    act.el.classList.remove('live');
    act.state.innerHTML = '';
    if (collapse && !act.userToggled) act.el.open = false;
    if (steerSummaries.length) {
      for (const summary of steerSummaries) {
        summary.style.display = act.el.open ? 'none' : '';
        run.body.insertBefore(summary, act.el);
      }
      act.el.addEventListener('toggle', () => {
        for (const summary of steerSummaries) {
          summary.style.display = act.el.open ? 'none' : '';
        }
      });
    }
    scheduleProcessCollapseUpdate();
    return [];
  }

  /** 本轮最终结论：最后一个步骤之后的正文；没有就退回最后一条正文 */
  function finalRunText(run) {
    const items = (run.order || []).filter(it => it && (it.type === 'steer' ||
      (it.key && run.blocks.get(it.key) === it)));
    let lastStep = -1;
    items.forEach((it, i) => {
      if (it.type !== 'text' && it.type !== 'steer') lastStep = i;
    });
    const after = [];
    for (let i = lastStep + 1; i < items.length; i++) {
      const it = items[i];
      if (it.type === 'text' && it.text && it.text.trim()) after.push(it.text.trim());
    }
    if (after.length) return after.join('\n');
    for (let i = items.length - 1; i >= 0; i--) {
      const it = items[i];
      if (it.type === 'text' && it.text && it.text.trim()) return it.text.trim();
    }
    return '';
  }

  // ------------------------------------------------------------ 已编辑文件

  const EDIT_TOOLS = new Set(['Edit', 'Write', 'MultiEdit', 'NotebookEdit']);

  function splitLines(s) {
    s = String(s == null ? '' : s).replace(/\r\n?/g, '\n');
    if (!s) return [];
    const a = s.split('\n');
    if (a[a.length - 1] === '') a.pop();
    return a;
  }

  /** 去掉相同的前缀/后缀行后，计算真正增删的行数 */
  function lineDelta(oldS, newS) {
    const a = splitLines(oldS);
    const b = splitLines(newS);
    let p = 0;
    while (p < a.length && p < b.length && a[p] === b[p]) p++;
    let s = 0;
    while (s < a.length - p && s < b.length - p &&
      a[a.length - 1 - s] === b[b.length - 1 - s]) s++;
    return { removed: a.length - p - s, added: b.length - p - s };
  }

  function editToolInfo(name, input) {
    if (!input || typeof input !== 'object') return null;

    if (name === 'Edit') {
      if (typeof input.file_path !== 'string' || !input.file_path) return null;
      const d = lineDelta(input.old_string, input.new_string);
      return { path: input.file_path, added: d.added, removed: d.removed };
    }
    if (name === 'MultiEdit') {
      if (typeof input.file_path !== 'string' || !input.file_path) return null;
      let added = 0;
      let removed = 0;
      for (const e of Array.isArray(input.edits) ? input.edits : []) {
        const d = lineDelta(e && e.old_string, e && e.new_string);
        added += d.added;
        removed += d.removed;
      }
      return { path: input.file_path, added, removed };
    }
    if (name === 'Write') {
      if (typeof input.file_path !== 'string' || !input.file_path) return null;
      return { path: input.file_path, added: splitLines(input.content).length, removed: 0 };
    }
    if (name === 'NotebookEdit') {
      const p = input.notebook_path || input.file_path;
      if (typeof p !== 'string' || !p) return null;
      if (input.edit_mode === 'delete') return { path: p, added: 0, removed: 0 };
      return { path: p, added: splitLines(input.new_source).length, removed: 0 };
    }
    return null;
  }

  /** records: [{ name, input, ok }] → [{ path, added, removed, edits }]（按路径聚合） */
  function aggregateEdits(records) {
    const map = new Map();
    for (const r of records) {
      if (!r || !r.ok || !EDIT_TOOLS.has(r.name)) continue;
      const info = editToolInfo(r.name, r.input);
      if (!info) continue;
      const key = info.path.replace(/\\/g, '/').toLowerCase();
      let cur = map.get(key);
      if (!cur) {
        cur = { path: info.path, added: 0, removed: 0, edits: 0 };
        map.set(key, cur);
      }
      cur.added += info.added;
      cur.removed += info.removed;
      cur.edits += 1;
    }
    return [...map.values()];
  }

  function collectRunEditRecords(run) {
    const out = [];
    if (!run) return out;
    for (const b of run.blocks.values()) {
      if (b.type !== 'tool_use') continue;
      out.push({ name: b.data.name, input: b.data.input, ok: !!b.hasResult && !!b.resultOk });
    }
    return out;
  }

  function historyEditRecords(blocks) {
    return (blocks || [])
      .filter(b => b.type === 'tool_use')
      .map(b => ({ name: b.name, input: b.input, ok: b.result != null && !b.isError }));
  }

  // ------------------------------------------------------------ 结论里的生成文件

function ensureArtifactStyle() {
  if (document.getElementById('artifact-ui-style')) return;
  const style = document.createElement('style');
  style.id = 'artifact-ui-style';
  style.textContent = `
/* 生成的文件 */
.artifact-card { border: 1px solid var(--line); border-radius: 12px; background: var(--panel); overflow: hidden; }
.artifact-card-head {
  display: flex; align-items: center; gap: 8px;
  padding: 9px 12px; font-size: 12px; color: var(--fg-2);
}
.artifact-card-head svg { width: 14px; height: 14px; color: var(--fg-4); }
.artifact-count { margin-left: auto; font-family: var(--mono); font-size: 11px; color: var(--fg-4); }
.artifact-list { border-top: 1px solid var(--line); }
.artifact-row { display: flex; align-items: center; gap: 10px; padding: 8px 12px; }
.artifact-row + .artifact-row { border-top: 1px solid var(--line); }
.artifact-row:hover { background: var(--panel-2); }
.artifact-main { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px; text-align: left; }
.artifact-name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 12.5px; color: var(--fg-2); }
.artifact-dir {
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  font-family: var(--mono); font-size: 10.5px; color: var(--fg-4);
}
.artifact-actions { display: flex; gap: 6px; flex: 0 0 auto; }
.artifact-btn {
  padding: 4px 9px; border-radius: 7px; border: 1px solid var(--line-2);
  background: var(--panel-2); color: var(--fg-2); font-size: 11px; white-space: nowrap;
}
.artifact-btn:hover { background: var(--panel-3); color: var(--fg); border-color: #3a424e; }
`;
  document.head.appendChild(style);
}
ensureArtifactStyle();
  function artifactSplit(p) {
    const slash = Math.max(p.lastIndexOf('\\'), p.lastIndexOf('/'));
    let dir = slash > 0 ? p.slice(0, slash) : '';
    if (/^[A-Za-z]:$/.test(dir)) dir += '\\';
    return { dir, name: slash >= 0 ? p.slice(slash + 1) : p };
  }

  function artifactPath(raw) {
    let p = String(raw || '').trim();
    if (!p) return '';
    if (p.includes('://')) return '';
    p = p.replace(/[ \t]+$/, '');
    p = p.replace(/[ \t]*[.,;:!?)\]}>》】”’。，；：、]+$/, '');
    if (!/^(?:[A-Za-z]:[\\/]|\\\\)/.test(p)) return '';
    if (/[<>{}*|?]/.test(p)) return '';
    const name = artifactSplit(p).name;
    if (!name || !/\.[A-Za-z0-9]{1,10}$/.test(name)) return '';
    return p;
  }

  function extractArtifactPaths(text) {
    const src = String(text || '');
    if (!src) return [];
    const seen = new Set();
    const out = [];
    const add = raw => {
      const p = artifactPath(raw);
      if (!p) return;
      const key = p.replace(/\//g, '\\').toLowerCase();
      if (seen.has(key)) return;
      seen.add(key);
      const parts = artifactSplit(p);
      out.push({ path: p, name: parts.name, dir: parts.dir });
    };
    const quoted = /[`"'“”‘’]([A-Za-z]:[\\/][^`"'“”‘’\r\n]+)[`"'“”‘’]/g;
    for (const m of src.matchAll(quoted)) add(m[1]);
    const bare = /(?:[A-Za-z]:[\\/]|\\\\)[^\s`"'“”‘’<>|?*，。；：、（）【】《》]+/g;
    for (const m of src.matchAll(bare)) add(m[0]);
    return out.slice(0, 6);
  }

  function buildArtifactCard(files) {
    const card = document.createElement('div');
    card.className = 'block artifact-card';

    const head = document.createElement('div');
    head.className = 'artifact-card-head';
    head.innerHTML = `${ICON.file}<span>生成的文件</span>`;
    const count = document.createElement('span');
    count.className = 'artifact-count';
    count.textContent = String(files.length);
    head.appendChild(count);
    card.appendChild(head);

    const list = document.createElement('div');
    list.className = 'artifact-list';
    card.appendChild(list);

    for (const f of files) {
      const row = document.createElement('div');
      row.className = 'artifact-row';

      const main = document.createElement('button');
      main.type = 'button';
      main.className = 'artifact-main';
      main.title = f.path;
      const name = document.createElement('span');
      name.className = 'artifact-name';
      name.textContent = f.name;
      const dir = document.createElement('span');
      dir.className = 'artifact-dir';
      dir.textContent = f.dir || f.path;
      main.append(name, dir);
      main.addEventListener('click', () => revealPath(f.path));

      const actions = document.createElement('div');
      actions.className = 'artifact-actions';
      const open = document.createElement('button');
      open.type = 'button';
      open.className = 'artifact-btn';
      open.textContent = '打开';
      open.title = '打开文件';
      open.addEventListener('click', () => revealPath(f.path));
      const folder = document.createElement('button');
      folder.type = 'button';
      folder.className = 'artifact-btn';
      folder.textContent = '文件夹';
      folder.title = '打开所在文件夹';
      folder.addEventListener('click', () => revealPath(f.dir || f.path));
      actions.append(open, folder);

      row.append(main, actions);
      list.appendChild(row);
    }
    return card;
  }

  function refreshArtifactCard(run) {
    if (!run) return;
    const texts = [];
    for (const b of run.blocks.values()) {
      if (b.type === 'text' && b.text && b.text.trim()) texts.push(b.text);
    }
    const files = texts.length ? extractArtifactPaths(texts[texts.length - 1]) : [];
    if (!files.length) {
      if (run.artifactEl) { run.artifactEl.remove(); run.artifactEl = null; }
      return;
    }
    const card = buildArtifactCard(files);
    if (run.artifactEl) run.artifactEl.replaceWith(card);
    else run.body.appendChild(card);
    run.artifactEl = card;
  }
  function buildEditCard(files) {
    let totalAdd = 0;
    let totalDel = 0;
    for (const f of files) { totalAdd += f.added; totalDel += f.removed; }

    const card = document.createElement('div');
    card.className = 'block edit-card';

    const head = document.createElement('div');
    head.className = 'edit-card-head';
    head.innerHTML = `${ICON.file}<span class="edit-title"></span>`;
    head.querySelector('.edit-title').textContent = `已编辑 ${files.length} 个文件`;
    const total = document.createElement('span');
    total.className = 'edit-total';
    total.innerHTML = `<span class="edit-add">+${totalAdd}</span> <span class="edit-del">-${totalDel}</span>`;
    head.appendChild(total);
    card.appendChild(head);

    const list = document.createElement('div');
    list.className = 'edit-list';
    card.appendChild(list);

    const SHOW = 3;
    const hiddenRows = [];
    files.forEach((f, i) => {
      const row = document.createElement('button');
      row.className = 'edit-row';
      row.title = f.path;
      if (i >= SHOW) row.hidden = true;

      const pathEl = document.createElement('span');
      pathEl.className = 'edit-path';
      const slash = Math.max(f.path.lastIndexOf('\\'), f.path.lastIndexOf('/'));
      if (slash > 0) {
        const dir = document.createElement('span');
        dir.className = 'ep-dir';
        dir.textContent = f.path.slice(0, slash + 1);
        const name = document.createElement('span');
        name.className = 'ep-name';
        name.textContent = f.path.slice(slash + 1);
        pathEl.append(dir, name);
      } else {
        const name = document.createElement('span');
        name.className = 'ep-name';
        name.textContent = f.path;
        pathEl.appendChild(name);
      }

      const stats = document.createElement('span');
      stats.className = 'edit-stats';
      stats.innerHTML = `<span class="edit-add">+${f.added}</span> <span class="edit-del">-${f.removed}</span>`;

      row.append(pathEl, stats);
      row.addEventListener('click', () => revealPath(f.path));
      list.appendChild(row);
      if (i >= SHOW) hiddenRows.push(row);
    });

    if (hiddenRows.length) {
      const more = document.createElement('button');
      more.className = 'edit-more';
      more.textContent = `再显示 ${hiddenRows.length} 个文件`;
      more.addEventListener('click', () => {
        const show = hiddenRows[0].hidden;
        for (const r of hiddenRows) r.hidden = !show;
        more.textContent = show ? '收起' : `再显示 ${hiddenRows.length} 个文件`;
      });
      list.appendChild(more);
    }

    return card;
  }

  function refreshEditCard(run) {
    if (!run) return;
    const files = aggregateEdits(collectRunEditRecords(run));
    if (!files.length) {
      if (run.cardEl) { run.cardEl.remove(); run.cardEl = null; }
      return;
    }
    const card = buildEditCard(files);
    if (run.cardEl) run.cardEl.replaceWith(card);
    else run.body.appendChild(card);
    run.cardEl = card;
  }

  function appendCaret(mdEl) {
    const caret = document.createElement('span');
    caret.className = 'caret';
    const last = mdEl.lastElementChild;
    if (last && (last.tagName === 'P' || last.tagName === 'LI' || last.tagName === 'H1' || last.tagName === 'H2' || last.tagName === 'H3')) {
      last.appendChild(caret);
    } else {
      mdEl.appendChild(caret);
    }
  }

  // 只让最近一段正在生成的文字显示光标，之前那些临时结论不再闪
  function clearOtherTextCarets(current) {
    const run = S.currentRun;
    if (!run) return;
    for (const other of run.blocks.values()) {
      if (other === current || other.type !== 'text' || !other.md) continue;
      other.md.querySelectorAll('.caret').forEach(el => el.remove());
    }
  }

  function paintText(b, streaming) {
    b.md.innerHTML = md(b.text);
    if (streaming) {
      clearOtherTextCarets(b);
      appendCaret(b.md);
      if (isLiveBlock(b)) {
        const run = S.currentRun;
        run.lastTextAt = Date.now();
        run.autoStageText = '';
        // 已经有白字结论在流式输出时，进度行让位给正文
        if (b.text.trim()) setRunProgress(run, '');
      }
    }
  }

  function paintThinking(b, streaming) {
    b.body.textContent = b.text;
    b.body.scrollTop = b.body.scrollHeight;
    const n = b.text.length;
    b.cnt.textContent = streaming ? `思考中 · ${n} 字` : `${n} 字`;
    b.el.classList.toggle('live', !!streaming);
    if (streaming) updateProgressForBlock(b);
  }

  function schedulePaint(b) {
    if (b.raf) return;
    b.raf = requestAnimationFrame(() => {
      b.raf = 0;
      if (b.type === 'text') paintText(b, true);
      else if (b.type === 'thinking') paintThinking(b, true);
      if (isCompactingCurrent()) syncCompactionProgress();
      if (S.stick) scrollToBottom();
    });
  }

  // 长任务里让用户随时看到「现在在干什么」：这条白字进度行不调用模型，不增加任何 API 开销。
  function progressForThinking(b) {
    const t = String(b.text || '').replace(/\s+/g, ' ').trim();
    return t ? '正在思考：' + (t.length > 64 ? t.slice(0, 64) + '…' : t) : '正在思考…';
  }

  function progressForTool(b) {
    const name = (b.data && b.data.name) || '工具';
    const raw = b.data && b.data.input ? toolSummary(name, b.data.input) : '';
    const summary = String(raw || '').replace(/\s+/g, ' ').trim();
    return '正在执行 ' + name + (summary ? '：' + (summary.length > 80 ? summary.slice(0, 80) + '…' : summary) : '…');
  }

  /** 客户端兜底：模型没写阶段正文时，用工具名/参数生成一句短中文 */
  function autoProgressText(name, input) {
    const inp = input || {};
    const base = p => String(p || '').replace(/\\/g, '/').split('/').pop();
    const cut = (s, n) => {
      const t = String(s || '').replace(/\s+/g, ' ').trim();
      return t.length > n ? t.slice(0, n) + '…' : t;
    };
    if (name === 'Bash') {
      const c = String(inp.command || '').toLowerCase();
      if (/--version|command -v|\bwhich\b|python\s+-v|node\s+-v|npm\s+-v/.test(c)) return '检查运行环境';
      if (/zipfile|word\/document|document\.xml/.test(c) && /(read|open|zip)/.test(c)) return '校验生成的文件';
      if (/\.docx|winword|\bword\b/.test(c)) return '生成 Word 文档';
      if (/\.(py|js|mjs|ps1|sh)\b/.test(c) && /\b(python|node|powershell|bash|sh)\b/.test(c)) return '运行脚本';
      if (/git\s+(status|diff|log|show|branch)/.test(c)) return '查看代码状态';
      if (/(npm|pnpm|yarn|pip|apt|choco|winget)\b.*\b(install|add|i)\b/.test(c)) return '安装依赖';
      if (/\b(pytest|vitest|jest|mocha|go test|cargo test|npm test|pnpm test)\b/.test(c)) return '运行测试';
      if (/\b(mkdir|new-item|touch|cp|copy|mv|move)\b/.test(c)) return '整理文件';
      if (/\b(grep|rg|findstr|select-string|find|ls|dir)\b/.test(c)) return '查找文件';
      return '运行命令';
    }
    if (name === 'Read') return '读取文件 ' + cut(base(inp.file_path || inp.path), 20);
    if (name === 'Write') return '写入文件 ' + cut(base(inp.file_path), 20);
    if (name === 'Edit' || name === 'MultiEdit' || name === 'NotebookEdit') {
      return '修改文件 ' + cut(base(inp.file_path), 20);
    }
    if (name === 'Grep') return '搜索内容' + (inp.pattern ? '：' + cut(inp.pattern, 16) : '');
    if (name === 'Glob') return '查找文件' + (inp.pattern ? '：' + cut(inp.pattern, 16) : '');
    if (name === 'WebSearch' || name === 'WebFetch') return '查询资料';
    if (name === 'Task') return '启动子代理' + (inp.description ? '：' + cut(inp.description, 16) : '');
    if (name === 'AskUserQuestion') return '等待你的选择';
    return name || '执行工具';
  }

  /** 模型没有阶段正文时，补一条「自动」进度；同类动作不重复刷 */
  function maybeAddAutoStage(run, b) {
    if (!run || !b || !isLiveBlock(b)) return;
    if (run.lastTextAt && Date.now() - run.lastTextAt < 15000) return;
    const name = (b.data && b.data.name) || '';
    if (!name) return;
    const text = autoProgressText(name, b.data.input);
    if (!text || text === run.autoStageText) return;
    const now = Date.now();
    // 最近 12 秒出现过的同类动作（例如 查找→修改→查找）不重复刷
    const recent = (run.autoStages || []).slice(-3);
    if (recent.some(el => el.dataset.text === text && now - Number(el.dataset.at || 0) < 12000)) return;
    const stick = S.stick;
    // 插入第 4 条时会移除最旧的一条；这类高度变化会触发 scroll 事件，
    // 先加保护窗口，别把它误判成用户主动上滚。
    S.scrollGuardUntil = Math.max(S.scrollGuardUntil || 0, Date.now() + 220);
    const el = document.createElement('div');
    el.className = 'auto-stage';
    el.textContent = text;
    el.dataset.text = text;
    el.dataset.at = String(now);
    run.body.insertBefore(el, run.progress && run.progress.parentNode === run.body ? run.progress : null);
    run.autoStages = run.autoStages || [];
    run.autoStages.push(el);
    run.autoStageText = text;
    if (run.order) run.order.push({ type: 'auto', el });
    while (run.autoStages.length > 3) {
      const dropped = run.autoStages.shift();
      if (!dropped) break;
      dropped.remove();
      if (run.order) {
        const idx = run.order.findIndex(item => item && item.el === dropped);
        if (idx >= 0) run.order.splice(idx, 1);
      }
    }
    if (stick && S.stick) {
      S.stick = true;
      scrollToBottom(true);
    }
  }

  function isLiveBlock(b) {
    return !!(S.currentRun && b && S.currentRun.blocks.get(b.key) === b);
  }

  function isCompactingCurrent() {
    if (!S.conv) return false;
    const id = S.conv.id;
    return (S.compacting && S.compactConvId === id) ||
      (S.manualCompact && S.manualCompactConvId === id) ||
      (S.cliCompacting && S.cliCompactConvId === id);
  }

  /** 压缩期间把「正在思考」这一栏改成压缩提示 */
  function syncCompactionProgress() {
    if (!S.currentRun || !isCompactingCurrent()) return;
    setRunProgress(S.currentRun, '正在压缩上下文…', 'compact');
  }

  function setRunProgress(run, text, kind) {
    if (!run || !run.progress) return;
    if (!text) { run.progress.hidden = true; return; }
    run.progress.hidden = false;
    run.progress.className = 'run-progress' + (kind ? ' ' + kind : '');
    run.progress.textContent = text;
    // 保持在回复区最下方，不打断正在阅读的文字
    if (run.body.lastElementChild !== run.progress) run.body.appendChild(run.progress);
  }

  function updateProgressForBlock(b) {
    if (!isLiveBlock(b)) return;
    if (isCompactingCurrent()) {
      syncCompactionProgress();
      return;
    }
    if (b.type === 'thinking') setRunProgress(S.currentRun, progressForThinking(b), 'thinking');
    else if (b.type === 'tool_use') setRunProgress(S.currentRun, progressForTool(b), 'tool');
  }

  function clearRunProgress(run) {
    if (!run || !run.progress) return;
    run.progress.remove();
    run.progress = null;
  }

  // styles.css 在本机被只读 ACL 锁住，进度行样式从这里注入
  function ensureRunProgressStyle() {
    if (document.getElementById('runProgressStyle')) return;
    const style = document.createElement('style');
    style.id = 'runProgressStyle';
    style.textContent = `
.run-progress {
  display: flex; align-items: baseline; gap: 8px;
  font-size: 13.5px; line-height: 1.6;
  color: var(--fg); padding: 1px 0 2px;
  word-break: break-word;
  animation: pulse 1.8s ease-in-out infinite;
}
.run-progress::before {
  content: ''; width: 6px; height: 6px; border-radius: 50%;
  background: var(--accent); flex: 0 0 auto; transform: translateY(-1px);
}
.run-progress.thinking { color: var(--fg-2); }
.run-progress.tool { color: var(--fg); }
.run-progress.wait { color: var(--yellow); }
.run-progress.compact { color: var(--accent); }
.compact-divider {
  align-self: center; display: flex; align-items: center; gap: 10px;
  width: 100%; max-width: 560px; margin: 22px 0 6px;
  color: var(--fg-4); font-size: 11.5px; line-height: 1.5;
  letter-spacing: .04em; user-select: none; white-space: nowrap;
}
.compact-divider::before,
.compact-divider::after {
  content: ''; height: 1px; flex: 1 1 24px; min-width: 16px;
  background: currentColor; opacity: .28;
}
.auto-stage {
  display: flex; align-items: baseline; gap: 7px;
  font-size: 12.5px; line-height: 1.6;
  color: var(--fg-3); padding: 0;
  word-break: break-word;
}
.auto-stage::before {
  content: '自动'; flex: 0 0 auto;
  font-size: 9.5px; line-height: 1.5; letter-spacing: .5px;
  color: var(--fg-4); border: 1px solid var(--line-2);
  border-radius: 4px; padding: 0 3px; opacity: .8;
}
.time-divider {
  align-self: center;
  margin: 18px 0 0;
  color: var(--fg-4);
  font-size: 11.5px;
  line-height: 1.4;
  text-align: center;
  user-select: none;
  font-variant-numeric: tabular-nums;
}
.time-divider + .msg.user { margin-top: 6px; }
.file-chip .ref-chip-name { font-family: var(--mono); font-size: 11.5px; }
.file-chip .ref-chip-ic { font-size: 13px; }
.update-btn {
  display: inline-flex; align-items: center; gap: 6px;
  height: 28px; padding: 0 10px; border-radius: 999px;
  border: 1px solid var(--accent-line);
  background: var(--accent-soft);
  color: var(--accent);
  font-size: 11.5px; line-height: 1; white-space: nowrap;
}
.update-btn:hover { background: rgba(224, 138, 95, .2); }
.update-btn:disabled { opacity: .65; cursor: default; }
.update-btn::before {
  content: ''; width: 6px; height: 6px; border-radius: 50%;
  background: var(--accent);
  animation: updatePulse 2s ease-out infinite;
}
.status-line .update-btn {
  margin-left: auto;
  height: 22px; padding: 0 8px;
  font-size: 10.5px; gap: 5px;
}
.status-line .update-btn::before { width: 5px; height: 5px; }
@keyframes updatePulse {
  0% { box-shadow: 0 0 0 0 rgba(224, 138, 95, .4); }
  70% { box-shadow: 0 0 0 6px rgba(224, 138, 95, 0); }
  100% { box-shadow: 0 0 0 0 rgba(224, 138, 95, 0); }
}
/* hidden 也会形成滚动容器，拦掉 scroll chaining；clip 不会。 */
.activity, .tool { overflow: hidden; overflow: clip; }
.process-collapse-btn {
  position: absolute; left: 14px; top: 70%; transform: translateY(-50%);
  z-index: 4;
  display: flex; align-items: center; gap: 6px;
  height: 30px; padding: 0 10px;
  border: 1px solid var(--line-2); border-radius: 999px;
  background: rgba(20, 23, 28, .92); color: var(--fg-2);
  box-shadow: var(--shadow);
  font-size: 11.5px; line-height: 1; white-space: nowrap;
  backdrop-filter: blur(6px);
}
.process-collapse-btn[hidden] { display: none; }
.process-collapse-btn:hover { background: var(--panel-3); color: var(--fg); }
.process-collapse-btn svg { width: 14px; height: 14px; color: var(--accent); flex: 0 0 auto; }
.process-collapse-btn.compact { padding: 0 8px; }
.process-collapse-btn.compact span { display: none; }
@media (max-width: 900px) {
  .process-collapse-btn { left: 8px; padding: 0 8px; }
  .process-collapse-btn span { display: none; }
}
/* 顶部工具栏：宽度不够时只压缩右侧三个下拉框的文字，不换行、不堆叠 */
.topbar { flex-wrap: nowrap; }
.title-block { min-width: 200px; overflow: hidden; }
.title-row { min-width: 0; overflow: hidden; }
.top-actions { flex: 0 1 auto; min-width: 0; flex-wrap: nowrap; }
.select-wrap { flex: 0 1 auto; min-width: 56px; }
.select-wrap select { min-width: 0; }
@media (min-width: 881px) and (max-width: 1100px) {
  .topbar { gap: 8px; padding-left: 16px; padding-right: 12px; }
  .top-actions { gap: 6px; }
  .select-wrap { padding: 0 6px; }
  .select-label { display: none; }
  #modelWrap select { max-width: 130px; }
  .select-wrap select { max-width: 100px; }
}
`;
    document.head.appendChild(style);
  }
  ensureRunProgressStyle();

  function ensureRun() {
    if (!S.currentRun) {
      clearEmpty();
      const { row, body } = createAssistantEl();
      const activity = buildActivityEl(true);
      body.appendChild(activity.el);
      // 进度行放在「过程」折叠区外面，折叠时也能看到当前在做什么
      const compacting = isCompactingCurrent();
      const progress = document.createElement('div');
      progress.className = 'run-progress ' + (compacting ? 'compact' : 'thinking');
      progress.textContent = compacting ? '正在压缩上下文…' : '正在思考…';
      body.appendChild(progress);
      S.currentRun = {
        row, body, activity, activityBody: activity.body,
        blocks: new Map(), toolMap: new Map(), order: [], cardEl: null,
        progress,
        // 混合兜底：模型没写阶段正文时，用工具动作补一条「自动」进度
        autoStages: [], autoStageText: '', lastTextAt: 0
      };
    }
    return S.currentRun;
  }

  /** 切回正在运行的对话时，历史里属于“这一轮”的消息不要重复渲染（实时快照里有） */
  function trimHistoryForLive(messages, live) {
    // 用这一轮的第一条用户消息做锚点（插话刚好触发下一轮时，它本身可能就是一条插话）
    const anchor = (live.users || [])[0];
    if (!anchor) return messages;
    const anchorSteer = !!anchor.steer;
    const anchorImages = Array.isArray(anchor.images) ? anchor.images.length : 0;
    let idx = -1;
    for (let i = messages.length - 1; i >= 0; i--) {
      const m = messages[i];
      if (m.role !== 'user' || !!m.steer !== anchorSteer) continue;
      const images = Array.isArray(m.images) ? m.images.length : 0;
      if ((m.text || '') === (anchor.text || '') && images === anchorImages) { idx = i; break; }
    }
    if (idx < 0 && anchor.ts) {
      const t = new Date(anchor.ts).getTime();
      if (isFinite(t)) {
        for (let i = messages.length - 1; i >= 0; i--) {
          const m = messages[i];
          if (m.role !== 'user' || !!m.steer !== anchorSteer) continue;
          const mt = new Date(m.ts).getTime();
          if (isFinite(mt) && Math.abs(mt - t) < 15000) { idx = i; break; }
        }
      }
    }
    return idx >= 0 ? messages.slice(0, idx) : messages;
  }

  /** 用服务端下发的实时快照重建当前这一轮的界面（切回运行中的对话时使用） */
  function renderLiveRun(live) {
    const users = Array.isArray(live.users) ? live.users : [];
    const blocks = Array.isArray(live.blocks) ? live.blocks : [];
    const first = users.find(u => !u.steer);
    if (first) {
      maybeAddChatTime(first.ts);
      addUserBubble(first.text, first.images);
    }

    const run = ensureRun();
    const steers = new Map();
    for (const u of users) {
      if (!u.steer) continue;
      noteChatActivityTime(u.ts);
      const raw = Number.isInteger(u.afterBlocks) ? u.afterBlocks : blocks.length;
      const at = Math.max(0, Math.min(raw, blocks.length));
      if (!steers.has(at)) steers.set(at, []);
      steers.get(at).push(u);
    }
    const flushSteers = at => {
      for (const u of steers.get(at) || []) addInlineSteer(run, u.text, u.images);
    };

    let lastTextBlk = null;
    for (let i = 0; i < blocks.length; i++) {
      flushSteers(i);
      const b = blocks[i] || {};
      const last = i === blocks.length - 1;
      if (b.type === 'text') {
        if (!b.text || !b.text.trim()) continue;
        const blk = ensureBlock(b.key, { type: 'text' });
        if (!blk) continue;
        blk.text = b.text;
        paintText(blk, false);
        lastTextBlk = blk;
      } else if (b.type === 'thinking') {
        if (!b.text || !b.text.trim()) continue;
        const blk = ensureBlock(b.key, { type: 'thinking' });
        if (!blk) continue;
        blk.text = b.text;
        paintThinking(blk, last);
      } else if (b.type === 'tool_use') {
        const blk = ensureBlock(b.key, { type: 'tool_use', id: b.id, name: b.name, input: b.input || null });
        if (!blk) continue;
        if (b.input) updateToolBlock(blk, { name: b.name, input: b.input });
        if (b.done) {
          setToolResult(blk, b.result, b.isError);
          blk.hasResult = true;
          blk.resultOk = !b.isError;
        } else {
          blk.statusEl.className = 'tool-status';
          blk.statusEl.innerHTML = '<span class="spin"></span>';
        }
      }
    }
    flushSteers(blocks.length);

    // 切回来时恢复「最后一段正文」的橙色光标；它后面可能已经跟着工具/思考块，
    // 不能只看“是不是最后一个块”，否则切走再切回光标就没了。
    if (lastTextBlk) appendCaret(lastTextBlk.md);

    if (live.permission) {
      showPermission({
        requestId: live.permission.requestId,
        toolName: live.permission.toolName,
        input: live.permission.input,
        suggestions: live.permission.suggestions || [],
        requiresUserInteraction: !!live.permission.requiresUserInteraction
      });
    }
    if (live.ask) showAsk(live.ask);
    refreshActivitySummary(run);
    if (S.stick) scrollToBottom(true);
    scheduleProcessCollapseUpdate();
  }

  function insertBlock(run, b) {
    if (run.order) run.order.push(b);

    if (b.type === 'text') {
      // 阶段性结论的白字留在「过程」折叠区外面，运行中始终可见；
      // 一轮结束后 finalizeActivity 再把它收回过程区，只留最后结论在外面。
      run.lastTextAt = Date.now();
      run.autoStageText = '';
      run.body.insertBefore(b.el, run.progress && run.progress.parentNode === run.body ? run.progress : null);
      return;
    }

    run.activityBody.appendChild(b.el);
    updateProgressForBlock(b);
    refreshActivitySummary(run);
    if (b.type === 'tool_use' && b.data.input) maybeAddAutoStage(run, b);

    // 思考、命令等过程在运行中默认收起，只留白字阶段性结论和底部进度行
    if (run.activity && !run.activity.userToggled) run.activity.el.open = false;
  }

  function ensureBlock(key, block) {
    const run = ensureRun();
    let b = run.blocks.get(key);
    if (b) return b;

    if (block.type === 'text') b = makeTextBlock(key);
    else if (block.type === 'thinking') b = makeThinkingBlock(key);
    else if (block.type === 'tool_use') b = makeToolBlock(block);
    else return null;

    b.el._blk = b;
    run.blocks.set(key, b);

    if (block.type === 'tool_use') {
      b.el._toolId = block.id;
      b.hasResult = false;
      b.resultOk = false;
      run.toolMap = run.toolMap || new Map();
      run.toolMap.set(block.id, b);
      if (block.name) updateToolBlock(b, block);
      if (!block.input) {
        b.statusEl.innerHTML = '<span class="spin"></span>';
        b.statusEl.className = 'tool-status';
      }
    }

    insertBlock(run, b);
    return b;
  }

  function historyBlock(body, block) {
    if (block.type === 'text') {
      const wrap = document.createElement('div');
      wrap.className = 'block text-block';
      const mdEl = document.createElement('div');
      mdEl.className = 'md';
      mdEl.innerHTML = md(block.text);
      wrap.appendChild(mdEl);
      body.appendChild(wrap);
    } else if (block.type === 'thinking') {
      const d = document.createElement('details');
      d.className = 'block thinking';
      d.innerHTML = `<summary>${ICON.chev}${ICON.spark}<span>思考</span><span class="cnt">${block.thinking.length} 字</span></summary><div class="think-body"></div>`;
      d.querySelector('.think-body').textContent = block.thinking;
      body.appendChild(d);
    } else if (block.type === 'tool_use') {
      const b = makeToolBlock(block);
      updateToolBlock(b, block);
      b.statusEl.className = 'tool-status ok';
      b.statusEl.textContent = '';
      if (block.result != null) {
        b.resultSec.hidden = false;
        b.resultEl.textContent = block.result || '（无输出）';
        b.resultSec.classList.toggle('err', !!block.isError);
        if (block.isError) {
          b.statusEl.className = 'tool-status err';
          b.statusEl.textContent = '失败';
        }
      } else {
        b.el.querySelector('.sec-input').hidden = b.inputEl.textContent === '';
      }
      body.appendChild(b.el);
    }
  }

  /** 历史里没有落盘费用时：token 从各条 assistant 消息的 usage 累加，时间用时间戳估算 */
  function deriveTurnMeta(msgs, userTs) {
    let usage = null;
    for (const m of msgs || []) {
      const u = m.usage;
      if (!u) continue;
      usage = usage || { input_tokens: 0, output_tokens: 0, cache_creation_input_tokens: 0, cache_read_input_tokens: 0 };
      usage.input_tokens += u.input_tokens || 0;
      usage.output_tokens += u.output_tokens || 0;
      usage.cache_creation_input_tokens += u.cache_creation_input_tokens || 0;
      usage.cache_read_input_tokens += u.cache_read_input_tokens || 0;
    }

    let duration = null;
    const last = msgs && msgs[msgs.length - 1];
    if (last && last.ts && userTs) {
      const d = new Date(last.ts).getTime() - new Date(userTs).getTime();
      if (isFinite(d) && d >= 0) duration = d;
    }

    if (!usage && duration == null) return null;
    return { usage, duration, ts: last && last.ts };
  }

  /** 同一过程块里可能有多轮 meta（插话被 CLI 拆成多轮时），合并成一份累计数据 */
  function mergeTurnMeta(msgs) {
    const metas = (msgs || []).map(m => m.meta).filter(Boolean);
    if (!metas.length) return null;
    if (metas.length === 1) return metas[0];
    const usage = { input_tokens: 0, output_tokens: 0, cache_creation_input_tokens: 0, cache_read_input_tokens: 0 };
    let duration = 0;
    for (const meta of metas) {
      const u = meta.usage || {};
      usage.input_tokens += u.input_tokens || 0;
      usage.output_tokens += u.output_tokens || 0;
      usage.cache_creation_input_tokens += u.cache_creation_input_tokens || 0;
      usage.cache_read_input_tokens += u.cache_read_input_tokens || 0;
      duration += meta.duration || 0;
    }
    return { duration, usage, ts: metas[metas.length - 1].ts };
  }

  function lastNonTextIndex(blocks) {
    let idx = -1;
    blocks.forEach((b, i) => {
      if (!b || b.type !== 'text') idx = i;
    });
    return idx;
  }

  function renderHistoryTurn(body, blocks, msgs, userTs, processThrough = 0, steers = [], compactPrior = 0, cutByCompact = false, compactTs = null) {
    // 过程中的临时结论收进「过程」；只有一整轮最后的文字作为最终结论露出来。
    // processThrough：插话之前的块数，保证插话前的内容不会被当成最终结论。
    const cut = Math.max(
      lastNonTextIndex(blocks),
      Math.min(processThrough, blocks.length) - 1
    );
    const processBlocks = cut >= 0 ? blocks.slice(0, cut + 1) : [];
    const finalBlocks = cut >= 0 ? blocks.slice(cut + 1) : blocks;

    const stored = mergeTurnMeta(msgs);
    const ownMeta = deriveTurnMeta(msgs, userTs);
    let meta = stored || ownMeta;

    if (cutByCompact) {
      // 压缩前的那一块：只保留本块的用时和命中率，不显示 tokens 和价钱
      meta = {
        duration: ownMeta ? ownMeta.duration : null,
        usage: ownMeta ? ownMeta.usage : null,
        ts: ownMeta ? ownMeta.ts : (meta && meta.ts),
        hideTokensCost: true
      };
    } else if (stored && compactPrior > 0) {
      // 压缩摘要把同一轮切成两块时，后一块会沿用整轮的累计记录。
      // 只有累计值 ≈ 本块用量 + 压缩前用量 才这样处理，续跑的新轮和并行子代理都不会误判。
      let own = 0;
      for (const m of msgs || []) own += usageTokenTotal(m.usage);
      const total = usageTokenTotal(stored.usage);
      const expected = own + compactPrior;
      if (total > 0 && Math.abs(total - expected) <= Math.max(5000, expected * 0.02)) {
        // tokens 和价钱用整轮累计，用时和命中率仍按本块自己的消息算
        let duration = ownMeta ? ownMeta.duration : null;
        const last = msgs && msgs[msgs.length - 1];
        if (duration == null && compactTs && last && last.ts) {
          const d = new Date(last.ts).getTime() - new Date(compactTs).getTime();
          if (isFinite(d) && d >= 0) duration = d;
        }
        meta = {
          duration,
          usage: ownMeta ? ownMeta.usage : null,
          ts: stored.ts,
          totals: stored.usage
        };
      }
    }

    if (processBlocks.length) {
      // 正常收尾且没有最终结论（例如停在工具调用上）时保持展开，避免整轮只剩一个空壳；
      // 被压缩打断的那一块不算正常收尾，打开对话时默认收起。
      const act = buildActivityEl(finalBlocks.length === 0 && !cutByCompact);
      act.el.classList.remove('live');
      act.state.innerHTML = '';
      // 展开时插话回到原来的步骤位置
      let si = 0;
      for (let i = 0; i < processBlocks.length; i++) {
        while (si < steers.length && steers[si].at <= i) {
          act.body.appendChild(makeSteerWrap(steers[si].text, steers[si].images));
          si++;
        }
        historyBlock(act.body, processBlocks[i]);
      }
      while (si < steers.length) {
        act.body.appendChild(makeSteerWrap(steers[si].text, steers[si].images));
        si++;
      }
      const steps = processBlocks.filter(b => b.type === 'thinking' || b.type === 'tool_use').length;
      const files = aggregateEdits(historyEditRecords(processBlocks)).length;
      setActivitySummary(act, steps, files);
      setActivityMeta(act, meta);
      body.appendChild(act.el);

      // 收起时插话显示在过程块上方；展开时上面这份隐藏，内部那份显示
      const summaries = [];
      for (const s of steers) {
        const wrap = makeSteerWrap(s.text, s.images);
        wrap.classList.add('steer-summary');
        summaries.push(wrap);
        body.insertBefore(wrap, act.el);
      }
      if (summaries.length) {
        const sync = () => {
          for (const w of summaries) w.style.display = act.el.open ? 'none' : '';
        };
        sync();
        act.el.addEventListener('toggle', sync);
      }

      for (const b of finalBlocks) historyBlock(body, b);
    } else if (steers.length) {
      // 纯文字轮次：插话直接留在原来的文字位置
      let si = 0;
      for (let i = 0; i < blocks.length; i++) {
        while (si < steers.length && steers[si].at <= i) {
          body.appendChild(makeSteerWrap(steers[si].text, steers[si].images));
          si++;
        }
        historyBlock(body, blocks[i]);
      }
      while (si < steers.length) {
        body.appendChild(makeSteerWrap(steers[si].text, steers[si].images));
        si++;
      }
    } else {
      for (const b of finalBlocks) historyBlock(body, b);
    }

    const finalText = finalBlocks.filter(b => b.type === 'text').map(b => b.text || '').join(String.fromCharCode(10));
    const artifacts = extractArtifactPaths(finalText);
    if (artifacts.length) body.appendChild(buildArtifactCard(artifacts));

    const files = aggregateEdits(historyEditRecords(blocks));
    if (files.length) body.appendChild(buildEditCard(files));

    // 纯文字轮次没有过程行，统计放到最下面
    if (!processBlocks.length && meta) {
      const info = turnMetaInfo(meta);
      if (info) {
        const line = document.createElement('div');
        line.className = 'run-meta';
        line.textContent = info.text;
        bindMetaTip(line, info);
        body.appendChild(line);
      }
    }
  }

  function renderHistory(messages) {
    hideSelectionToolbar();
    S.scrollGuardUntil = Date.now() + 250;
    messagesEl.innerHTML = '';
    resetChatTime();
    let turn = null;
    let curUserTs = null;
    let processThrough = 0;
    let afterCompact = false;
    let compactPriorTokens = 0;
    let lastCompactTs = null;

    const flush = () => {
      if (turn) {
        renderHistoryTurn(
          turn.body, turn.blocks, turn.msgs, turn.userTs, processThrough,
          turn.steers, turn.compactPrior, turn.cutByCompact, turn.compactTs
        );
      }
      turn = null;
      processThrough = 0;
    };

    for (const m of messages) {
      if (m.role === 'user') {
        if (isCompactSummaryMessage(m)) {
          // 压缩摘要本身不显示成大段用户消息，只留一条分隔提示。
          // 记下被压缩掉的这一块的用量，用于判断下一页是否沿用了整轮累计。
          let prior = 0;
          if (turn) {
            turn.cutByCompact = true;
            for (const mm of turn.msgs) prior += usageTokenTotal(mm.usage);
          }
          compactPriorTokens += prior;
          flush();
          addCompactDivider();
          curUserTs = null;
          processThrough = 0;
          afterCompact = true;
          lastCompactTs = m.ts || null;
          continue;
        }
        if (m.steer) {
          // 插话交给过程块处理：展开时在原步骤位置，收起时在过程块上方
          if (turn) {
            turn.steers.push({ text: m.text, images: m.images, at: turn.blocks.length });
            processThrough = turn.blocks.length;
            noteChatActivityTime(m.ts);
          } else {
            maybeAddChatTime(m.ts);
            addUserBubble(m.text, m.images, { steer: true });
            curUserTs = m.ts;
          }
        } else {
          flush();
          maybeAddChatTime(m.ts);
          addUserBubble(m.text, m.images);
          curUserTs = m.ts;
          processThrough = 0;
          afterCompact = false;
          compactPriorTokens = 0;
        }
      } else {
        if (!turn) {
          const el = createAssistantEl();
          turn = {
            row: el.row, body: el.body, blocks: [], msgs: [], userTs: curUserTs, steers: [],
            compactPrior: afterCompact ? compactPriorTokens : 0,
            compactTs: afterCompact ? lastCompactTs : null
          };
        }
        turn.msgs.push(m);
        for (const b of m.blocks || []) turn.blocks.push(b);
      }
    }
    flush();

    // 用最后一条 assistant 消息的输入量估算当前上下文占用。
    // 遇到压缩摘要时从 0 重新算，避免把压缩前的高占用带到压缩后。
    let ctx = 0;
    for (const m of messages) {
      if (m.role === 'user' && isCompactSummaryMessage(m)) {
        ctx = 0;
        continue;
      }
      if (m.role === 'assistant' && m.usage) {
        const t = usageContextTokens(m.usage);
        if (t) ctx = t;
      }
    }
    S.contextTokens = ctx;
    updateContextBadge();

    if (!messages.length) renderEmpty();
    scheduleProcessCollapseUpdate();
  }

  function renderEmpty() {
    const inConv = !!S.conv;
    const folder = inConv ? S.conv.cwd : S.currentFolder;
    messagesEl.innerHTML = `
      <div class="empty">
        <div class="empty-mark">✳</div>
        <h1>${inConv ? '开始对话' : '今天做点什么？'}</h1>
        <p>${inConv
          ? '在下面的输入框里写下任务，Enter 发送。'
          : (folder ? '在当前文件夹里开一段新对话，或者先换一个文件夹。' : '先选一个工作文件夹，然后开始。')}</p>
        ${folder ? `<div class="folder-line">当前文件夹 <code>${escapeHtml(folder)}</code></div>` : ''}
        ${inConv ? '' : `<div class="empty-actions">
          <button class="btn primary" data-act="pick">选择文件夹</button>
          ${folder ? '<button class="btn" data-act="new">新建对话</button>' : ''}
        </div>`}
        <div class="empty-tips"><kbd>Enter</kbd> 发送 · <kbd>Shift</kbd>+<kbd>Enter</kbd> 换行 · <kbd>Ctrl</kbd>+<kbd>N</kbd> 新对话</div>
      </div>`;
    scheduleProcessCollapseUpdate();
  }

  // ------------------------------------------------------------ 滚动

  // 只有真的贴到底部才继续跟随。留 8px 给缩放/小数滚动，避免差一像素就不跟随。
  const STICK_BOTTOM_PX = 8;

  function nearBottom() {
    return transcriptEl.scrollHeight - transcriptEl.scrollTop - transcriptEl.clientHeight <= STICK_BOTTOM_PX;
  }

  function scrollToBottom(force) {
    if (!force && !S.stick) return;
    requestAnimationFrame(() => {
      // 排队期间用户可能已经往上滚了。无论是流式输出还是用户刚发消息，
      // 只要已经离开底部，这次滚动就让位，不能把用户拽回去。
      if (!S.stick) return;
      transcriptEl.scrollTop = transcriptEl.scrollHeight;
    });
  }

  function updateScrollDownBtn() {
    const btn = $('#scrollDown');
    btn.hidden = S.stick || transcriptEl.scrollHeight <= transcriptEl.clientHeight + 20;
    if (!btn.hidden) updateScrollDownPosition();
  }

  function markUserScrolledUp() {
    if (!S.stick) return;
    S.stick = false;
    updateScrollDownBtn();
  }

  let lastScrollTop = transcriptEl.scrollTop;
  let lastTouchY = 0;

  // 只要用户有向上滚的动作就立刻停止自动跟随，不再等滚出 140px 才解除
  transcriptEl.addEventListener('wheel', e => {
    if (e.deltaY < 0) markUserScrolledUp();
  }, { passive: true });
  transcriptEl.addEventListener('touchstart', e => {
    const t = e.touches && e.touches[0];
    if (t) lastTouchY = t.clientY;
  }, { passive: true });
  transcriptEl.addEventListener('touchmove', e => {
    const t = e.touches && e.touches[0];
    if (!t) return;
    if (t.clientY > lastTouchY + 2) markUserScrolledUp();
    lastTouchY = t.clientY;
  }, { passive: true });

  transcriptEl.addEventListener('scroll', () => {
    const top = transcriptEl.scrollTop;
    // 内容/状态行更新可能让 scrollTop 抖 1~2px；这不是用户上滑，不能因此关掉跟随。
    // 真正的滚轮/触摸上滑已经由上面的 wheel/touch 监听立刻处理；这里只兜底滚动条拖动。
    const goingUp = top < lastScrollTop - 12;
    lastScrollTop = top;
    // renderHistory 重建或自动进度行增删时浏览器也会发 scroll；保护窗口内不改变跟随状态。
    if (Date.now() < S.scrollGuardUntil) {
      if (!goingUp && nearBottom()) S.stick = true;
      updateScrollDownBtn();
      scheduleProcessCollapseUpdate();
      return;
    }
    if (goingUp) S.stick = false;
    else if (nearBottom()) S.stick = true;
    updateScrollDownBtn();
    scheduleProcessCollapseUpdate();
  });

  $('#scrollDown').addEventListener('click', () => {
    S.stick = true;
    transcriptEl.scrollTop = transcriptEl.scrollHeight;
    $('#scrollDown').hidden = true;
  });

  /** 输入框/面板变高时，把“回到底部”按钮顶到输入区上方，避免落进输入框里 */
  function updateScrollDownPosition() {
    const btn = $('#scrollDown');
    const wrap = document.querySelector('.composer-wrap');
    const parent = btn && btn.parentElement; // .main：即使按钮 hidden 也能量到包含块
    if (!btn || !wrap || !parent) return;
    const p = parent.getBoundingClientRect();
    const w = wrap.getBoundingClientRect();
    btn.style.bottom = Math.max(8, Math.round(p.bottom - w.top + 10)) + 'px';
  }
  updateScrollDownPosition();
  window.addEventListener('resize', updateScrollDownPosition);
  if (typeof ResizeObserver === 'function') {
    const composerWrap = document.querySelector('.composer-wrap');
    if (composerWrap) new ResizeObserver(updateScrollDownPosition).observe(composerWrap);
  }

  // 兜底：任何内容高度变化（自动进度、工具块、图片加载等）都补一次贴底。
  // 只在用户本来就停在底部时生效；用户上滚后不会被拽回去。
  if (typeof ResizeObserver === 'function') {
    let followRaf = 0;
    const followObserver = new ResizeObserver(() => {
      if (!S.stick || followRaf) return;
      followRaf = requestAnimationFrame(() => {
        followRaf = 0;
        if (S.stick) transcriptEl.scrollTop = transcriptEl.scrollHeight;
      });
    });
    followObserver.observe(messagesEl);
    // 输入区/状态栏变高会压缩消息区可视高度，同样要补一次贴底。
    followObserver.observe(transcriptEl);
  }

  // ------------------------------------------------------------ 浮动的「收起过程」

  let processCollapseTarget = null;
  let processCollapseRaf = 0;

  function ensureProcessCollapseButton() {
    let btn = document.getElementById('processCollapseBtn');
    if (btn) return btn;
    btn = document.createElement('button');
    btn.id = 'processCollapseBtn';
    btn.type = 'button';
    btn.className = 'process-collapse-btn';
    btn.hidden = true;
    btn.title = '收起上方已经滑出视口的过程';
    btn.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 15l6-6 6 6"/></svg><span>收起</span>';
    btn.addEventListener('click', collapseProcessAbove);
    const host = document.querySelector('.main') || document.body;
    host.appendChild(btn);
    return btn;
  }

  /** 找最靠近当前视口、且标题已经滑到聊天区上方的展开过程 */
  function findProcessToCollapse() {
    const top = transcriptEl.getBoundingClientRect().top;
    const acts = messagesEl.querySelectorAll('details.activity[open]');
    let lastVisibleAbove = null;
    for (const el of acts) {
      if (!el.classList.contains('has-process')) continue;
      const summary = el.querySelector(':scope > summary');
      if (!summary) continue;
      if (summary.getBoundingClientRect().bottom > top + 4) continue;
      // 过程框整体已经滑出视口上方后，不再显示按钮；只收起仍有一截在视口里的过程。
      if (el.getBoundingClientRect().bottom <= top + 4) continue;
      lastVisibleAbove = el;
    }
    return lastVisibleAbove;
  }

  function updateProcessCollapseButton() {
    const btn = ensureProcessCollapseButton();
    processCollapseTarget = findProcessToCollapse();
    btn.hidden = !processCollapseTarget;
    if (!processCollapseTarget) return;

    // 贴在当前展开过程框的左侧，而不是固定在整个聊天区的最左边。
    // 窗口变窄、内容居中或侧栏变化时，每次滚动/重排都会重新计算。
    const host = btn.parentElement;
    const hostRect = host.getBoundingClientRect();
    const actRect = processCollapseTarget.getBoundingClientRect();
    btn.classList.remove('compact');
    const actLeft = actRect.left - hostRect.left;
    // 一直在过程框外侧；左边空间不够时只留箭头，不再塞进过程框里面。
    let btnWidth = btn.offsetWidth || 65;
    let left = actLeft - btnWidth - 4;
    if (left < 2) {
      btn.classList.add('compact');
      btnWidth = btn.offsetWidth || 30;
      left = actLeft - btnWidth - 4;
    }
    left = Math.max(2, Math.min(hostRect.width - btnWidth - 2, left));
    // 空间再紧也不把按钮塞进过程框：右边缘最多停在框的左边界外。
    left = Math.min(left, actLeft - btnWidth - 4);
    left = Math.max(2, left);
    btn.style.left = Math.round(left) + 'px';

    // 垂直方向默认靠下（主区 70%），但不能跑到展开过程框的底部下面。
    // 过程框底部已经滑到视口上方时，按钮跟着框底走；否则至少留在视口内。
    const trRect = transcriptEl.getBoundingClientRect();
    const btnHeight = btn.offsetHeight || 30;
    const gap = 8;
    const desired = hostRect.top + hostRect.height * 0.70;
    const minCenter = Math.max(actRect.top, trRect.top) + gap + btnHeight / 2;
    const maxCenter = Math.min(actRect.bottom, trRect.bottom) - gap - btnHeight / 2;
    let center = desired;
    if (maxCenter > minCenter) center = Math.max(minCenter, Math.min(maxCenter, center));
    else center = Math.max(trRect.top + gap + btnHeight / 2, Math.min(desired, actRect.bottom - gap - btnHeight / 2));
    btn.style.top = Math.round(center - hostRect.top) + 'px';
  }

  function scheduleProcessCollapseUpdate() {
    if (processCollapseRaf) return;
    processCollapseRaf = requestAnimationFrame(() => {
      processCollapseRaf = 0;
      updateProcessCollapseButton();
    });
  }

  function collapseProcessAbove() {
    const target = processCollapseTarget;
    if (!target || !target.open || !target.isConnected) {
      scheduleProcessCollapseUpdate();
      return;
    }
    const top = transcriptEl.getBoundingClientRect().top;
    const rect = target.getBoundingClientRect();
    const inside = rect.bottom > top + 4;
    const beforeScroll = transcriptEl.scrollTop;
    const beforeHeight = transcriptEl.scrollHeight;

    target.open = false;
    requestAnimationFrame(() => {
      if (inside) {
        // 用户正滑在过程正文里：收起后把过程标题带到视口顶部，避免停在空白处
        const summary = target.querySelector(':scope > summary');
        if (summary) {
          const delta = summary.getBoundingClientRect().top - top - 8;
          transcriptEl.scrollTop = Math.max(0, transcriptEl.scrollTop + delta);
        }
      } else {
        // 过程整体在视口上方：把下方内容按被移除的高度补偿回来，保持当前位置
        const removed = Math.max(0, beforeHeight - transcriptEl.scrollHeight);
        transcriptEl.scrollTop = Math.max(0, beforeScroll - removed);
      }
      scheduleProcessCollapseUpdate();
    });
  }

  window.addEventListener('resize', scheduleProcessCollapseUpdate);
  window.addEventListener('resize', refreshSelectDisplay);

  // ------------------------------------------------------------ 侧栏

  function convMatches(c, q) {
    if (!q) return true;
    return (c.title || '').toLowerCase().includes(q) || (c.preview || '').toLowerCase().includes(q);
  }

  // 未发过消息的新对话永远排在最前（最新创建的在前）；已发消息的再按更新时间排。
  // 服务端也按同样规则排序，这里再排一次，保证 SSE 增量更新时侧栏顺序也立即正确。
  function isFreshConv(c) {
    return !!(c && (c.placeholder || c.turns === 0));
  }

  function compareConvOrder(a, b) {
    const an = isFreshConv(a);
    const bn = isFreshConv(b);
    if (an !== bn) return an ? -1 : 1;
    const at = new Date(an ? (a.createdAt || a.updatedAt || 0) : (a.updatedAt || 0)).getTime();
    const bt = new Date(bn ? (b.createdAt || b.updatedAt || 0) : (b.updatedAt || 0)).getTime();
    return (isFinite(bt) ? bt : 0) - (isFinite(at) ? at : 0);
  }

  /** 当前对话刚发出第一条消息：立即降级到「已开始」分组，不必等下一次 bootstrap */
  function markConversationStarted(id) {
    if (!id) return;
    for (const f of S.folders) {
      const c = (f.conversations || []).find(x => x.id === id);
      if (!c) continue;
      c.placeholder = false;
      c.turns = Math.max(1, Number(c.turns) || 0);
      c.updatedAt = new Date().toISOString();
    }
    if (S.conv && S.conv.id === id) {
      S.conv.turns = Math.max(1, Number(S.conv.turns) || 0);
    }
  }

  // ------------------------------------------------------------ 侧栏预览

  function savePreviewOverrides() {
    try {
      localStorage.setItem('convPreviews', JSON.stringify(Object.fromEntries(S.previewOverrides)));
    } catch { /* 存不下就算了，本次会话内仍然有效 */ }
  }

  function applyPreviewOverrides() {
    if (!S.previewOverrides.size) return;
    for (const f of S.folders) {
      for (const c of f.conversations || []) {
        const p = S.previewOverrides.get(c.id);
        if (p) c.preview = p;
      }
    }
  }

  /** 历史消息里最后一条助手正文（用于打开对话时修正侧栏预览） */
  function lastAssistantText(messages) {
    const list = messages || [];
    let lastUser = -1;
    list.forEach((m, i) => { if (m && m.role === 'user' && !m.steer) lastUser = i; });
    for (let i = list.length - 1; i > lastUser; i--) {
      const m = list[i];
      if (!m || m.role !== 'assistant') continue;
      const texts = (m.blocks || []).filter(b => b.type === 'text' && b.text && b.text.trim());
      if (texts.length) return texts[texts.length - 1].text.trim();
    }
    return '';
  }

  /** 把侧栏里某个对话的预览改成指定文字（任务完成后传助手结论） */
  function setConvPreview(id, text) {
    if (!id) return;
    const clean = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 90);
    if (!clean) return;
    S.previewOverrides.set(id, clean);
    savePreviewOverrides();
    applyPreviewOverrides();
    renderFolders();
  }

  function renderFolders() {
    applyPreviewOverrides();
    const list = $('#folderList');
    const scrollTop = list.scrollTop;
    list.innerHTML = '';
    const q = (S.search || '').trim().toLowerCase();
    let shown = 0;

    for (const f of S.folders) {
      const convs = (f.conversations || []).filter(c => convMatches(c, q)).sort(compareConvOrder);
      if (q && !convs.length) continue;
      shown++;

      const collapsed = !q && S.collapsed.has(f.path);
      const sec = document.createElement('div');
      sec.className = 'folder';

      const head = document.createElement('div');
      head.className = 'folder-head' + (collapsed ? ' collapsed' : '') +
        (S.currentFolder && S.currentFolder.toLowerCase() === f.path.toLowerCase() ? ' active-folder' : '');
      head.innerHTML = `
        ${ICON.chev}${ICON.folder}
        <span class="fname">${escapeHtml(f.name)}</span>
        <span class="count">${convs.length}</span>
        <button class="fbtn" data-new title="在此文件夹新建对话">${ICON.plus}</button>
        <button class="fbtn" data-menu title="更多">${ICON.dots}</button>`;
      head.title = f.path;

      head.addEventListener('click', e => {
        const newBtn = e.target.closest('[data-new]');
        const menuBtn = e.target.closest('[data-menu]');
        if (newBtn) { e.stopPropagation(); newChat(f.path); return; }
        if (menuBtn) {
          e.stopPropagation();
          const r = menuBtn.getBoundingClientRect();
          showMenu(r.left - 130, r.bottom + 4, [
            { label: '在资源管理器中打开', icon: ICON.external, onClick: () => revealPath(f.path) },
            { sep: true },
            { label: '从列表中移除', icon: ICON.trash, danger: true, onClick: () => removeFolder(f.path) }
          ]);
          return;
        }
        S.currentFolder = f.path;
        if (q) { /* 搜索时忽略折叠 */ }
        else {
          if (S.collapsed.has(f.path)) S.collapsed.delete(f.path);
          else S.collapsed.add(f.path);
          localStorage.setItem('collapsedFolders', JSON.stringify([...S.collapsed]));
        }
        renderFolders();
        updateChrome();
      });

      const bodyEl = document.createElement('div');
      bodyEl.className = 'folder-body';
      if (!collapsed) {
        if (!f.exists) {
          const note = document.createElement('div');
          note.className = 'folder-foot-note';
          note.textContent = '文件夹不存在或已被移动';
          bodyEl.appendChild(note);
        } else if (!convs.length) {
          const note = document.createElement('div');
          note.className = 'folder-foot-note';
          note.textContent = q ? '没有匹配的对话' : '暂无对话';
          bodyEl.appendChild(note);
        } else {
          for (const c of convs) {
            bodyEl.appendChild(convRow(c));
          }
        }
      }

      sec.appendChild(head);
      sec.appendChild(bodyEl);
      list.appendChild(sec);
    }

    if (!shown) {
      list.innerHTML = `<div class="sb-empty">${q ? '没有找到匹配的对话' : '还没有任何对话<br>点击上方「新对话」开始'}</div>`;
    }
    list.scrollTop = scrollTop;
  }

  function convRow(c) {
    const row = document.createElement('div');
    row.className = 'conv' + (S.conv && S.conv.id === c.id ? ' active' : '');
    row.dataset.id = c.id;

    const running = S.runningIds.has(c.id) || (S.conv && S.conv.id === c.id && S.running);
    const sub = [timeAgo(c.updatedAt), c.preview].filter(Boolean);

    const asking = S.askIds.has(c.id);
    const unread = !asking && S.attention.has(c.id);
    row.innerHTML = `
      <div class="conv-title">${escapeHtml(c.title || '新对话')}${asking ? '<span class="ask-dot" title="Claude 在等你回答">?</span>' : (unread ? '<span class="unread-dot" title="有新的完成或待处理"></span>' : '')}</div>
      <div class="conv-sub">
        ${running ? '<span class="run-dot"></span>' : ''}
        <span>${escapeHtml(sub[0] || '')}</span>
        ${sub[1] ? `<span class="sep">·</span><span class="preview">${escapeHtml(sub[1])}</span>` : ''}
      </div>
      <button class="conv-menu" title="更多">${ICON.dots}</button>`;

    row.addEventListener('click', e => {
      if (e.target.closest('.conv-menu')) return;
      openConversation(c.id);
    });

    row.querySelector('.conv-menu').addEventListener('click', e => {
      e.stopPropagation();
      const r = e.currentTarget.getBoundingClientRect();
      showMenu(r.left - 150, r.bottom + 4, [
        { label: '重命名', icon: ICON.pencil, onClick: () => renameConv(c) },
        { label: '在资源管理器中打开', icon: ICON.external, onClick: () => revealPath(c.cwd || (S.conv && S.conv.cwd)) },
        { sep: true },
        { label: '删除对话', icon: ICON.trash, danger: true, onClick: () => deleteConv(c) }
      ]);
    });

    return row;
  }

  function showMenu(x, y, items, opts = {}) {
    closeMenu();
    const m = document.createElement('div');
    m.className = 'menu';
    if (opts.keepFocus) m.addEventListener('mousedown', e => e.preventDefault());
    for (const it of items) {
      if (it.sep) { m.appendChild(document.createElement('hr')); continue; }
      const b = document.createElement('button');
      if (it.danger) b.className = 'danger';
      b.disabled = !!it.disabled;
      const hint = it.hint ? `<span class="menu-hint">${escapeHtml(it.hint)}</span>` : '';
      b.innerHTML = `${it.icon || ''}<span>${escapeHtml(it.label)}</span>${hint}`;
      b.addEventListener('click', () => { closeMenu(); it.onClick(); });
      m.appendChild(b);
    }
    document.body.appendChild(m);
    const r = m.getBoundingClientRect();
    const PAD = 8, GAP = 2;
    let left = x + GAP;
    let top = y + GAP;
    // 默认出现在指针右下角；下方/右侧放不下时翻到上方/左侧
    if (left + r.width + PAD > innerWidth) left = Math.max(PAD, x - r.width - GAP);
    if (top + r.height + PAD > innerHeight) top = Math.max(PAD, y - r.height - GAP);
    m.style.left = left + 'px';
    m.style.top = top + 'px';
    S.menuEl = m;

    setTimeout(() => {
      const onDoc = ev => { if (!m.contains(ev.target)) closeMenu(); };
      document.addEventListener('mousedown', onDoc, true);
      S.menuDocHandler = onDoc;
    }, 0);
  }

  function closeMenu() {
    if (S.menuEl) { S.menuEl.remove(); S.menuEl = null; }
    if (S.menuDocHandler) {
      document.removeEventListener('mousedown', S.menuDocHandler, true);
      S.menuDocHandler = null;
    }
  }

  async function revealPath(p) {
    if (!p) return;
    try { await api('/reveal', { method: 'POST', body: JSON.stringify({ path: p }) }); }
    catch (e) { toast(e.message, 'error'); }
  }

  // ------------------------------------------------------------ 输入弹窗
  // Electron 不支持 window.prompt()（调用会直接返回 null），重命名必须用自己的弹窗

  let promptState = null;

  function askText({ title, value = '', note = '', okText = '确定', placeholder = '' } = {}) {
    if (promptState) return Promise.resolve(null);
    return new Promise(resolve => {
      promptState = { resolve };
      $('#promptTitle').textContent = title || '输入';
      const input = $('#promptInput');
      input.value = value;
      input.placeholder = placeholder;
      $('#promptNote').textContent = note;
      $('#promptNote').hidden = !note;
      $('#promptOk').textContent = okText;
      $('#promptModal').hidden = false;
      requestAnimationFrame(() => { input.focus(); input.select(); });
    });
  }

  function closeAskText(value) {
    if (!promptState) return;
    $('#promptModal').hidden = true;
    const { resolve } = promptState;
    promptState = null;
    resolve(value);
  }

  async function renameConv(c) {
    const name = await askText({
      title: '重命名对话',
      value: c.title || '',
      note: '留空则由 AI 根据对话内容自动生成标题',
      okText: '保存'
    });
    if (name === null) return;
    const title = name.trim();
    if (title === (c.title || '').trim()) return;
    try {
      await api('/conversation?id=' + encodeURIComponent(c.id), {
        method: 'PATCH',
        body: JSON.stringify({ title })
      });
      if (S.conv && S.conv.id === c.id) S.conv.title = title || null;
      await refreshBoot();
      updateChrome();
      if (title) toast('已重命名');
    } catch (e) { toast(e.message, 'error'); }
  }

  async function deleteConv(c) {
    if (!confirm(`删除对话「${c.title || '新对话'}」？\n\n会话记录会一并删除，无法恢复。`)) return;
    try {
      await api('/conversation?id=' + encodeURIComponent(c.id), { method: 'DELETE' });
      S.drafts.delete(c.id);
      S.previewOverrides.delete(c.id);
      savePreviewOverrides();
      if (S.conv && S.conv.id === c.id) {
        S.conv = null;
        S.running = false;
        S.currentRun = null;
        localStorage.removeItem('lastConversation');
        history.replaceState(null, '', location.pathname);
        renderHistory([]);
      }
      await refreshBoot();
      updateChrome();
      updateComposerState();
      toast('已删除');
    } catch (e) { toast(e.message, 'error'); }
  }

  async function removeFolder(p) {
    if (!confirm(`从列表中移除「${p}」？\n\n对话记录不会被删除，只是不再显示。`)) return;
    try {
      await api('/folder?path=' + encodeURIComponent(p), { method: 'DELETE' });
      if (S.currentFolder === p) S.currentFolder = null;
      await refreshBoot();
      updateChrome();
    } catch (e) { toast(e.message, 'error'); }
  }

  // ------------------------------------------------------------ 输入草稿（按对话隔离）

  const DRAFT_NEW = '__new__';

  function draftKey() {
    return (S.conv && S.conv.id) || DRAFT_NEW;
  }

  /** 把当前输入框、待发图片和引用记到当前对话名下 */
  function saveComposerDraft() {
    const key = draftKey();
    const draft = {
      text: inputEl.value,
      images: S.pendingImages.slice(),
      files: S.pendingFiles.slice(),
      refs: S.pendingRefs.slice(),
      quotes: S.pendingQuotes.slice()
    };
    if (!draft.text && !draft.images.length && !draft.files.length && !draft.refs.length && !draft.quotes.length) S.drafts.delete(key);
    else S.drafts.set(key, draft);
  }

  /** 切到某个对话时恢复它自己的草稿；没有草稿就清空输入框 */
  function restoreComposerDraft(id) {
    const draft = id ? S.drafts.get(id) : null;
    inputEl.value = draft ? draft.text : '';
    S.pendingImages = draft ? draft.images.slice() : [];
    S.pendingFiles = draft && Array.isArray(draft.files) ? draft.files.slice() : [];
    S.pendingRefs = draft ? draft.refs.slice() : [];
    S.pendingQuotes = draft && Array.isArray(draft.quotes) ? draft.quotes.slice() : [];
    S.refSel = new Map(S.pendingRefs.map(r => [r.id, r]));
    renderAttachments();
    autoGrow();
    updateComposerState();
  }

  // ------------------------------------------------------------ 打开对话

  async function openConversation(id, opts = {}) {
    if (!id) return;
    // 先保存当前对话的草稿，再切走；新建对话发送时用 keepComposer 保留输入框内容
    if (!opts.keepComposer) saveComposerDraft();
    const seq = ++S.loadSeq;
    // 切换期间到达的 SSE 事件先存起来，等快照渲染完再补上（避免丢 token / 丢插话）
    const switchBuf = { id, events: [] };
    S.switchBuf = switchBuf;
    try {
      const conv = await api('/conversation?id=' + encodeURIComponent(id));
      if (seq !== S.loadSeq) {
        if (S.switchBuf === switchBuf) S.switchBuf = null;
        return;
      }

      const live = conv.running && conv.live && Array.isArray(conv.live.users) ? conv.live : null;
      const prevConvId = S.conv && S.conv.id;
      S.conv = conv;
      S.conv.compacted = !!conv.compacted;
      // 重新打开会话时按历史压缩摘要数量还原次数，避免弹窗总说“压缩过 1 次”
      const summaryCount = (conv.messages || []).filter(m =>
        m && m.role === 'user' && isCompactSummaryMessage(m)
      ).length;
      S.ctxEpoch = summaryCount || (conv.compacted ? 1 : 0);
      if (prevConvId !== conv.id) {
        S.guardWarned = false;
        S.guardStopRequested = false;
        S.guardStopConvId = null;
        S.guardAutoResumeCount = 0;
      }
      S.currentFolder = conv.cwd;
      S.running = !!conv.running;
      if (conv.running) S.runningIds.add(id); else S.runningIds.delete(id);
      // 切走期间手动 /compact 已经结束的话，清掉残留标记，避免下一轮误把上下文重置成 0
      if (!conv.running && S.manualCompact && S.manualCompactConvId === id) {
        S.manualCompact = false;
        S.manualCompactConvId = null;
      }
      S.currentRun = null;
      S.stick = true;
      S.joinedMidRun = !!conv.running;
      hidePermission();
      hideAsk();
      if (!document.hidden) attentionRemove(id);
      if (live && live.ask) S.askIds.add(id); else S.askIds.delete(id);
      localStorage.setItem('lastConversation', id);
      history.replaceState(null, '', '#/c/' + id);

      renderHistory(live ? trimHistoryForLive(conv.messages || [], live) : (conv.messages || []));
      // 打开已结束的对话时，顺手把侧栏预览修正成最后一条助手结论
      if (!conv.running) {
        const lastText = lastAssistantText(conv.messages || []);
        if (lastText) setConvPreview(id, lastText);
      }
      // 新服务会返回压缩后的真实占用；旧服务没有这个字段，退回 renderHistory 的估算
      if (conv.compacted) {
        S.contextTokens = (typeof conv.contextTokens === 'number' && conv.contextTokens > 0) ? conv.contextTokens : 0;
        updateContextBadge();
      }
      if (live) renderLiveRun(live);
      else if (conv.running) ensureRun();
      renderFolders();
      updateChrome();
      updateComposerState();
      if (!opts.keepComposer) restoreComposerDraft(id);
      scrollToBottom(true);
      closeSidebarMobile();
      inputEl.focus();

      // 补上切换期间收到的增量事件
      if (S.switchBuf === switchBuf) S.switchBuf = null;
      if (S.conv && S.conv.id === id) {
        const minSeq = live && typeof live.seq === 'number' ? live.seq : 0;
        for (const ev of switchBuf.events) {
          if (ev.convId !== id) continue;
          if (live && typeof ev.seq === 'number' && ev.seq <= minSeq) continue;
          handleEvent(ev);
        }
      }
    } catch (e) {
      if (S.switchBuf === switchBuf) S.switchBuf = null;
      toast(e.message, 'error');
      if (String(e.message).includes('不存在')) {
        localStorage.removeItem('lastConversation');
        history.replaceState(null, '', location.pathname);
        S.conv = null;
        renderHistory([]);
        updateChrome();
      }
    }
  }

  // ------------------------------------------------------------ 新对话

  async function newChat(folderPath) {
    // 允许在当前对话运行期间新开对话：每个对话在服务端有独立的 Runner，
    // 旧对话会继续在后台跑，侧栏用运行圆点提示进度。
    let cwd = folderPath || S.currentFolder || (S.conv && S.conv.cwd) || null;
    if (!cwd) {
      cwd = await chooseFolder();
      if (!cwd) return;
    }
    try {
      const conv = await api('/conversation', { method: 'POST', body: JSON.stringify({ cwd }) });
      await refreshBoot();
      await openConversation(conv.id);
      inputEl.focus();
    } catch (e) {
      toast(e.message, 'error');
    }
  }

  /** 从 850K 提醒按钮开新对话：只带旧对话的摘要+最近内容，不重发整段长上下文 */
  async function startHandoffConversation() {
    if (!S.conv) return;
    if (S.running || S.compacting || S.cliCompacting) {
      toast('当前这一轮还在运行，等结束后再试');
      return;
    }
    const old = S.conv;
    const oldRef = {
      id: old.id,
      title: old.title || '未命名对话',
      cwd: old.cwd,
      updatedAt: old.updatedAt || new Date().toISOString(),
      turns: 0
    };
    saveComposerDraft();
    try {
      const conv = await api('/conversation', { method: 'POST', body: JSON.stringify({ cwd: old.cwd }) });
      await refreshBoot();
      await openConversation(conv.id, { keepComposer: true });
      // openConversation 会恢复新对话的空草稿，引用要放在它之后
      S.pendingRefs = [oldRef];
      S.refSel = new Map([[oldRef.id, oldRef]]);
      renderAttachments();
      if (!inputEl.value.trim()) inputEl.value = '继续之前的工作：';
      autoGrow();
      updateComposerState();
      inputEl.focus();
      toast('已新建对话并引用上一个对话的摘要与最近内容；接着输入下一步任务即可');
    } catch (e) {
      toast(e.message, 'error');
    }
  }

  async function chooseFolder(start) {
    const p = await pickFolder(start || S.currentFolder);
    if (!p) return null;
    try {
      await api('/folder', { method: 'POST', body: JSON.stringify({ path: p }) });
      S.currentFolder = p;
      await refreshBoot();
      updateChrome();
      return p;
    } catch (e) {
      toast(e.message, 'error');
      return null;
    }
  }

  // ------------------------------------------------------------ 1.1.0 自动压缩 / 引用对话 / 技能与 MCP

  function fmtBytes(n) {
    n = Number(n) || 0;
    if (n < 1024) return n + ' B';
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1024 / 1024).toFixed(1) + ' MB';
  }

  function shouldAutoCompact(text) {
    if (!S.conv || S.running || S.compacting) return false;
    if (text && text.startsWith('/')) return false;
    return S.contextTokens >= AUTO_COMPACT_AT;
  }

  function runAutoCompact(opts = {}) {
    if (S.compacting || !S.conv) return Promise.resolve(false);
    S.compacting = true;
    S.compactConvId = S.conv.id;
    S.compactPostTokens = 0;
    updateComposerState();
    syncCompactionProgress();
    setStatus('上下文接近上限，正在压缩…', 'warn');
    toast('上下文接近上限，正在自动压缩…');
    return new Promise(resolve => {
      let done = false;
      let timer = 0;
      const finish = ok => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        if (S.compactWaiter === finish) S.compactWaiter = null;
        resolve(ok);
      };
      timer = setTimeout(() => {
        toast('自动压缩超时，可以手动发送 /compact', 'error');
        finish(false);
      }, 240000);
      S.compactWaiter = finish;
      api('/chat', {
        method: 'POST',
        body: JSON.stringify({ id: S.conv.id, text: '/compact' })
      }).catch(e => {
        toast(e.message, 'error');
        finish(false);
      });
    }).then(ok => {
      S.compacting = false;
      S.compactConvId = null;
      updateComposerState();
      setStatus('已连接', 'ok');
      if (ok) {
        // 具体数值由 run_end / compact_boundary 更新，这里不要再覆盖成 0
        updateContextBadge();
        toast(opts.autoResume ? '上下文已压缩，正在自动继续任务…' : '上下文已压缩，继续发送');
      }
      return ok;
    });
  }

  async function composeWithRefs(text, refs, extraText = '') {
    const digest = await digestReady;
    if (!digest || typeof digest.buildBlock !== 'function') throw new Error('引用摘要模块未加载');
    const packs = [];
    for (const r of refs) {
      // handoff=1：服务端只返回最近一次压缩摘要 + 最近几十条消息，
      // 避免把几十 MB 的长转录整个拉到浏览器；模型侧仍由 ref-digest 压到 12–15K 字符。
      const c = await api('/conversation?id=' + encodeURIComponent(r.id) + '&handoff=1');
      packs.push({
        id: r.id,
        title: c.title || r.title,
        cwd: c.cwd || r.cwd,
        updatedAt: r.updatedAt,
        messages: c.messages || []
      });
    }
    // extraText：来自被引用对话的文字引用，作为额外的筛选词，帮助定位相关轮次
    const block = digest.buildBlock(packs, text, {
      maxChars: refs.length > 1 ? 15000 : 12000,
      extra: extraText
    });
    return block ? (text ? text + '\n\n' : '') + block : text;
  }

  function allConversations() {
    const out = [];
    for (const f of S.folders) {
      for (const c of f.conversations || []) out.push({ ...c, folder: f.path });
    }
    return out;
  }

  function openRefPicker() {
    if (S.compacting) return;
    S.refSel = new Map((S.pendingRefs || []).map(r => [r.id, r]));
    S.refSearch = '';
    const inp = $('#featRefSearch');
    if (inp) inp.value = '';
    const modal = $('#featRefModal');
    if (!modal) return;
    modal.hidden = false;
    renderRefList();
    setTimeout(() => { try { inp.focus(); } catch { /* ignore */ } }, 30);
  }

  function updateRefCount() {
    const el = $('#featRefCount');
    if (el) el.textContent = S.refSel.size ? `已选 ${S.refSel.size} / 3` : '未选择（最多 3 个）';
  }

  function renderRefList() {
    const list = $('#featRefList');
    if (!list) return;
    list.innerHTML = '';
    updateRefCount();
    const q = String(S.refSearch || '').trim().toLowerCase();
    const convs = allConversations()
      .filter(c => !S.conv || c.id !== S.conv.id)
      .filter(c => {
        if (!q) return true;
        return [c.title, c.preview, c.folder].some(x => String(x || '').toLowerCase().includes(q));
      })
      .sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0));

    if (!convs.length) {
      list.innerHTML = '<div class="feat-empty">没有可引用的对话。先在左侧打开或新建过对话再试。</div>';
      return;
    }

    for (const c of convs) {
      const empty = !!c.placeholder || !c.turns;
      const sel = S.refSel.has(c.id);
      const row = document.createElement('button');
      row.type = 'button';
      row.className = 'feat-item' + (sel ? ' sel' : '') + (empty ? ' off' : '');
      row.disabled = empty;
      const folderName = String(c.folder || '').split(/[\\/]/).filter(Boolean).pop() || c.folder || '';
      row.innerHTML = `
        <span class="feat-check">${sel ? '✓' : ''}</span>
        <span class="feat-main">
          <span class="feat-title"><b>${escapeHtml(c.title || '未命名对话')}</b></span>
          <span class="feat-desc">${escapeHtml(c.preview || '（没有预览）')}</span>
          <span class="feat-meta">${escapeHtml(folderName)} · ${escapeHtml(timeAgo(c.updatedAt))} · ${Number(c.turns) || 0} 轮</span>
        </span>`;
      row.addEventListener('click', () => {
        if (empty) return;
        if (S.refSel.has(c.id)) {
          S.refSel.delete(c.id);
        } else {
          if (S.refSel.size >= 3) { toast('最多同时引用 3 个对话'); return; }
          S.refSel.set(c.id, {
            id: c.id, title: c.title || '未命名对话',
            cwd: c.folder || c.cwd, updatedAt: c.updatedAt, turns: c.turns
          });
        }
        renderRefList();
      });
      list.appendChild(row);
    }
  }

  function commitRefs() {
    S.pendingRefs = [...S.refSel.values()];
    renderAttachments();
    const modal = $('#featRefModal');
    if (modal) modal.hidden = true;
    if (S.pendingRefs.length) toast(`已引用 ${S.pendingRefs.length} 个对话`);
  }

  async function openExtensions() {
    const modal = $('#featExtModal');
    if (!modal) return;
    modal.hidden = false;
    await loadExtensions();
  }

  async function loadExtensions() {
    const list = $('#featExtList');
    if (!list) return;
    list.innerHTML = '<div class="feat-empty">正在读取本机技能和 MCP…</div>';
    try {
      const cwd = (S.conv && S.conv.cwd) || S.currentFolder || '';
      const data = await api('/extensions?cwd=' + encodeURIComponent(cwd));
      S.extData = data;
      if (data.version) S.appVersion = data.version;
      renderExtensions();
    } catch (e) {
      const msg = String(e.message || '');
      if (/\(404\)|(^|\D)404(\D|$)|未知接口/.test(msg)) {
        list.innerHTML = '<div class="feat-empty">这个功能要重启一次工作台后生效。<br>当前服务进程还在跑旧代码；重启不会丢对话记录。</div>';
      } else {
        list.innerHTML = `<div class="feat-empty">读取失败：${escapeHtml(msg)}</div>`;
      }
    }
  }

  function renderExtensions() {
    const data = S.extData || { skills: [], mcp: [] };
    const tab = ['skills', 'mcp', 'plugins'].includes(S.extTab) ? S.extTab : 'skills';
    const tabs = document.querySelectorAll('#featExtModal [data-tab]');
    tabs.forEach(b => {
      const is = b.dataset.tab === tab;
      b.classList.toggle('active', is);
      if (b.dataset.tab === 'skills') b.textContent = `技能 ${data.skills ? data.skills.length : 0}`;
      else if (b.dataset.tab === 'mcp') b.textContent = `MCP ${data.mcp ? data.mcp.length : 0}`;
      else b.textContent = S.plugins ? `插件 ${S.plugins.installed ? S.plugins.installed.length : 0}` : '插件';
    });
    const ver = $('#featVersion');
    if (ver) ver.textContent = S.appVersion ? 'v' + S.appVersion : '';

    const pSearch = $('#featPluginSearch');
    if (pSearch) pSearch.hidden = tab !== 'plugins';

    const list = $('#featExtList');
    if (!list) return;
    if (tab === 'plugins') {
      renderPlugins();
      return;
    }
    list.innerHTML = '';
    const items = tab === 'skills' ? (data.skills || []) : (data.mcp || []);
    if (!items.length) {
      list.innerHTML = tab === 'skills'
        ? '<div class="feat-empty">没有找到本机安装的技能。<br>位置：~/.claude/skills 和项目内的 .claude/skills</div>'
        : '<div class="feat-empty">没有配置 MCP 服务器。<br>位置：~/.claude.json 和项目内的 .mcp.json</div>';
    }

    for (const it of items) {
      const row = document.createElement('div');
      row.className = 'feat-item';
      if (tab === 'skills') {
        const scope = it.scope === 'project' ? '项目级' : '用户级';
        row.innerHTML = `
          <span class="feat-main">
            <span class="feat-title"><b>${escapeHtml(it.name)}</b>
              <span class="feat-badge">${scope}</span>
              ${it.hasSkillMd ? '' : '<span class="feat-badge bad">缺少 SKILL.md</span>'}
            </span>
            <span class="feat-desc">${escapeHtml(it.description || '（没有描述）')}</span>
            <span class="feat-meta" title="${escapeHtml(it.path)}">${escapeHtml(it.path)}${it.size ? ' · ' + fmtBytes(it.size) : ''}</span>
          </span>`;
        const btn = document.createElement('button');
        btn.className = 'feat-remove';
        btn.textContent = '卸载';
        btn.addEventListener('click', () => uninstallSkill(it));
        row.appendChild(btn);
      } else {
        const scope = { user: '用户级', local: '本机项目', project: '项目 .mcp.json' }[it.scope] || it.scope;
        let state = '';
        if (it.enabled === false) state = '<span class="feat-badge bad">已禁用</span>';
        else if (it.enabled === null) state = '<span class="feat-badge">待批准</span>';
        row.innerHTML = `
          <span class="feat-main">
            <span class="feat-title"><b>${escapeHtml(it.name)}</b>
              <span class="feat-badge">${escapeHtml(scope)}</span>${state}
            </span>
            <span class="feat-desc">${escapeHtml([it.type, it.target].filter(Boolean).join(' · ') || '（未知类型）')}</span>
            <span class="feat-meta" title="${escapeHtml(it.source || '')}">${escapeHtml(it.source || '')}${it.cwd ? ' · ' + escapeHtml(it.cwd) : ''}</span>
          </span>`;
        const btn = document.createElement('button');
        btn.className = 'feat-remove';
        btn.textContent = '移除';
        btn.addEventListener('click', () => uninstallMcp(it));
        row.appendChild(btn);
      }
      list.appendChild(row);
    }

    const note = $('#featExtNote');
    if (note) {
      note.textContent = tab === 'skills'
        ? '卸载会移到 ~/.claude/skills-trash（插件技能请在插件里管理）'
        : '移除后重启对应会话生效（插件 MCP 不在这里）';
    }
  }

  async function uninstallSkill(it) {
    if (!confirm(`卸载技能「${it.name}」？\n\n会移动到 ~/.claude/skills-trash，之后可以手动恢复。`)) return;
    try {
      await api('/extensions/skill/remove', {
        method: 'POST',
        body: JSON.stringify({ path: it.path, cwd: (S.conv && S.conv.cwd) || S.currentFolder || '' })
      });
      toast('已卸载：' + it.name);
      await loadExtensions();
    } catch (e) { toast(e.message, 'error'); }
  }

  async function uninstallMcp(it) {
    const scope = { user: '用户级', local: '本机项目', project: '项目 .mcp.json' }[it.scope] || it.scope;
    if (!confirm(`移除 MCP「${it.name}」？\n\n作用域：${scope}${it.cwd ? '\n项目：' + it.cwd : ''}\n\n会调用 claude mcp remove，之后重启对应会话生效。`)) return;
    try {
      await api('/extensions/mcp/remove', {
        method: 'POST',
        body: JSON.stringify({ name: it.name, scope: it.scope, cwd: it.cwd || '' })
      });
      toast('已移除：' + it.name);
      if (it.scope !== 'user' && S.conv && it.cwd && it.cwd.toLowerCase() === String(S.conv.cwd || '').toLowerCase()) {
        toast('当前对话还在用旧连接，重启这个对话后生效');
      }
      await loadExtensions();
    } catch (e) { toast(e.message, 'error'); }
  }

  function pluginMatches(item, q) {
    if (!q) return true;
    return [item.name, item.description, item.marketplace, item.id]
      .some(x => String(x || '').toLowerCase().includes(q));
  }

  function pluginActionButton(label, cls, disabled, onClick) {
    const b = document.createElement('button');
    b.className = 'feat-action' + (cls ? ' ' + cls : '');
    b.textContent = label;
    b.disabled = !!disabled;
    b.addEventListener('click', onClick);
    return b;
  }

  async function loadPlugins(force = false) {
    if (S.pluginLoading) return;
    S.pluginLoading = true;
    if (S.extTab === 'plugins') {
      const list = $('#featExtList');
      if (list) list.innerHTML = '<div class="feat-empty">正在读取插件列表…</div>';
    }
    try {
      const data = await api('/plugins' + (force ? '?refresh=1' : ''));
      S.plugins = {
        installed: Array.isArray(data.installed) ? data.installed : [],
        available: Array.isArray(data.available) ? data.available : [],
        availableError: String(data.availableError || '')
      };
      if (data.version) S.appVersion = data.version;
    } catch (e) {
      const msg = String(e.message || '读取失败');
      S.plugins = {
        installed: [],
        available: [],
        availableError: /未知接口|\(404\)|(^|\D)404(\D|$)/.test(msg)
          ? '这个功能要重启一次工作台后生效。'
          : msg
      };
    } finally {
      S.pluginLoading = false;
      if (S.extTab === 'plugins') renderPlugins();
    }
  }

  function renderPlugins() {
    const list = $('#featExtList');
    if (!list) return;
    if (!S.plugins) {
      list.innerHTML = '<div class="feat-empty">正在读取插件列表…</div>';
      if (!S.pluginLoading) loadPlugins();
      return;
    }

    const q = String(S.pluginSearch || '').trim().toLowerCase();
    const installedAll = S.plugins.installed || [];
    const pTab = document.querySelector('#featExtModal [data-tab="plugins"]');
    if (pTab) pTab.textContent = `插件 ${installedAll.length}`;
    const installed = installedAll.filter(it => pluginMatches(it, q));
    const available = (S.plugins.available || []).filter(it => pluginMatches(it, q));
    const totalAvailable = available.length;
    const shown = q ? available : (S.pluginShowAll ? available : available.slice(0, 30));

    list.innerHTML = '';
    if (S.plugins.availableError) {
      const warn = document.createElement('div');
      warn.className = 'feat-warn';
      warn.textContent = '可安装列表读取失败：' + S.plugins.availableError;
      list.appendChild(warn);
    }

    const instHead = document.createElement('div');
    instHead.className = 'feat-section';
    instHead.textContent = `已安装（${installedAll.length}）`;
    list.appendChild(instHead);
    if (!installed.length) {
      const empty = document.createElement('div');
      empty.className = 'feat-empty';
      empty.textContent = q ? '没有匹配的已安装插件。' : '还没有安装市场插件。CLI 自带的技能/插件不在这里。';
      list.appendChild(empty);
    }
    for (const it of installed) {
      const row = document.createElement('div');
      row.className = 'feat-item';
      const state = it.enabled ? '<span class="feat-badge">已启用</span>' : '<span class="feat-badge bad">已禁用</span>';
      const scope = { user: '用户级', project: '项目级', local: '本机级' }[it.scope] || it.scope || '';
      row.innerHTML = `
        <span class="feat-main">
          <span class="feat-title"><b>${escapeHtml(it.name)}</b>
            ${it.version ? `<span class="feat-badge">v${escapeHtml(it.version)}</span>` : ''}
            <span class="feat-badge">${escapeHtml(scope)}</span>${state}
          </span>
          <span class="feat-desc">${escapeHtml(it.description || '（没有描述）')}</span>
          <span class="feat-meta" title="${escapeHtml(it.installPath || '')}">${escapeHtml(it.marketplace || '')}${it.installPath ? ' · ' + escapeHtml(it.installPath) : ''}</span>
        </span>`;
      const actions = document.createElement('div');
      actions.className = 'feat-actions';
      const busy = S.pluginBusy === it.id;
      actions.appendChild(pluginActionButton(busy ? '处理中…' : (it.enabled ? '禁用' : '启用'), '', busy,
        () => runPluginAction(it.enabled ? 'disable' : 'enable', it)));
      actions.appendChild(pluginActionButton('卸载', 'danger', busy, () => runPluginAction('uninstall', it)));
      row.appendChild(actions);
      list.appendChild(row);
    }

    const availHead = document.createElement('div');
    availHead.className = 'feat-section';
    availHead.textContent = q ? `搜索结果（${totalAvailable}）` : `可安装（${totalAvailable}）`;
    list.appendChild(availHead);
    if (!shown.length) {
      const empty = document.createElement('div');
      empty.className = 'feat-empty';
      empty.textContent = q ? '没有匹配的可安装插件。' : '没有可安装的插件（marketplace 可能还没同步）。';
      list.appendChild(empty);
    }
    for (const it of shown) {
      const row = document.createElement('div');
      row.className = 'feat-item';
      const count = Number(it.installCount) || 0;
      row.innerHTML = `
        <span class="feat-main">
          <span class="feat-title"><b>${escapeHtml(it.name)}</b>
            <span class="feat-badge">${escapeHtml(it.marketplace || 'marketplace')}</span>
            ${count ? `<span class="feat-badge">${count.toLocaleString()} 次安装</span>` : ''}
          </span>
          <span class="feat-desc">${escapeHtml(it.description || '（没有描述）')}</span>
          <span class="feat-meta">${escapeHtml(it.id)}</span>
        </span>`;
      const actions = document.createElement('div');
      actions.className = 'feat-actions';
      const busy = S.pluginBusy === it.id;
      actions.appendChild(pluginActionButton(busy ? '安装中…' : '安装', 'primary', busy,
        () => runPluginAction('install', it)));
      row.appendChild(actions);
      list.appendChild(row);
    }
    if (!q && !S.pluginShowAll && totalAvailable > 30) {
      const more = document.createElement('button');
      more.className = 'feat-more';
      more.textContent = `显示全部 ${totalAvailable} 个`;
      more.addEventListener('click', () => { S.pluginShowAll = true; renderPlugins(); });
      list.appendChild(more);
    }

    const note = $('#featExtNote');
    if (note) {
      note.textContent = S.pluginBusy
        ? '正在执行插件操作，请稍候…'
        : '安装/卸载后新开一轮会话或重启工作台生效；内置技能不在这里';
    }
  }

  async function runPluginAction(action, item) {
    const label = { install: '安装', enable: '启用', disable: '禁用', uninstall: '卸载' }[action] || action;
    const name = item.name || item.id;
    if (action === 'install') {
      if (!confirm(`安装插件「${name}」？\n\n来源：${item.marketplace || 'marketplace'}\n安装后需要新开一轮会话或重启工作台生效。`)) return;
    } else if (action === 'uninstall') {
      if (!confirm(`卸载插件「${name}」？\n\n它提供的技能/MCP/命令会一起移除。`)) return;
    }
    S.pluginBusy = item.id;
    renderPlugins();
    try {
      const r = await api('/plugins/action', {
        method: 'POST',
        body: JSON.stringify({ action, id: item.id, scope: item.scope || '' })
      });
      const line = String(r.output || (label + '完成')).split('\n').map(s => s.trim()).filter(Boolean)[0] || (label + '完成');
      toast(line.slice(0, 220));
      S.plugins = null;
      await loadPlugins(true);
    } catch (e) {
      toast(label + '失败：' + e.message, 'error');
    } finally {
      S.pluginBusy = '';
      if (S.extTab === 'plugins') renderPlugins();
    }
  }

  function injectFeatures() {
    if ($('#featRefModal')) return;

    const style = document.createElement('style');
    style.id = 'feat-style';
    style.textContent = `
      .ctx-badge.compacting { color: var(--accent); border-color: var(--accent-line); }
      .ctx-badge.compacting .ctx-dot { background: var(--accent); animation: ctxPulse 1s ease-in-out infinite; }
      @keyframes ctxPulse { 0%, 100% { opacity: .3; transform: scale(.85); } 50% { opacity: 1; transform: scale(1.15); } }
      .composer-tool { width: 28px; height: 28px; border-radius: 8px; display: grid; place-items: center; color: var(--fg-4); }
      .composer-tool:hover { background: var(--panel-2); color: var(--fg-2); }
      .composer-tool svg { width: 16px; height: 16px; }
      .ref-chip { display: flex; align-items: center; gap: 6px; max-width: 260px; padding: 4px 6px 4px 8px; border: 1px solid var(--line-2); border-radius: 8px; background: var(--panel); font-size: 12px; color: var(--fg-2); }
      .ref-chip-ic { color: var(--accent); font-size: 12px; line-height: 1; }
      .ref-chip-name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .ref-chip .attach-x { position: static; width: 18px; height: 18px; background: transparent; color: var(--fg-4); }
      .ref-chip .attach-x:hover { background: var(--red); color: #fff; }
      .bubble-ref { display: inline-block; margin-bottom: 6px; padding: 1px 7px; border: 1px solid var(--line-2); border-radius: 99px; font-size: 10.5px; color: var(--fg-4); }
      .feat-modal { width: min(760px, calc(100vw - 48px)); height: min(620px, calc(100vh - 80px)); }
      .feat-body { flex: 1; min-height: 0; display: flex; flex-direction: column; padding: 12px 14px; gap: 10px; }
      .feat-search { height: 32px; padding: 0 11px; border-radius: 8px; border: 1px solid var(--line-2); background: var(--panel); color: var(--fg); font-size: 12.5px; outline: 0; }
      .feat-search:focus { border-color: var(--accent-line); }
      .feat-hint { font-size: 11.5px; color: var(--fg-4); line-height: 1.55; }
      .feat-list { flex: 1; min-height: 0; overflow: auto; display: flex; flex-direction: column; gap: 6px; }
      .feat-item { display: flex; align-items: stretch; gap: 10px; padding: 9px 10px; border: 1px solid var(--line); border-radius: 9px; background: var(--panel); text-align: left; width: 100%; }
      button.feat-item:hover { border-color: var(--line-2); background: var(--panel-2); }
      .feat-item.sel { border-color: var(--accent-line); background: var(--panel-2); }
      .feat-item.off { opacity: .45; }
      .feat-check { flex: 0 0 18px; width: 18px; height: 18px; margin-top: 2px; border: 1px solid var(--line-2); border-radius: 5px; display: grid; place-items: center; font-size: 11px; color: var(--accent); }
      .feat-item.sel .feat-check { border-color: var(--accent-line); background: rgba(229,145,99,.12); }
      .feat-main { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
      .feat-title { display: flex; align-items: center; gap: 7px; font-size: 13px; color: var(--fg); min-width: 0; }
      .feat-title b { font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .feat-badge { flex: 0 0 auto; font-size: 10px; padding: 1px 6px; border-radius: 99px; border: 1px solid var(--line-2); color: var(--fg-4); }
      .feat-badge.bad { color: var(--red); border-color: rgba(224,112,112,.35); }
      .feat-desc { font-size: 12px; color: var(--fg-3); overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
      .feat-meta { font-family: var(--mono); font-size: 10.5px; color: var(--fg-4); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .feat-remove { flex: 0 0 auto; align-self: center; padding: 4px 9px; border: 1px solid var(--line-2); border-radius: 7px; font-size: 11.5px; color: var(--red); }
      .feat-remove:hover { background: rgba(224,112,112,.12); border-color: rgba(224,112,112,.35); }
      .feat-empty { padding: 30px 12px; text-align: center; color: var(--fg-4); font-size: 12.5px; line-height: 1.8; }
      .feat-tabs { display: flex; gap: 6px; padding: 10px 14px 0; border-bottom: 1px solid var(--line); }
      .feat-tab { padding: 7px 12px; border-radius: 8px 8px 0 0; font-size: 12.5px; color: var(--fg-4); }
      .feat-tab:hover { color: var(--fg-2); }
      .feat-tab.active { color: var(--fg); background: var(--panel); border: 1px solid var(--line); border-bottom-color: var(--panel); margin-bottom: -1px; }
      .feat-count { margin-right: auto; font-size: 11.5px; color: var(--fg-4); }
      .feat-version { margin-left: 8px; font-size: 10.5px; color: var(--fg-4); font-family: var(--mono); }
      .feat-section { margin: 8px 2px 2px; font-size: 10.5px; letter-spacing: 1px; text-transform: uppercase; color: var(--fg-4); }
      .feat-actions { display: flex; gap: 6px; align-self: center; flex: 0 0 auto; }
      .feat-action { padding: 4px 9px; border: 1px solid var(--line-2); border-radius: 7px; font-size: 11.5px; color: var(--fg-3); }
      .feat-action:hover { background: var(--panel-2); color: var(--fg-2); }
      .feat-action.primary { color: var(--accent); border-color: var(--accent-line); }
      .feat-action.danger { color: var(--red); }
      .feat-action:disabled { opacity: .5; }
      .feat-more { align-self: center; margin: 4px 0; padding: 6px 12px; border: 1px solid var(--line-2); border-radius: 8px; font-size: 12px; color: var(--fg-3); }
      .feat-more:hover { background: var(--panel-2); color: var(--fg-2); }
      .feat-warn { padding: 8px 10px; border: 1px solid rgba(224,112,112,.32); border-radius: 8px; color: var(--red); font-size: 12px; line-height: 1.5; }
      .bubble-text.collapsed { max-height: 21em; overflow: hidden; -webkit-mask-image: linear-gradient(to bottom, #000 calc(100% - 42px), transparent); mask-image: linear-gradient(to bottom, #000 calc(100% - 42px), transparent); }
      .bubble-expand { display: block; margin-top: 7px; padding: 0; border: 0; background: none; color: var(--accent); font: inherit; font-size: 11.5px; line-height: 1.4; cursor: pointer; text-align: left; }
      .bubble-expand:hover { text-decoration: underline; }
    `;
    document.head.appendChild(style);

    const refBtn = document.createElement('button');
    refBtn.id = 'refBtn';
    refBtn.className = 'composer-tool';
    refBtn.title = '引用其它对话（只把与当前问题相关的内容带给 Claude）';
    refBtn.setAttribute('aria-label', '引用其它对话');
    refBtn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M4 5h16v11H9l-4 3v-3H4z"/><path d="M8 9h8M8 12h5"/></svg>';
    const btns = document.querySelector('.composer-btns');
    if (btns) btns.insertBefore(refBtn, stopBtn);

    const extBtn = document.createElement('button');
    extBtn.id = 'featExtBtn';
    extBtn.className = 'ghost-btn';
    extBtn.title = '查看、卸载本机的技能和 MCP';
    extBtn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M9 3v5M15 3v5M7 8h10v6a5 5 0 0 1-10 0z"/><path d="M12 19v2"/></svg><span>技能与 MCP</span>';
    const foot = document.querySelector('.sb-foot');
    if (foot) foot.insertBefore(extBtn, foot.firstChild);

    const tmp = document.createElement('div');
    tmp.innerHTML = `
      <div class="modal-backdrop" id="featRefModal" hidden>
        <div class="modal feat-modal" role="dialog" aria-modal="true" aria-label="引用其它对话">
          <div class="modal-head">
            <b>引用其它对话</b>
            <button class="icon-btn" data-close title="关闭（Esc）">
              <svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>
            </button>
          </div>
          <div class="feat-body">
            <input class="feat-search" id="featRefSearch" type="text" placeholder="搜索对话标题、内容或文件夹…" spellcheck="false" autocomplete="off">
            <div class="feat-hint">发送时会以输入框里的任务为依据，只挑和被引用对话相关的片段，不会整段读取。先写任务再选对话效果最好。</div>
            <div class="feat-list" id="featRefList"></div>
          </div>
          <div class="modal-foot dialog-foot">
            <span class="feat-count" id="featRefCount"></span>
            <button class="btn" data-cancel>取消</button>
            <button class="btn primary" data-ok>引用</button>
          </div>
        </div>
      </div>
      <div class="modal-backdrop" id="featExtModal" hidden>
        <div class="modal feat-modal" role="dialog" aria-modal="true" aria-label="技能与 MCP">
          <div class="modal-head">
            <b>技能与 MCP<span class="feat-version" id="featVersion"></span></b>
            <button class="icon-btn" data-close title="关闭（Esc）">
              <svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>
            </button>
          </div>
          <div class="feat-tabs">
            <button class="feat-tab active" data-tab="skills">技能</button>
            <button class="feat-tab" data-tab="mcp">MCP</button>
            <button class="feat-tab" data-tab="plugins">插件</button>
          </div>
          <div class="feat-body">
            <input class="feat-search" id="featPluginSearch" type="text" placeholder="搜索已安装或可安装插件…" spellcheck="false" autocomplete="off" hidden>
            <div class="feat-list" id="featExtList"></div>
          </div>
          <div class="modal-foot dialog-foot">
            <span class="feat-count" id="featExtNote"></span>
            <button class="btn" data-refresh>刷新</button>
            <button class="btn" data-close>关闭</button>
          </div>
        </div>
      </div>`;
    const frag = document.createDocumentFragment();
    while (tmp.firstChild) frag.appendChild(tmp.firstChild);
    document.body.appendChild(frag);

    fetch('/version.json', { cache: 'no-store' })
      .then(r => r.ok ? r.json() : null)
      .then(v => {
        if (v && v.version) {
          S.appVersion = v.version;
          const line = $('#statusLine');
          if (line) line.title = 'Claude 工作台 v' + v.version;
        }
      })
      .catch(() => {});
  }

  function bindFeatureEvents() {
    const refBtn = $('#refBtn');
    if (refBtn) refBtn.addEventListener('click', openRefPicker);
    const extBtn = $('#featExtBtn');
    if (extBtn) extBtn.addEventListener('click', openExtensions);

    const rm = $('#featRefModal');
    if (rm) {
      rm.addEventListener('mousedown', e => { if (e.target === rm) rm.hidden = true; });
      rm.querySelectorAll('[data-close],[data-cancel]').forEach(b => {
        b.addEventListener('click', () => { rm.hidden = true; });
      });
      const ok = rm.querySelector('[data-ok]');
      if (ok) ok.addEventListener('click', commitRefs);
      const search = $('#featRefSearch');
      if (search) {
        search.addEventListener('input', e => { S.refSearch = e.target.value; renderRefList(); });
        search.addEventListener('keydown', e => {
          if (e.key === 'Enter') { e.preventDefault(); commitRefs(); }
        });
      }
    }

    const em = $('#featExtModal');
    if (em) {
      em.addEventListener('mousedown', e => { if (e.target === em) em.hidden = true; });
      em.querySelectorAll('[data-close]').forEach(b => {
        b.addEventListener('click', () => { em.hidden = true; });
      });
      const refresh = em.querySelector('[data-refresh]');
      if (refresh) refresh.addEventListener('click', () => {
        if (S.extTab === 'plugins') { S.plugins = null; loadPlugins(true); }
        else loadExtensions();
      });
      em.querySelectorAll('[data-tab]').forEach(b => {
        b.addEventListener('click', () => { S.extTab = b.dataset.tab; renderExtensions(); });
      });
      const ps = $('#featPluginSearch');
      if (ps) ps.addEventListener('input', e => {
        S.pluginSearch = e.target.value;
        if (S.extTab === 'plugins') renderPlugins();
      });
    }

    document.addEventListener('keydown', e => {
      if (e.key !== 'Escape') return;
      if (rm && !rm.hidden) { rm.hidden = true; return; }
      if (em && !em.hidden) { em.hidden = true; }
    });
  }

  // ------------------------------------------------------------ 发送

  // ------------------------------------------------------------ 粘贴截图

  const MAX_PENDING_IMAGES = 5;
  const MAX_PENDING_FILES = 20;
  // 连续聊天超过这个间隔才显示新的时间分隔条
  const CHAT_TIME_GAP = 10 * 60 * 1000;

  function renderAttachments() {
    // chip 被删掉时不会触发 mouseleave，重绘时统一收起悬停浮窗
    hideQuoteTip();
    attachStrip.innerHTML = '';
    if (!S.pendingImages.length && !S.pendingFiles.length && !S.pendingRefs.length && !S.pendingQuotes.length) {
      attachStrip.hidden = true;
      return;
    }
    attachStrip.hidden = false;
    // 引用对话排在引用文字前面，多个文字引用也始终跟在对话引用后面
    S.pendingRefs.forEach(ref => {
      const chip = document.createElement('div');
      chip.className = 'ref-chip conv-chip';
      const ic = document.createElement('span');
      ic.className = 'ref-chip-ic';
      ic.textContent = '❝';
      const name = document.createElement('span');
      name.className = 'ref-chip-name';
      name.textContent = ref.title || '未命名对话';
      const x = document.createElement('button');
      x.type = 'button';
      x.className = 'attach-x';
      x.title = '移除引用';
      x.textContent = '×';
      x.addEventListener('click', () => {
        hideQuoteTip();
        S.pendingRefs = S.pendingRefs.filter(r => r.id !== ref.id);
        renderAttachments();
      });
      chip.append(ic, name, x);
      chip.addEventListener('mouseenter', () => showConvRefTip(chip, ref));
      chip.addEventListener('mouseleave', hideQuoteTip);
      attachStrip.appendChild(chip);
    });
    S.pendingQuotes.forEach(q => {
      const chip = document.createElement('div');
      chip.className = 'ref-chip quote-chip';
      const ic = document.createElement('span');
      ic.className = 'ref-chip-ic';
      ic.textContent = '“';
      const name = document.createElement('span');
      name.className = 'ref-chip-name';
      name.textContent = quotePreview(q.text);
      const x = document.createElement('button');
      x.type = 'button';
      x.className = 'attach-x';
      x.title = '移除引用';
      x.textContent = '×';
      x.addEventListener('click', () => {
        hideQuoteTip();
        S.pendingQuotes = S.pendingQuotes.filter(item => item.id !== q.id);
        renderAttachments();
        updateComposerState();
      });
      chip.append(ic, name, x);
      chip.addEventListener('mouseenter', () => showQuoteTip(chip, q));
      chip.addEventListener('mouseleave', hideQuoteTip);
      attachStrip.appendChild(chip);
    });
    S.pendingFiles.forEach(file => {
      const chip = document.createElement('div');
      chip.className = 'ref-chip file-chip';
      chip.title = file.path + (file.isDir ? '（文件夹）' : '');
      const ic = document.createElement('span');
      ic.className = 'ref-chip-ic';
      ic.textContent = file.isDir ? '📁' : '📄';
      const name = document.createElement('span');
      name.className = 'ref-chip-name';
      name.textContent = file.name || baseNameOfPath(file.path);
      const x = document.createElement('button');
      x.type = 'button';
      x.className = 'attach-x';
      x.title = '移除引用';
      x.textContent = '×';
      x.addEventListener('click', () => {
        S.pendingFiles = S.pendingFiles.filter(f => f.id !== file.id);
        renderAttachments();
      });
      chip.append(ic, name, x);
      attachStrip.appendChild(chip);
    });
    S.pendingImages.forEach((img, i) => {
      const item = document.createElement('div');
      item.className = 'attach-item';
      const el = document.createElement('img');
      el.src = img.url;
      el.alt = img.name || `第 ${i + 1} 张图片`;
      el.title = '单击查看大图';
      const num = document.createElement('span');
      num.className = 'attach-num';
      num.textContent = i + 1;
      const x = document.createElement('button');
      x.type = 'button';
      x.className = 'attach-x';
      x.title = '移除';
      x.textContent = '×';
      x.addEventListener('click', () => {
        S.pendingImages = S.pendingImages.filter(i => i.id !== img.id);
        renderAttachments();
      });
      item.append(el, num, x);
      attachStrip.appendChild(item);
    });
  }

  /** 把剪贴板图片缩到最长边 1568px，并保证 base64 不超过 5MB */
  async function normalizeImage(file) {
    const type = (file.type || '').toLowerCase();
    if (!/^image\/(png|jpeg|webp|gif)$/.test(type)) throw new Error('只支持 PNG/JPEG/WebP/GIF 图片');
    if (file.size > 20 * 1024 * 1024) throw new Error('图片超过 20MB');

    const bmp = await createImageBitmap(file);
    try {
      const LIMIT = 5 * 1024 * 1024;
      const outType = type === 'image/png' ? 'image/png' : 'image/jpeg';

      const draw = (maxSide, quality) => {
        const scale = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
        const w = Math.max(1, Math.round(bmp.width * scale));
        const h = Math.max(1, Math.round(bmp.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        canvas.getContext('2d').drawImage(bmp, 0, 0, w, h);
        return canvas.toDataURL(outType, quality);
      };

      const plan = outType === 'image/png'
        ? [[1568, 1], [1200, 1], [1024, 1], [768, 1]]
        : [[1568, .9], [1200, .85], [1024, .8], [768, .75]];
      let dataUrl = '';
      for (const [side, q] of plan) {
        dataUrl = draw(side, q);
        if (dataUrl.length <= LIMIT) break;
      }

      const data = dataUrl.slice(dataUrl.indexOf(',') + 1);
      if (!data || data.length > LIMIT) throw new Error('图片压缩后仍然过大');
      return { media_type: outType, data, url: dataUrl };
    } finally {
      if (bmp.close) bmp.close();
    }
  }

  async function stageFiles(files) {
    for (const file of files) {
      if (S.pendingImages.length >= MAX_PENDING_IMAGES) {
        toast(`最多 ${MAX_PENDING_IMAGES} 张图片`);
        break;
      }
      try {
        const info = await normalizeImage(file);
        S.pendingImages.push({ id: ++S.imageSeq, name: file.name || null, ...info });
      } catch (e) {
        toast(e.message, 'error');
      }
    }
    renderAttachments();
  }

  function baseNameOfPath(p) {
    const s = String(p || '').replace(/[\\/]+$/, '');
    const m = s.match(/[^\\/]+$/);
    return m ? m[0] : s;
  }

  function normalizeDroppedPath(p) {
    // webUtils 有时返回正斜杠；统一成反斜杠，展示和 Claude 读取都更稳
    return String(p || '').replace(/\//g, '\\');
  }

  function getDroppedPath(file) {
    try {
      let p = '';
      if (window.guiDesktop && typeof window.guiDesktop.getPathForFile === 'function') {
        p = window.guiDesktop.getPathForFile(file);
      }
      if (!p && file && file.path) p = file.path;
      return normalizeDroppedPath(p);
    } catch { return ''; }
  }

  function stageFileRefs(refs) {
    for (const ref of refs) {
      if (S.pendingFiles.length >= MAX_PENDING_FILES) {
        toast(`最多引用 ${MAX_PENDING_FILES} 个文件/文件夹`);
        break;
      }
      const path = ref.path;
      if (!path) continue;
      const key = path.toLowerCase();
      if (S.pendingFiles.some(f => f.path.toLowerCase() === key)) continue;
      S.pendingFiles.push({
        id: ++S.fileSeq,
        path,
        name: ref.name || baseNameOfPath(path),
        isDir: !!ref.isDir
      });
    }
    renderAttachments();
  }

  /** 把一批 File（可含文件夹）统一分流成图片附件或文件/文件夹引用 */
  async function stageIncomingFiles(incoming) {
    const images = [];
    const refs = [];
    let noPath = 0;
    for (const item of incoming) {
      const file = item && item.file;
      if (!file) continue;
      const isDir = !!(item && item.isDir);
      if (!isDir && /^image\/(png|jpeg|webp|gif)$/i.test(file.type || '')) {
        images.push(file);
        continue;
      }
      const path = getDroppedPath(file);
      if (!path) { noPath++; continue; }
      refs.push({ path, name: file.name || baseNameOfPath(path), isDir });
    }
    if (images.length) await stageFiles(images);
    if (refs.length) stageFileRefs(refs);
    return { images: images.length, files: refs.length, noPath };
  }

  /** 原生选择器选中的图片按 Ctrl+V 图片同一管线处理（压缩 + 预览） */
  async function stagePickedImages(items) {
    const files = [];
    for (const item of items) {
      if (!item || !item.dataUrl) continue;
      try {
        const blob = await (await fetch(item.dataUrl)).blob();
        files.push(new File([blob], item.name || 'image', { type: item.mime || blob.type }));
      } catch (e) {
        toast('读取图片失败：' + e.message, 'error');
      }
    }
    if (files.length) await stageFiles(files);
  }

  function buildFileRefBlock(files) {
    if (!files || !files.length) return '';
    const lines = files.map(f => '- ' + (f.isDir ? '[文件夹] ' : '[文件] ') + f.path);
    return '[引用的文件/文件夹，请按需读取]\n' + lines.join('\n');
  }

  function withFileRefs(text, files) {
    const block = buildFileRefBlock(files);
    if (!block) return text;
    return text ? (text + '\n\n' + block) : block;
  }

  function handlePaste(e) {
    const dt = e.clipboardData;
    if (!dt) return;

    const incoming = [];
    for (const it of Array.from(dt.items || [])) {
      if (it.kind !== 'file') continue;
      const file = it.getAsFile();
      if (!file) continue;
      let entry = null;
      try { entry = it.webkitGetAsEntry && it.webkitGetAsEntry(); } catch { /* ignore */ }
      incoming.push({ file, isDir: !!(entry && entry.isDirectory) });
    }
    if (!incoming.length) {
      for (const file of Array.from(dt.files || [])) incoming.push({ file, isDir: false });
    }

    if (incoming.length) {
      e.preventDefault();
      stageIncomingFiles(incoming).then(res => {
        if (!res.images && !res.files) {
          toast(res.noPath ? '无法读取文件路径，请用桌面客户端粘贴' : '没有可引用的文件');
        }
      });
      return;
    }

    // 复制文件夹时有些平台只给 file:// URI，没有 File 对象
    const uriText = String(dt.getData('text/uri-list') || '').trim();
    if (!uriText) return;
    const refs = [];
    for (const raw of uriText.split(/\r?\n/)) {
      const m = /^file:\/\/(.+)$/i.exec(raw.trim());
      if (!m) continue;
      let p = m[1];
      try { p = decodeURIComponent(p); } catch { /* ignore */ }
      p = p.replace(/^\/([A-Za-z]:)/, '$1');
      const isDir = /[\\/]$/.test(p);
      p = normalizeDroppedPath(p.replace(/[\\/]+$/, ''));
      if (p) refs.push({ path: p, name: baseNameOfPath(p), isDir });
    }
    if (refs.length) {
      e.preventDefault();
      stageFileRefs(refs);
    }
  }

  // 输入框左下角的引用入口：原生对话框，分开选择图片/文件或文件夹
  function injectComposerAttach() {
    const row = document.querySelector('#composer .composer-row');
    if (!row || document.querySelector('.composer-attach-btns')) return;

    const style = document.createElement('style');
    style.id = 'composerAttachStyle';
    style.textContent = `
      .composer-attach-btns { display: flex; align-items: center; flex: 0 0 auto; margin-left: -4px; }
      .composer-attach-btns .icon-btn { width: 26px; height: 26px; border-radius: 8px; color: var(--fg-3); }
      .composer-attach-btns .icon-btn:hover, .composer-attach-btns .icon-btn[aria-expanded="true"] { color: var(--fg); background: var(--panel-2); }
      .composer-attach-menu {
        position: fixed; z-index: 90; min-width: 168px; padding: 5px;
        border: 1px solid var(--line-2); border-radius: 10px;
        background: var(--panel); box-shadow: var(--shadow);
      }
      .composer-attach-menu[hidden] { display: none !important; }
      .composer-attach-menu button {
        display: flex; align-items: center; gap: 8px; width: 100%; height: 32px;
        padding: 0 9px; border-radius: 7px; background: transparent;
        color: var(--fg-2); font-size: 12.5px; text-align: left; white-space: nowrap;
      }
      .composer-attach-menu button:hover { background: var(--panel-2); color: var(--fg); }
      .composer-attach-menu svg { width: 15px; height: 15px; flex: 0 0 auto; color: var(--fg-3); }
    `;
    document.head.appendChild(style);

    const group = document.createElement('div');
    group.className = 'composer-attach-btns';
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'icon-btn';
    btn.id = 'pickFilesBtn';
    btn.title = '引用图片/文件或文件夹';
    btn.setAttribute('aria-label', '引用图片、文件或文件夹');
    btn.setAttribute('aria-haspopup', 'menu');
    btn.setAttribute('aria-expanded', 'false');
    btn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M21.2 11.6l-8.5 8.5a6 6 0 0 1-8.5-8.5l8.5-8.5a4 4 0 0 1 5.7 5.7l-8.5 8.5a2 2 0 0 1-2.8-2.8l7.8-7.8"/></svg>';
    group.appendChild(btn);
    row.insertBefore(group, row.firstChild);

    const menu = document.createElement('div');
    menu.className = 'composer-attach-menu';
    menu.setAttribute('role', 'menu');
    menu.hidden = true;
    menu.innerHTML = `
      <button type="button" data-kind="files" role="menuitem">
        <svg viewBox="0 0 24 24"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>
        引用图片/文件（仅文件）
      </button>
      <button type="button" data-kind="folder" role="menuitem">
        <svg viewBox="0 0 24 24"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>
        引用文件夹（仅文件夹）
      </button>`;
    document.body.appendChild(menu);

    // 浏览器版拿不到绝对路径，退回原生 input（桌面客户端走 IPC 选择器）
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.multiple = true;
    fileInput.style.display = 'none';
    const folderInput = document.createElement('input');
    folderInput.type = 'file';
    folderInput.multiple = true;
    folderInput.setAttribute('webkitdirectory', '');
    folderInput.style.display = 'none';
    document.body.append(fileInput, folderInput);

    const closeMenu = () => {
      if (menu.hidden) return;
      menu.hidden = true;
      btn.setAttribute('aria-expanded', 'false');
    };

    const openMenu = () => {
      menu.hidden = false;
      btn.setAttribute('aria-expanded', 'true');
      const r = btn.getBoundingClientRect();
      menu.style.left = Math.round(r.left) + 'px';
      menu.style.top = Math.max(8, Math.round(r.top - menu.offsetHeight - 8)) + 'px';
    };

    const pickReference = async kind => {
      closeMenu();
      if (window.guiDesktop && typeof window.guiDesktop.pickReference === 'function') {
        try {
          const res = await window.guiDesktop.pickReference(kind);
          if (!res || res.canceled) return;
          const items = Array.isArray(res.items) ? res.items : [];
          if (!items.length) return;
          if (kind === 'folder') {
            stageFileRefs(items.map(i => ({
              path: normalizeDroppedPath(i.path),
              name: i.name || baseNameOfPath(i.path),
              isDir: true
            })));
          } else {
            const images = items.filter(i => i.isImage && i.dataUrl);
            const refs = items.filter(i => !i.isImage);
            if (images.length) await stagePickedImages(images);
            if (refs.length) {
              stageFileRefs(refs.map(i => ({
                path: normalizeDroppedPath(i.path),
                name: i.name || baseNameOfPath(i.path),
                isDir: false
              })));
            }
          }
          inputEl.focus();
        } catch (e) {
          toast('选择引用失败：' + e.message, 'error');
        }
        return;
      }
      if (window.guiDesktop) {
        toast('请重启一次客户端，启用新的引用选择器');
        return;
      }
      if (kind === 'folder') folderInput.click();
      else fileInput.click();
    };

    btn.addEventListener('click', e => {
      e.stopPropagation();
      if (menu.hidden) openMenu(); else closeMenu();
    });
    menu.addEventListener('click', e => {
      const item = e.target.closest('[data-kind]');
      if (item) pickReference(item.dataset.kind);
    });
    document.addEventListener('mousedown', e => {
      if (!menu.hidden && e.target !== btn && !menu.contains(e.target)) closeMenu();
    }, true);
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') closeMenu();
    });
    window.addEventListener('resize', closeMenu);

    fileInput.addEventListener('change', async () => {
      const files = Array.from(fileInput.files || []);
      fileInput.value = '';
      if (!files.length) return;
      const res = await stageIncomingFiles(files.map(file => ({ file, isDir: false })));
      if (!res.images && !res.files) {
        toast(res.noPath ? '无法读取文件路径，请用桌面客户端' : '没有可引用的文件');
      }
      inputEl.focus();
    });

    folderInput.addEventListener('change', () => {
      const first = folderInput.files && folderInput.files[0];
      folderInput.value = '';
      if (!first) { toast('文件夹为空或无法读取'); return; }
      const full = getDroppedPath(first);
      if (!full) { toast('无法读取文件夹路径，请用桌面客户端'); return; }
      const fullNorm = full.replace(/\\/g, '/');
      const rel = String(first.webkitRelativePath || '').replace(/\\/g, '/');
      const inside = rel.split('/').slice(1).join('/');
      let dir = inside ? fullNorm.slice(0, Math.max(0, fullNorm.length - inside.length)) : fullNorm.replace(/\/[^/]*$/, '');
      dir = normalizeDroppedPath(dir.replace(/\/+$/, ''));
      if (!dir) { toast('无法确定文件夹路径'); return; }
      stageFileRefs([{ path: dir, name: baseNameOfPath(dir), isDir: true }]);
      inputEl.focus();
    });

    const hint = $('#composerHint');
    if (hint && hint.textContent.includes('可粘贴截图')) {
      hint.textContent = 'Enter 发送 · Shift + Enter 换行 · 可拖入/粘贴文件、图片或文件夹';
    }
  }

  // ------------------------------------------------------------ 图片查看

  function openImageViewer(src) {
    if (!src) return;
    $('#viewerImg').src = src;
    $('#imageViewer').hidden = false;
  }

  function closeImageViewer() {
    const viewer = $('#imageViewer');
    if (viewer.hidden) return;
    viewer.hidden = true;
    $('#viewerImg').removeAttribute('src');
  }

  /** 复制文字到剪贴板；navigator.clipboard 不可用时退回 execCommand */
  async function copyTextToClipboard(text) {
    let ok = false;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
        ok = true;
      }
    } catch { /* 退回 execCommand */ }
    if (!ok) {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        ta.style.top = '0';
        document.body.appendChild(ta);
        ta.select();
        ok = document.execCommand('copy');
        ta.remove();
      } catch { ok = false; }
    }
    if (ok) toast('已复制');
    else toast('复制失败，请使用 Ctrl+C', 'error');
    return ok;
  }

  /** 复制图片到剪贴板；非 PNG 先转成 PNG，因为系统剪贴板只收 image/png */
  async function copyImageToClipboard(src) {
    try {
      const res = await fetch(src);
      if (!res.ok) throw new Error('图片读取失败');
      let blob = await res.blob();
      if (blob.type !== 'image/png') {
        const bmp = await createImageBitmap(blob);
        try {
          const canvas = document.createElement('canvas');
          canvas.width = bmp.width;
          canvas.height = bmp.height;
          canvas.getContext('2d').drawImage(bmp, 0, 0);
          blob = await new Promise((resolve, reject) => {
            canvas.toBlob(b => b ? resolve(b) : reject(new Error('图片转换失败')), 'image/png');
          });
        } finally {
          if (bmp.close) bmp.close();
        }
      }
      if (!navigator.clipboard || typeof ClipboardItem === 'undefined') {
        throw new Error('当前环境不支持复制图片');
      }
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      toast('图片已复制');
      return true;
    } catch (err) {
      toast('复制图片失败：' + (err && err.message ? err.message : err), 'error');
      return false;
    }
  }

  // ------------------------------------------------------------ 选中文字引用

  let quoteUI = null;
  let quoteTipUI = null;
  let quoteTipSeq = 0;
  let quoteTipAnchor = null;
  let quoteSel = null;        // 当前选区：{ text, source, sourceId, role }
  let quoteTarget = null;     // “引用至其他对话”待处理的引用
  let quoteSelTimer = 0;

  function ensureQuoteUI() {
    if (quoteUI) return quoteUI;

    const style = document.createElement('style');
    style.id = 'quote-ui-style';
    style.textContent = `
      .sel-toolbar { position: fixed; z-index: 85; display: flex; align-items: center; padding: 2px; border: 1px solid var(--line-2); border-radius: 8px; background: var(--panel); box-shadow: var(--shadow); }
      .sel-toolbar button { padding: 3px 7px; border-radius: 6px; font-size: 11px; color: var(--fg-2); white-space: nowrap; }
      .sel-toolbar button:hover { background: var(--panel-2); color: var(--fg); }
      .sel-toolbar .sel-sep { width: 1px; height: 12px; margin: 0 2px; background: var(--line-2); }
      .quote-pick-ic { flex: 0 0 22px; height: 22px; margin-top: 1px; display: grid; place-items: center; border-radius: 6px; background: var(--panel-2); color: var(--accent); font-size: 13px; }
      .quote-target-modal { height: min(540px, calc(100vh - 80px)); }
      .ref-chip.quote-chip .ref-chip-ic { color: var(--accent); }
      .ref-chip.conv-chip { border-color: var(--accent-line); background: rgba(229,145,99,.06); }
      .ref-chip.conv-chip .ref-chip-ic { color: var(--accent); }
      .bubble-quote { margin: 0 0 7px; padding: 6px 8px; border-left: 2px solid var(--accent-line); border-radius: 6px; background: rgba(255,255,255,.055); }
      .bubble-quote-text { font-size: 12px; line-height: 1.45; color: var(--accent); }
      .bubble-quote-src { margin-top: 2px; font-size: 10.5px; color: var(--fg-4); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .quote-tip { position: fixed; z-index: 96; pointer-events: none; max-width: min(460px, calc(100vw - 24px)); max-height: 320px; overflow: auto; padding: 9px 11px; border: 1px solid var(--line-2); border-radius: 9px; background: #15181e; box-shadow: var(--shadow); font-size: 12px; line-height: 1.55; color: var(--fg-2); }
      .quote-tip-text { white-space: pre-wrap; word-break: break-word; }
      .quote-tip-src { margin-top: 6px; padding-top: 6px; border-top: 1px solid var(--line); color: var(--fg-4); font-size: 10.5px; }
      .quote-tip-title { font-size: 12.5px; font-weight: 600; color: var(--fg); word-break: break-word; }
      .quote-tip-row { margin-top: 4px; font-size: 11px; color: var(--fg-3); word-break: break-all; }
    `;
    document.head.appendChild(style);

    const tb = document.createElement('div');
    tb.id = 'selToolbar';
    tb.className = 'sel-toolbar';
    tb.hidden = true;
    tb.innerHTML = '<button type="button" data-sel-act="quote">引用</button><span class="sel-sep"></span><button type="button" data-sel-act="other">引用至其他对话</button>';
    document.body.appendChild(tb);

    const modal = document.createElement('div');
    modal.id = 'quoteTargetModal';
    modal.className = 'modal-backdrop';
    modal.hidden = true;
    modal.innerHTML = `
      <div class="modal feat-modal quote-target-modal" role="dialog" aria-modal="true" aria-label="引用至其他对话">
        <div class="modal-head">
          <b>引用至其他对话</b>
          <button class="icon-btn" data-close title="关闭（Esc）">
            <svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>
          </button>
        </div>
        <div class="feat-body">
          <input class="feat-search" id="quoteTargetSearch" type="text" placeholder="搜索对话标题、内容或文件夹…" spellcheck="false" autocomplete="off">
          <div class="feat-hint">只带被选中的这段原文和出处，不会读取来源对话的其它内容；也可以直接新建一个对话。</div>
          <div class="feat-list" id="quoteTargetList"></div>
        </div>
        <div class="modal-foot dialog-foot">
          <button class="btn" data-cancel>取消</button>
        </div>
      </div>`;
    document.body.appendChild(modal);

    const search = modal.querySelector('#quoteTargetSearch');
    const list = modal.querySelector('#quoteTargetList');

    // mousedown 阻止默认行为，点浮动条时不会把选区弄丢
    tb.addEventListener('mousedown', e => e.preventDefault());
    tb.addEventListener('click', e => {
      const btn = e.target.closest('[data-sel-act]');
      if (!btn) return;
      const q = quoteSel;
      hideSelectionToolbar();
      if (!q || !q.text.trim()) return;
      if (btn.dataset.selAct === 'quote') {
        const sel = window.getSelection();
        if (sel) sel.removeAllRanges();
        if (addPendingQuote(q)) toast('已加入引用');
      } else {
        openQuoteTargetModal(q);
      }
    });

    modal.addEventListener('click', e => {
      if (e.target === modal || e.target.closest('[data-close], [data-cancel]')) closeQuoteTargetModal();
    });
    search.addEventListener('input', renderQuoteTargetList);

    quoteUI = { tb, modal, search, list };
    return quoteUI;
  }

  function scheduleSelectionToolbar() {
    clearTimeout(quoteSelTimer);
    quoteSelTimer = setTimeout(updateSelectionToolbar, 120);
  }

  function updateSelectionToolbar() {
    quoteSelTimer = 0;
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount || !sel.anchorNode || !transcriptEl.contains(sel.anchorNode)) {
      hideSelectionToolbar();
      return;
    }
    const text = sel.toString();
    if (!text.trim()) { hideSelectionToolbar(); return; }
    showSelectionToolbar(sel, captureQuote(sel, text));
  }

  /** 记录选区的文字和出处（来源对话、是用户消息还是 Claude 回复） */
  function captureQuote(sel, text) {
    let role = '';
    try {
      const node = sel.anchorNode && (sel.anchorNode.nodeType === 1 ? sel.anchorNode : sel.anchorNode.parentElement);
      if (node && node.closest) {
        if (node.closest('.steer-inline, .bubble.steer')) role = 'user';
        else {
          const msg = node.closest('#messages .msg');
          if (msg) role = msg.classList.contains('user') ? 'user' : 'assistant';
        }
      }
    } catch { /* 跨节点选区忽略角色 */ }
    return {
      text,
      source: (S.conv && (S.conv.title || '新对话')) || '当前对话',
      sourceId: (S.conv && S.conv.id) || '',
      role
    };
  }

  function showSelectionToolbar(sel, quote) {
    const ui = ensureQuoteUI();
    quoteSel = quote;
    ui.tb.hidden = false;
    ui.tb.style.visibility = 'hidden';
    const rect = sel.getRangeAt(0).getBoundingClientRect();
    if (!rect.width && !rect.height) { hideSelectionToolbar(); return; }
    // 选区滚出视口后不再显示，避免浮动条停在屏幕边缘
    if (rect.bottom < 0 || rect.top > innerHeight) { hideSelectionToolbar(); return; }
    const size = ui.tb.getBoundingClientRect();
    let left = rect.left + rect.width / 2 - size.width / 2;
    left = Math.max(8, Math.min(left, innerWidth - size.width - 8));
    let top = rect.top - size.height - 8;
    if (top < 8) top = rect.bottom + 8;
    top = Math.max(8, Math.min(top, innerHeight - size.height - 8));
    ui.tb.style.left = Math.round(left) + 'px';
    ui.tb.style.top = Math.round(top) + 'px';
    ui.tb.style.visibility = '';
  }

  function hideSelectionToolbar() {
    clearTimeout(quoteSelTimer);
    quoteSelTimer = 0;
    if (quoteUI && !quoteUI.tb.hidden) {
      quoteUI.tb.hidden = true;
      quoteUI.tb.style.visibility = '';
    }
  }

  function addPendingQuote(q) {
    if (!q || !String(q.text || '').trim()) return false;
    const sourceId = q.sourceId || '';
    if (S.pendingQuotes.some(x => x.text === q.text && (x.sourceId || '') === sourceId)) {
      toast('这段已经引用过了');
      return false;
    }
    if (S.pendingQuotes.length >= 5) {
      toast('最多同时引用 5 段文字');
      return false;
    }
    S.pendingQuotes.push({
      id: 'q' + (++S.quoteSeq),
      text: q.text,
      source: q.source || '当前对话',
      sourceId,
      role: q.role || ''
    });
    renderAttachments();
    updateComposerState();
    inputEl.focus();
    return true;
  }

  /** 发送时把引用拼成结构化文本，让模型知道出处，但只带这一段原文 */
  function quoteBlock(q) {
    const meta = JSON.stringify({
      source: String(q.source || ''),
      conv: String(q.sourceId || ''),
      role: String(q.role || '')
    });
    const excerpt = String(q.text || '')
      .replace(/\r\n?/g, '\n')
      .replace(/<\/?gui-quote/gi, m => '&lt;' + m.slice(1))
      .trim();
    return '<gui-quote>\n' + meta + '\n' + excerpt + '\n</gui-quote>';
  }

  function withQuotes(text, quotes) {
    const blocks = (quotes || []).map(quoteBlock).filter(Boolean).join('\n\n');
    const t = String(text || '').trim();
    return blocks ? (blocks + (t ? '\n\n' + t : '')) : t;
  }

  function openQuoteTargetModal(q) {
    const ui = ensureQuoteUI();
    quoteTarget = q;
    ui.search.value = '';
    ui.modal.hidden = false;
    renderQuoteTargetList();
    setTimeout(() => { try { ui.search.focus(); } catch { /* ignore */ } }, 30);
  }

  function closeQuoteTargetModal() {
    if (quoteUI) quoteUI.modal.hidden = true;
  }

  function renderQuoteTargetList() {
    const ui = quoteUI;
    if (!ui) return;
    const q = String(ui.search.value || '').trim().toLowerCase();
    const list = ui.list;
    list.innerHTML = '';

    const newRow = document.createElement('button');
    newRow.type = 'button';
    newRow.className = 'feat-item';
    newRow.innerHTML = `
      <span class="quote-pick-ic">＋</span>
      <span class="feat-main">
        <span class="feat-title"><b>新对话</b></span>
        <span class="feat-desc">在当前文件夹新建对话，并把这段引用带过去</span>
      </span>`;
    newRow.addEventListener('click', () => chooseQuoteTarget(null));
    list.appendChild(newRow);

    const convs = allConversations()
      .filter(c => !S.conv || c.id !== S.conv.id)
      .filter(c => {
        if (!q) return true;
        return [c.title, c.preview, c.folder].some(x => String(x || '').toLowerCase().includes(q));
      })
      .sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0));

    for (const c of convs) {
      const row = document.createElement('button');
      row.type = 'button';
      row.className = 'feat-item';
      const folderName = String(c.folder || '').split(/[\\/]/).filter(Boolean).pop() || c.folder || '';
      row.innerHTML = `
        <span class="quote-pick-ic">↗</span>
        <span class="feat-main">
          <span class="feat-title"><b>${escapeHtml(c.title || '未命名对话')}</b></span>
          <span class="feat-desc">${escapeHtml(c.preview || '（没有预览）')}</span>
          <span class="feat-meta">${escapeHtml(folderName)} · ${escapeHtml(timeAgo(c.updatedAt))} · ${Number(c.turns) || 0} 轮</span>
        </span>`;
      row.addEventListener('click', () => chooseQuoteTarget(c.id));
      list.appendChild(row);
    }

    if (q && !convs.length) {
      const empty = document.createElement('div');
      empty.className = 'feat-empty';
      empty.textContent = '没有匹配的对话，可以使用上面的“新对话”。';
      list.appendChild(empty);
    }
  }

  async function chooseQuoteTarget(targetId) {
    const q = quoteTarget;
    quoteTarget = null;
    closeQuoteTargetModal();
    if (!q || !String(q.text || '').trim()) return;
    try {
      if (!targetId) {
        let cwd = S.currentFolder || (S.conv && S.conv.cwd) || null;
        if (!cwd) cwd = await chooseFolder();
        if (!cwd) return;
        const conv = await api('/conversation', { method: 'POST', body: JSON.stringify({ cwd }) });
        await refreshBoot();
        await openConversation(conv.id);
        addPendingQuote(q);
        toast('已新建对话并引用');
      } else {
        await openConversation(targetId);
        addPendingQuote(q);
        toast('已引用到输入框');
      }
    } catch (e) {
      toast('引用失败：' + e.message, 'error');
    }
  }

  function ensureQuoteTip() {
    if (quoteTipUI) return quoteTipUI;
    const tip = document.createElement('div');
    tip.id = 'quoteTip';
    tip.className = 'quote-tip';
    tip.hidden = true;
    document.body.appendChild(tip);
    quoteTipUI = tip;
    return tip;
  }

  function placeQuoteTip(tip, anchor) {
    tip.hidden = false;
    tip.style.visibility = 'hidden';
    const r = anchor.getBoundingClientRect();
    const size = tip.getBoundingClientRect();
    let left = r.left + r.width / 2 - size.width / 2;
    left = Math.max(8, Math.min(left, innerWidth - size.width - 8));
    let top = r.top - size.height - 8;
    if (top < 8) top = r.bottom + 8;
    top = Math.max(8, Math.min(top, innerHeight - size.height - 8));
    tip.style.left = Math.round(left) + 'px';
    tip.style.top = Math.round(top) + 'px';
    tip.style.visibility = '';
  }

  function showQuoteTip(anchor, q) {
    quoteTipSeq++;
    quoteTipAnchor = anchor;
    const tip = ensureQuoteTip();
    tip.innerHTML = '';
    const text = document.createElement('div');
    text.className = 'quote-tip-text';
    text.textContent = String(q.text || '');
    const src = document.createElement('div');
    src.className = 'quote-tip-src';
    src.textContent = quoteSourceLabel(q);
    tip.append(text, src);
    placeQuoteTip(tip, anchor);
  }

  /** 引用对话 chip 的悬停浮窗：项目文件夹 + 当前上下文用量 */
  function showConvRefTip(anchor, ref) {
    quoteTipSeq++;
    const seq = quoteTipSeq;
    quoteTipAnchor = anchor;
    const tip = ensureQuoteTip();
    tip.innerHTML = '';

    const title = document.createElement('div');
    title.className = 'quote-tip-title';
    title.textContent = ref.title || '未命名对话';
    const folder = document.createElement('div');
    folder.className = 'quote-tip-row';
    folder.textContent = '项目文件夹：' + (ref.cwd || '未知');
    const ctx = document.createElement('div');
    ctx.className = 'quote-tip-row';
    ctx.textContent = '上下文：读取中…';
    tip.append(title, folder, ctx);
    placeQuoteTip(tip, anchor);

    const fill = tokens => {
      if (seq !== quoteTipSeq || quoteTipAnchor !== anchor || !quoteTipUI || quoteTipUI.hidden) return;
      const n = Number(tokens);
      if (!isFinite(n) || n <= 0) {
        ctx.textContent = ref.turns > 0
          ? '上下文：暂无数据（重启客户端后刷新）'
          : '上下文：暂无（还没有消息）';
        return;
      }
      const pct = Math.min(100, n / CONTEXT_LIMIT * 100);
      ctx.textContent = '上下文：' + fmtTok(n) + ' tokens（约 ' +
        (pct < 1 ? pct.toFixed(1) : Math.round(pct)) + '% / 1M）';
    };

    if (typeof ref.contextTokens === 'number') {
      fill(ref.contextTokens);
      return;
    }
    api('/conversation?id=' + encodeURIComponent(ref.id) + '&handoff=1')
      .then(c => {
        ref.contextTokens = typeof c.contextTokens === 'number' ? c.contextTokens : -1;
        fill(ref.contextTokens);
      })
      .catch(() => {
        if (seq === quoteTipSeq && quoteTipAnchor === anchor && quoteTipUI && !quoteTipUI.hidden) {
          ctx.textContent = '上下文：读取失败';
        }
      });
  }

  function hideQuoteTip() {
    quoteTipSeq++;
    quoteTipAnchor = null;
    if (quoteTipUI) {
      quoteTipUI.hidden = true;
      quoteTipUI.style.visibility = '';
    }
  }

  function initQuoteSelection() {
    ensureQuoteUI();
    ensureQuoteTip();
    document.addEventListener('selectionchange', scheduleSelectionToolbar);
    // 滚动/缩放时跟着选区重新定位，而不是直接消失（打开对话时的自动贴底也会触发滚动）
    transcriptEl.addEventListener('scroll', scheduleSelectionToolbar, { passive: true });
    window.addEventListener('resize', scheduleSelectionToolbar);
    // 滚出位置后引用提示浮框跟着收起；浮框自己内部滚动时不收
    document.addEventListener('scroll', e => {
      if (quoteTipUI && (e.target === quoteTipUI || quoteTipUI.contains(e.target))) return;
      hideQuoteTip();
    }, true);
    window.addEventListener('resize', hideQuoteTip);
    document.addEventListener('keydown', e => {
      if (e.key !== 'Escape') return;
      hideSelectionToolbar();
      hideQuoteTip();
      closeQuoteTargetModal();
    });
  }

  // ------------------------------------------------------------ 输入框右键菜单

  const IS_MAC = /Mac|iPhone|iPad/i.test(navigator.platform || '');
  const MOD = IS_MAC ? '⌘' : 'Ctrl+';

  function insertTextAtCursor(text) {
    const start = inputEl.selectionStart ?? inputEl.value.length;
    const end = inputEl.selectionEnd ?? start;
    inputEl.value = inputEl.value.slice(0, start) + text + inputEl.value.slice(end);
    const pos = start + text.length;
    inputEl.setSelectionRange(pos, pos);
    autoGrow();
    updateComposerState();
  }

  async function pasteFromClipboard() {
    if (window.guiDesktop && typeof window.guiDesktop.edit === 'function') {
      window.guiDesktop.edit('paste');
      return;
    }

    let text = '';
    try {
      if (navigator.clipboard && navigator.clipboard.read) {
        const items = await navigator.clipboard.read();
        const files = [];
        for (const item of items) {
          let taken = false;
          for (const type of item.types) {
            if (!taken && /^image\//i.test(type)) {
              const blob = await item.getType(type);
              const ext = type.split('/')[1] || 'png';
              files.push(new File([blob], `粘贴的图片.${ext}`, { type }));
              taken = true;
            } else if (type === 'text/plain') {
              text += await (await item.getType(type)).text();
            }
          }
        }
        if (files.length) await stageFiles(files);
        if (text) insertTextAtCursor(text);
        if (files.length || text) return;
      }
    } catch { /* 退回到纯文本读取 */ }

    try {
      text = await navigator.clipboard.readText();
      if (text) insertTextAtCursor(text);
    } catch {
      toast(`无法读取剪贴板，请直接按 ${MOD}V 粘贴`, 'error');
    }
  }

  function runEditCommand(cmd) {
    closeMenu();
    inputEl.focus();

    if (window.guiDesktop && typeof window.guiDesktop.edit === 'function') {
      window.guiDesktop.edit(cmd);
      return;
    }

    if (cmd === 'selectAll') { inputEl.select(); return; }
    if (cmd === 'cut' || cmd === 'copy') {
      let ok = false;
      try { ok = document.execCommand(cmd); } catch { ok = false; }
      if (!ok) toast(`当前浏览器不允许自动${cmd === 'cut' ? '剪切' : '复制'}，请使用快捷键`, 'error');
      return;
    }
    if (cmd === 'paste') pasteFromClipboard();
  }

  function showInputMenu(x, y) {
    const hasSel = inputEl.selectionStart !== inputEl.selectionEnd;
    const hasText = inputEl.value.length > 0;
    showMenu(x, y, [
      { label: '剪切', hint: MOD + 'X', disabled: !hasSel, onClick: () => runEditCommand('cut') },
      { label: '复制', hint: MOD + 'C', disabled: !hasSel, onClick: () => runEditCommand('copy') },
      { label: '粘贴', hint: MOD + 'V', onClick: () => runEditCommand('paste') },
      { sep: true },
      { label: '全选', hint: MOD + 'A', disabled: !hasText, onClick: () => runEditCommand('selectAll') }
    ], { keepFocus: true });
  }

  async function send() {
    // 只拦当前对话自己的压缩任务；别的对话在后台压缩不应影响这里发送
    if (S.compacting && S.conv && S.compactConvId === S.conv.id) return;
    const text = inputEl.value.trim();
    if (!text && !S.pendingImages.length && !S.pendingFiles.length && !S.pendingQuotes.length) return;
    if (text.startsWith('/') && (S.pendingFiles.length || S.pendingQuotes.length)) {
      toast('斜杠命令不能同时引用文件或文字，请先移除引用', 'warn');
      return;
    }
    if (S.running) { await sendSteer(text); return; }
    if (!S.guardStopRequested) S.guardWarned = false;
    if (!S.guardAutoResuming) S.guardAutoResumeCount = 0;

    if (!S.conv) {
      let cwd = S.currentFolder;
      if (!cwd) {
        cwd = await chooseFolder();
        if (!cwd) return;
      }
      try {
        const conv = await api('/conversation', { method: 'POST', body: JSON.stringify({ cwd }) });
        await refreshBoot();
        // 输入框里就是这条要发的消息，不能被新建对话的空草稿覆盖
        await openConversation(conv.id, { keepComposer: true });
      } catch (e) {
        toast(e.message, 'error');
        return;
      }
    }

    const sendConvId = S.conv.id;

    // 上下文接近上限：先压缩，再发这条消息
    if (shouldAutoCompact(text)) {
      const ok = await runAutoCompact();
      if (!ok) return;
      if (!S.conv || S.conv.id !== sendConvId) {
        toast('已切换对话，这条消息没有发送');
        return;
      }
    }

    // 引用对话：按当前问题筛选片段，避免整份读入
    const useRefs = !text.startsWith('/') && S.pendingRefs.length > 0;
    const sentRefs = useRefs ? S.pendingRefs.slice() : [];
    const sentFiles = S.pendingFiles.slice();
    const sentQuotes = S.pendingQuotes.slice();
    let payloadText = text;
    if (sentRefs.length) {
      setStatus('正在整理引用内容…', 'warn');
      try {
        // 只把来源就在被引用对话里的文字引用作为额外筛选词，避免无关引用干扰轮次选择
        const extraQuoteText = sentQuotes
          .filter(q => sentRefs.some(r => r.id === q.sourceId))
          .map(q => String(q.text || '').slice(0, 1200))
          .join('\n')
          .slice(0, 3000);
        payloadText = await composeWithRefs(text, sentRefs, extraQuoteText);
      } catch (e) {
        setStatus('已连接', 'ok');
        toast('读取引用对话失败：' + e.message, 'error');
        return;
      }
      setStatus('已连接', 'ok');
    }
    // 发送顺序：引用文字 → 你的问题 → 引用对话片段 → 文件引用。
    // 显示上引用对话排前面，但发给模型时先放被引用的原话，再看引用对话的筛选片段。
    payloadText = withFileRefs(withQuotes(payloadText, sentQuotes), sentFiles);

    if (!S.conv || S.conv.id !== sendConvId) {
      toast('已切换对话，这条消息没有发送');
      return;
    }

    const sentImages = S.pendingImages.slice();
    const sentIds = new Set(sentImages.map(i => i.id));
    const sentFileIds = new Set(sentFiles.map(f => f.id));
    const sentQuoteIds = new Set(sentQuotes.map(q => q.id));

    inputEl.value = '';
    S.pendingImages = S.pendingImages.filter(i => !sentIds.has(i.id));
    S.pendingFiles = S.pendingFiles.filter(f => !sentFileIds.has(f.id));
    S.pendingQuotes = S.pendingQuotes.filter(q => !sentQuoteIds.has(q.id));
    if (sentRefs.length) S.pendingRefs = [];
    renderAttachments();
    autoGrow();
    S.stick = true;
    S.manualCompact = text === '/compact';
    S.manualCompactConvId = S.manualCompact ? S.conv.id : null;
    if (S.manualCompact) syncCompactionProgress();

    try {
      await api('/chat', {
        method: 'POST',
        body: JSON.stringify({
          id: S.conv.id,
          text: payloadText,
          images: sentImages.map(i => ({ media_type: i.media_type, data: i.data }))
        })
      });
      S.drafts.delete(sendConvId);
      setConvPreview(sendConvId, text || (sentQuotes.length ? '[引用] ' + quotePreview(sentQuotes[0].text)
        : (sentImages.length ? '[图片]' : (sentFiles.length ? '[文件引用]' : ''))));
    } catch (e) {
      S.manualCompact = false;
      S.manualCompactConvId = null;
      toast(e.message, 'error');
      inputEl.value = text;
      S.pendingImages = sentImages.concat(S.pendingImages);
      S.pendingFiles = sentFiles.concat(S.pendingFiles);
      S.pendingQuotes = sentQuotes.concat(S.pendingQuotes);
      if (sentRefs.length) S.pendingRefs = sentRefs;
      renderAttachments();
      autoGrow();
    }
  }

  async function sendSteer(text) {
    if (!S.conv) return;
    const sendConvId = S.conv.id;

    const sentImages = S.pendingImages.slice();
    const sentFiles = S.pendingFiles.slice();
    const sentQuotes = S.pendingQuotes.slice();
    if (!text && !sentImages.length && !sentFiles.length && !sentQuotes.length) return;
    const sentIds = new Set(sentImages.map(i => i.id));
    const sentFileIds = new Set(sentFiles.map(f => f.id));
    const sentQuoteIds = new Set(sentQuotes.map(q => q.id));
    // 插话同样先放引用文字，再放文件和对话引用
    const payloadText = withFileRefs(withQuotes(text, sentQuotes), sentFiles);

    inputEl.value = '';
    S.pendingImages = S.pendingImages.filter(i => !sentIds.has(i.id));
    S.pendingFiles = S.pendingFiles.filter(f => !sentFileIds.has(f.id));
    S.pendingQuotes = S.pendingQuotes.filter(q => !sentQuoteIds.has(q.id));
    renderAttachments();
    autoGrow();
    S.stick = true;

    try {
      await api('/steer', {
        method: 'POST',
        body: JSON.stringify({
          id: sendConvId,
          text: payloadText,
          images: sentImages.map(i => ({ media_type: i.media_type, data: i.data }))
        })
      });
      S.drafts.delete(sendConvId);
      setConvPreview(sendConvId, text || (sentQuotes.length ? '[引用] ' + quotePreview(sentQuotes[0].text)
        : (sentImages.length ? '[图片]' : (sentFiles.length ? '[文件引用]' : ''))));
    } catch (e) {
      toast(e.message, 'error');
      inputEl.value = text;
      S.pendingImages = sentImages.concat(S.pendingImages);
      S.pendingFiles = sentFiles.concat(S.pendingFiles);
      S.pendingQuotes = sentQuotes.concat(S.pendingQuotes);
      renderAttachments();
      autoGrow();
    }
  }

  function updateComposerState() {
    if (S.compacting && S.compactConvId === (S.conv && S.conv.id)) {
      sendBtn.hidden = false;
      sendBtn.classList.remove('steer-mode');
      sendBtn.title = '正在压缩上下文…';
      stopBtn.hidden = false;
      inputEl.placeholder = '正在压缩上下文…';
      $('#composerHint').textContent = '上下文接近上限，正在自动压缩（点「停止」可取消）';
      return;
    }
    const running = S.running;
    sendBtn.hidden = false;
    sendBtn.classList.toggle('steer-mode', running);
    sendBtn.title = running ? '插话（当前步骤结束后生效）' : '发送';
    stopBtn.hidden = !running;
    inputEl.placeholder = S.conv
      ? (running ? '输入插话，Enter 发送…' : '给 Claude 布置任务…（可拖入文件/文件夹、粘贴截图）')
      : (S.currentFolder ? '输入任务，Enter 发送…（可拖入文件/文件夹）' : '先选择一个文件夹…');
    stopBtn.disabled = false;
  }

  // ------------------------------------------------------------ 顶部栏

  function updateChrome() {
    const folder = (S.conv && S.conv.cwd) || S.currentFolder || '';
    $('#convTitle').textContent = (S.conv && S.conv.title) || '新对话';
    const pathText = $('#folderPathText');
    pathText.textContent = folder || '未选择文件夹';
    pathText.classList.toggle('mono', !!folder);
    $('#folderPath').disabled = !folder;

    const mode = (S.conv && S.conv.permissionMode) || S.settings.defaultPermissionMode;
    const sel = $('#permSelect');
    if (sel.value !== mode) sel.value = mode;
    const wrap = $('#permWrap');
    wrap.className = 'select-wrap' + (mode === 'bypassPermissions' ? ' bypass'
      : mode === 'plan' ? ' plan' : mode === 'acceptEdits' ? ' acceptEdits' : '');
    wrap.title = mode === 'bypassPermissions'
      ? '全部放行：不询问、不拦截，请只在信任的文件夹使用'
      : mode === 'plan' ? '只读规划：不会修改文件'
        : mode === 'acceptEdits' ? '自动接受编辑' : '自动判断';

    // 没有打开对话时，下拉框显示“全局默认选择”，改完不会弹回“默认”
    const modelVal = S.conv ? (S.conv.model || '') : (S.settings.defaultModelChoice || '');
    const modelSel = $('#modelSelect');
    if (modelVal && !Array.from(modelSel.options).some(o => o.value === modelVal)) {
      modelSel.appendChild(new Option(modelVal, modelVal));
    }
    if (modelSel.value !== modelVal) modelSel.value = modelVal;

    const effortVal = S.conv ? (S.conv.effort || '') : (S.settings.defaultEffort || '');
    const effortSel = $('#effortSelect');
    if (effortVal && !Array.from(effortSel.options).some(o => o.value === effortVal)) {
      effortSel.appendChild(new Option(effortVal, effortVal));
    }
    if (effortSel.value !== effortVal) effortSel.value = effortVal;

    const hint = S.running
      ? 'Claude 正在处理… 输入内容会作为插话，在当前步骤结束后生效'
      : (folder ? `工作目录：${folder}` : 'Enter 发送 · Shift + Enter 换行 · 可拖入文件/文件夹');
    $('#composerHint').textContent = hint;
  }

  // ------------------------------------------------------------ SSE

  function connectSSE() {
    const es = new EventSource('/api/stream?token=' + encodeURIComponent(TOKEN));
    es.onopen = () => setStatus('已连接', 'ok');
    es.onerror = () => setStatus('连接已断开，正在重连…', 'warn');
    es.onmessage = ev => {
      let data;
      try { data = JSON.parse(ev.data); } catch { return; }
      handleEvent(data);
    };
  }

  function isCurrent(ev) {
    return S.conv && ev.convId === S.conv.id;
  }

  function handleEvent(ev) {
    if (S.switchBuf && ev.convId === S.switchBuf.id && S.switchBuf.events.length < 6000) {
      S.switchBuf.events.push(ev);
    }
    const cur = isCurrent(ev);

    switch (ev.t) {
      case 'user_echo':
        if (cur) {
          const msg = ev.message || {};
          const slashCompact = msg.text === '/compact' && (S.compacting || S.manualCompact);
          const summary = isCompactSummaryMessage(msg);
          if (slashCompact) {
            // 压缩命令本身不显示成用户气泡
          } else if (summary) {
            addCompactDivider();
          } else if (msg.steer && S.currentRun) {
            noteChatActivityTime(msg.ts);
            addInlineSteer(S.currentRun, msg.text, msg.images);
          } else {
            maybeAddChatTime(msg.ts);
            addUserBubble(msg.text, msg.images, { steer: !!msg.steer });
          }
          if (!slashCompact && !summary) {
            S.stick = true;
            scrollToBottom(true);
          }
        }
        markConversationStarted(ev.convId);
        renderFolders();
        break;

      case 'run_start':
        S.runningIds.add(ev.convId);
        markConversationStarted(ev.convId);
        notifyDesktopBusy();
        if (cur) {
          S.running = true;
          S.joinedMidRun = false;
          S.guardWarned = false;
          updateCtxHint();
          // 压缩过程不建空的回复行，结束后界面保持干净
          if (!S.currentRun && !S.compacting) ensureRun();
          syncCompactionProgress();
          S.stick = nearBottom() || S.stick;
          updateComposerState();
          updateChrome();
        }
        renderFolders();
        break;

      case 'msg_start':
        break;

      case 'block_start':
        // 空的思考块先不建，等第一个 delta 到达再显示，避免出现「思考 0 字」
        if (cur && ev.block && ev.block.type !== 'thinking') ensureBlock(ev.key, ev.block);
        break;

      case 'delta':
        if (cur) {
          const run = ensureRun();
          let b = run.blocks.get(ev.key);
          if (!b) {
            if (ev.kind === 'text') b = ensureBlock(ev.key, { type: 'text' });
            else if (ev.kind === 'thinking') b = ensureBlock(ev.key, { type: 'thinking' });
          }
          if (!b) break;
          if (ev.kind === 'text') { b.text += ev.text; schedulePaint(b); }
          else if (ev.kind === 'thinking') { b.text += ev.text; schedulePaint(b); }
        }
        break;

      case 'block_set':
        if (cur) {
          const run = ensureRun();
          let b = run.blocks.get(ev.key);
          if (!b) b = ensureBlock(ev.key, ev.block);
          if (b) {
            updateToolBlock(b, ev.block);
            b.statusEl.className = 'tool-status';
            b.statusEl.innerHTML = '<span class="spin"></span>';
            refreshActivitySummary(run);
            if (b.type === 'tool_use') maybeAddAutoStage(run, b);
          }
        }
        break;

      case 'tool_result':
        if (cur && S.currentRun && S.currentRun.toolMap) {
          const b = S.currentRun.toolMap.get(ev.toolUseId);
          if (b) {
            setToolResult(b, ev.content, ev.isError);
            b.hasResult = true;
            b.resultOk = !ev.isError;
            refreshActivitySummary(S.currentRun);
          }
        }
        break;

      case 'permission': {
        const isPlan = ev.toolName === 'ExitPlanMode';
        if (!isWindowActive() || !S.conv || S.conv.id !== ev.convId) {
          attentionAdd(ev.convId, isPlan ? '等你确认计划' : '等你确认操作');
          if (!isWindowActive()) {
            notifyDesktop(
              isPlan ? 'Claude 的计划待确认' : 'Claude 需要确认操作',
              `${convTitleOf(ev.convId)}：${isPlan ? '计划已就绪' : (ev.toolName || '工具')}`,
              ev.convId
            );
          }
        }
        if (cur) showPermission(ev);
        break;
      }

      case 'permission_resolved':
        if (cur && S.pendingPerm && S.pendingPerm.requestId === ev.requestId) hidePermission();
        if (S.attention.has(ev.convId)) {
          if (isWindowActive() && S.conv && S.conv.id === ev.convId) attentionRemove(ev.convId);
          else {
            S.attentionInfo.set(ev.convId, ev.allow ? '权限已允许' : '权限已拒绝');
            refreshAttention();
          }
        }
        break;

      case 'ask': {
        S.askIds.add(ev.convId);
        renderFolders();
        if (!isWindowActive() || !S.conv || S.conv.id !== ev.convId) {
          attentionAdd(ev.convId, '等你回答问题');
          if (!isWindowActive()) {
            const q = (ev.questions && ev.questions[0] && ev.questions[0].question) || '';
            const suffix = ev.major ? '' : '（40 秒后按推荐继续）';
            notifyDesktop('Claude 在等你回答', `${convTitleOf(ev.convId)}：${q}${suffix}`, ev.convId);
          }
        }
        if (cur) {
          showAsk(ev);
        } else {
          const found = S.folders.flatMap(f => f.conversations || []).find(c => c.id === ev.convId);
          toast(`「${(found && found.title) || '另一个对话'}」在等你回答`);
        }
        break;
      }

      case 'ask_resolved':
        S.askIds.delete(ev.convId);
        renderFolders();
        if (cur && S.pendingAsk && S.pendingAsk.requestId === ev.requestId) {
          hideAsk();
          if (ev.timeout) toast('长时间未回答，已自动暂停这一轮');
          else if (ev.auto) toast('已按推荐选项自动继续');
          else if (ev.cancelled) toast('已跳过这个问题');
        }
        if (S.attention.has(ev.convId)) {
          if (isWindowActive() && S.conv && S.conv.id === ev.convId) attentionRemove(ev.convId);
          else {
            const text = ev.timeout ? '问题等待超时' : ev.auto ? '问题已按推荐处理' : ev.cancelled ? '问题已跳过' : '问题已回答';
            S.attentionInfo.set(ev.convId, text);
            refreshAttention();
          }
        }
        break;

      case 'run_end': {
        const wasCompacting = !!(S.compacting && ev.convId === S.compactConvId);
        const guardStop = !!(S.guardStopRequested && S.guardStopConvId === ev.convId);
        if (guardStop) {
          S.guardStopRequested = false;
          S.guardStopConvId = null;
          S.guardWarned = false;
        }
        S.runningIds.delete(ev.convId);
        S.askIds.delete(ev.convId);
        notifyDesktopBusy();
        if (wasCompacting) {
          attentionRemove(ev.convId);
        } else if (ev.stopped) {
          attentionRemove(ev.convId);
        } else if (!isWindowActive() || !S.conv || S.conv.id !== ev.convId) {
          const kind = ev.error ? '任务出错' : '任务已完成';
          attentionAdd(ev.convId, kind);
          if (!isWindowActive()) notifyDesktop(kind, convTitleOf(ev.convId), ev.convId);
        } else {
          attentionRemove(ev.convId);
        }
        if (cur) { hideAsk(); endRun(ev); }
        else renderFolders();

        if (wasCompacting) {
          const ok = !ev.error && !ev.stopped;
          S.compacting = false;
          S.compactConvId = null;
          if (ok) S.contextTokens = S.compactPostTokens || 0;
          S.compactPostTokens = 0;
          updateContextBadge();
          updateComposerState();
          if (!ok && ev.error) toast('自动压缩失败：' + ev.error, 'error');
          const w = S.compactWaiter;
          S.compactWaiter = null;
          if (w) w(ok);
        } else if (cur && S.manualCompact && S.manualCompactConvId === ev.convId) {
          if (!ev.error && !ev.stopped) {
            S.contextTokens = S.compactPostTokens || 0;
            updateContextBadge();
          }
          S.compactPostTokens = 0;
          S.manualCompact = false;
          S.manualCompactConvId = null;
        }

        if (S.cliCompactConvId === ev.convId) {
          S.cliCompacting = false;
          S.cliCompactConvId = null;
        }
        updateContextBadge();

        // 900K 轮内兜底：停止成功后，等这一轮彻底收尾，再自动压缩并自动续跑
        if (guardStop && cur && S.conv && S.conv.id === ev.convId && !S.running && !S.compacting) {
          setTimeout(() => {
            if (S.conv && S.conv.id === ev.convId && !S.running && !S.compacting) {
              runAutoCompact({ autoResume: true }).then(async ok => {
                if (!ok) return;
                if (!(S.conv && S.conv.id === ev.convId) || S.running || S.compacting) return;
                if (inputEl.value.trim() || S.pendingRefs.length || S.pendingImages.length || S.pendingFiles.length) {
                  toast('上下文已压缩；输入框里还有待发内容，请直接发送', 'warn');
                  inputEl.focus();
                  return;
                }
                if (S.guardAutoResumeCount >= 2) {
                  inputEl.value = '继续刚才的任务：';
                  autoGrow();
                  updateComposerState();
                  inputEl.focus();
                  toast('已连续自动压缩 2 次，请确认后再继续', 'warn');
                  return;
                }
                S.guardAutoResumeCount += 1;
                S.guardAutoResuming = true;
                try {
                  inputEl.value = AUTO_CONTINUE_PROMPT;
                  autoGrow();
                  updateComposerState();
                  await send();
                } finally {
                  S.guardAutoResuming = false;
                }
              });
            }
          }, 250);
        }
        refreshBootSoon();
        break;
      }

      case 'error':
        toast(ev.message, 'error');
        if (cur) abortRun(ev.message);
        break;

      case 'conv_created':
      case 'conv_removed':
        refreshBootSoon();
        break;

      case 'conv_meta': {
        if (S.conv && S.conv.id === ev.id) {
          if (ev.title !== undefined) S.conv.title = ev.title;
          if (ev.permissionMode) S.conv.permissionMode = ev.permissionMode;
          if (ev.model !== undefined) S.conv.model = ev.model;
          if (ev.effort !== undefined) S.conv.effort = ev.effort;
          updateChrome();
        }
        // 侧栏数据来自 S.folders，就地更新，自动生成的标题无需等下一次 bootstrap
        if (ev.title) {
          for (const f of S.folders) {
            const found = (f.conversations || []).find(c => c.id === ev.id);
            if (found) { found.title = ev.title; break; }
          }
        }
        renderFolders();
        break;
      }

      case 'compact_boundary':
        if (cur) {
          addCompactDivider();
          const post = Number(ev.post) || 0;
          if (post) {
            S.contextTokens = post;
            S.compactPostTokens = post;
            if (S.conv) {
              S.conv.compacted = true;
              S.ctxEpoch = Math.max(1, (S.ctxEpoch || 0) + 1);
            }
            updateContextBadge();
          }
        }
        break;

      case 'usage':
        if (cur && ev.usage) {
          const t = usageContextTokens(ev.usage);
          if (t) {
            S.contextTokens = t;
            updateContextBadge();
            maybeGuardContext(t);
          }
        }
        break;

      case 'status': {
        if (!cur) break;
        if (ev.status === 'compacting') {
          S.cliCompacting = true;
          S.cliCompactConvId = ev.convId;
          updateContextBadge();
          setStatus('正在压缩上下文…', 'warn');
          syncCompactionProgress();
        } else if ((S.cliCompacting && S.cliCompactConvId === ev.convId) || ev.compactResult) {
          if (S.cliCompactConvId === ev.convId) {
            S.cliCompacting = false;
            S.cliCompactConvId = null;
          }
          if (ev.compactResult === 'failed') {
            toast('自动压缩失败：' + String(ev.compactError || '上下文仍然超过模型上限').slice(0, 300), 'error');
          } else if (ev.compactResult === 'success') {
            toast('上下文已压缩');
          }
          updateContextBadge();
          setStatus(S.running ? 'Claude 正在工作…' : '已连接', S.running ? 'warn' : 'ok');
          if (S.currentRun && !isCompactingCurrent()) setRunProgress(S.currentRun, '', 'thinking');
        } else if (S.running) {
          setStatus('Claude 正在工作…', 'warn');
        }
        break;
      }

      default:
        break;
    }
  }

  function abortRun(message) {
    const run = S.currentRun;
    if (run) {
      for (const b of run.blocks.values()) {
        if (b.raf) cancelAnimationFrame(b.raf);
        b.raf = 0;
        if (b.type === 'text' && b.md) b.md.querySelectorAll('.caret').forEach(el => el.remove());
      }
      clearRunProgress(run);
      finalizeActivity(run, false);
      const div = document.createElement('div');
      div.className = 'block err-block';
      div.textContent = '出错了：' + message;
      run.body.appendChild(div);
      if (S.stick) scrollToBottom();
    }
    S.currentRun = null;
    S.running = false;
    if (S.conv && S.cliCompactConvId === S.conv.id) {
      S.cliCompacting = false;
      S.cliCompactConvId = null;
    }
    updateContextBadge();
    if (S.conv) {
      S.runningIds.delete(S.conv.id);
      S.askIds.delete(S.conv.id);
    }
    notifyDesktopBusy();
    hidePermission();
    hideAsk();
    updateComposerState();
    updateChrome();
  }

  function endRun(ev) {
    S.running = false;
    const run = S.currentRun;

    if (run) {
      clearRunProgress(run);
      for (const [key, b] of run.blocks) {
        if (b.type === 'text') {
          if (b.raf) cancelAnimationFrame(b.raf);
          b.raf = 0;
          if (!b.text.trim()) { b.el.remove(); run.blocks.delete(key); continue; }
          paintText(b, false);
        } else if (b.type === 'thinking') {
          if (b.raf) cancelAnimationFrame(b.raf);
          b.raf = 0;
          if (!b.text.trim()) { b.el.remove(); run.blocks.delete(key); continue; }
          paintThinking(b, false);
          if (!b.userToggled) b.el.open = false;
        } else if (b.type === 'tool_use') {
          if (b.statusEl.querySelector('.spin')) {
            b.statusEl.className = 'tool-status';
            b.statusEl.textContent = '';
          }
        }
      }

      refreshActivitySummary(run);
      finalizeActivity(run, !ev.error && !ev.stopped);

      // 任务正常完成后，侧栏预览换成最终结论，而不是停留在用户那句提问
      if (!ev.error && !ev.stopped) {
        const preview = finalRunText(run);
        if (preview) setConvPreview(ev.convId || (S.conv && S.conv.id), preview);
      }

      if (ev.error && !ev.stopped) {
        const div = document.createElement('div');
        div.className = 'block err-block';
        div.textContent = ev.error;
        run.body.appendChild(div);
      }

      refreshArtifactCard(run);
      refreshEditCard(run);

      const turnMeta = { duration: ev.duration, usage: ev.usage, ts: Date.now() };
      if (run.activity) setActivityMeta(run.activity, turnMeta);

      // 有过程行时统计显示在过程行右侧；纯文字轮次才放在底部
      const bits = [];
      let metaInfo = null;
      if (!run.activity) {
        const info = turnMetaInfo(turnMeta);
        if (info) {
          bits.push(info.text);
          metaInfo = info;
        }
      }
      if (bits.length || ev.stopped) {
        const meta = document.createElement('div');
        meta.className = 'run-meta';
        if (ev.stopped) {
          const tag = document.createElement('span');
          tag.className = 'warn';
          tag.textContent = '■ 已停止';
          meta.appendChild(tag);
          if (bits.length) meta.appendChild(document.createTextNode(' · '));
        }
        meta.appendChild(document.createTextNode(bits.join(' · ')));
        if (metaInfo) bindMetaTip(meta, metaInfo);
        run.body.appendChild(meta);
      }

      if (S.stick) scrollToBottom();

      if (!run.body.querySelector('.thinking, .text-block, .tool, .edit-card, .run-meta, .err-block') && run.row) {
        run.row.remove();
      }
    }

    S.currentRun = null;
    hidePermission();
    hideAsk();
    if (S.conv) S.askIds.delete(S.conv.id);
    setStatus('已连接', 'ok');
    updateComposerState();
    updateChrome();
    renderFolders();

    // 如果是在回复中途切回来的，流式内容可能缺了开头，结束后用落盘的记录重绘一次
    if (S.joinedMidRun && S.conv) {
      S.joinedMidRun = false;
      const id = S.conv.id;
      setTimeout(async () => {
        if (S.running || !S.conv || S.conv.id !== id) return;
        try {
          const c = await api('/conversation?id=' + encodeURIComponent(id));
          if (S.conv && S.conv.id === id && !S.running) {
            const keepStick = S.stick;
            renderHistory(c.messages || []);
            S.stick = keepStick;
            if (S.stick) scrollToBottom(true);
          }
        } catch { /* ignore */ }
      }, 600);
    }
  }

  function fmtTok(n) {
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
    return String(n);
  }

  // ------------------------------------------------------------ 权限询问

  function showPermission(ev) {
    hideAsk();
    S.pendingPerm = ev;
    setRunProgress(S.currentRun, '等待你的确认：' + (ev.toolName || '操作') + '…', 'wait');
    const panel = $('#permPanel');

    if (ev.toolName === 'ExitPlanMode') {
      const plan = ev.input && (ev.input.plan || ev.input.planText || ev.input.planMarkdown) || '';
      const body = typeof plan === 'string' && plan ? plan : (() => {
        try { return JSON.stringify(ev.input, null, 2); } catch { return String(ev.input); }
      })();
      panel.innerHTML = `
        <div class="pp-title">Claude 的计划已就绪，确认开始执行？</div>
        <pre>${escapeHtml(body)}</pre>
        <div class="pp-actions">
          <button class="btn" data-deny>继续修改</button>
          <button class="btn primary" data-allow>开始执行</button>
        </div>`;
      panel.hidden = false;
      panel.querySelector('[data-allow]').onclick = () => respondPermission(true);
      panel.querySelector('[data-deny]').onclick = () => respondPermission(false, '用户希望先继续修改计划，请不要开始执行。');
      return;
    }

    let body = '';
    try { body = JSON.stringify(ev.input, null, 2); } catch { body = String(ev.input); }
    panel.innerHTML = `
      <div class="pp-title">Claude 请求使用 <b>${escapeHtml(ev.toolName)}</b></div>
      <pre>${escapeHtml(body)}</pre>
      <div class="pp-actions">
        <button class="btn" data-deny>拒绝</button>
        <button class="btn primary" data-allow>允许</button>
      </div>`;
    panel.hidden = false;
    panel.querySelector('[data-allow]').onclick = () => respondPermission(true);
    panel.querySelector('[data-deny]').onclick = () => respondPermission(false);
  }

  function hidePermission() {
    S.pendingPerm = null;
    $('#permPanel').hidden = true;
    $('#permPanel').innerHTML = '';
  }

  async function respondPermission(allow, message) {
    const p = S.pendingPerm;
    if (!p || !S.conv) return;
    try {
      await api('/permission', {
        method: 'POST',
        body: JSON.stringify({ id: S.conv.id, requestId: p.requestId, allow, message })
      });
      hidePermission();
    } catch (e) { toast(e.message, 'error'); }
  }

  // ------------------------------------------------------------ Claude 提问

  let askState = null;
  let askTimer = null;

  // 模型有时把 "(Recommended)" 写进选项 label；显示时去掉，另用「推荐」标签，但回传仍用原 label
  function askLabelText(label) {
    const raw = String(label == null ? '' : label);
    return raw.replace(/\s*[（(]\s*(推荐|推荐选项|recommended)\s*[）)]\s*$/i, '').trim() || raw;
  }

  function hideAsk() {
    if (askTimer) { clearInterval(askTimer); askTimer = null; }
    askState = null;
    S.pendingAsk = null;
    const panel = $('#askPanel');
    if (panel) { panel.hidden = true; panel.innerHTML = ''; }
  }

  function showAsk(ev) {
    if (!ev || !Array.isArray(ev.questions) || !ev.questions.length) return;
    if (S.pendingAsk && S.pendingAsk.requestId !== ev.requestId) hideAsk();
    hidePermission();
    S.pendingAsk = ev;
    setRunProgress(S.currentRun, '等待你的回答…', 'wait');
    askState = {
      ev,
      selections: ev.questions.map(() => new Set()),
      others: ev.questions.map(() => '')
    };

    const panel = $('#askPanel');
    panel.innerHTML = '';
    panel.hidden = false;

    const head = document.createElement('div');
    head.className = 'ask-head';
    const title = document.createElement('b');
    title.textContent = ev.major ? 'Claude 需要你做一个决定' : 'Claude 想确认一下';
    const count = document.createElement('span');
    count.className = 'ask-count';
    head.append(title, count);
    panel.appendChild(head);

    const firstLabels = ev.questions.map(q => (q.options && q.options[0] && q.options[0].label) || '');

    ev.questions.forEach((q, qi) => {
      const wrap = document.createElement('div');
      wrap.className = 'ask-q';

      if (q.header) {
        const h = document.createElement('div');
        h.className = 'ask-header';
        h.textContent = q.header;
        wrap.appendChild(h);
      }
      const qt = document.createElement('div');
      qt.className = 'ask-text';
      qt.textContent = q.question || '';
      wrap.appendChild(qt);

      const opts = document.createElement('div');
      opts.className = 'ask-opts';
      const options = Array.isArray(q.options) ? q.options : [];
      for (let oi = 0; oi < options.length; oi++) {
        const opt = options[oi] || {};
        const label = typeof opt.label === 'string' ? opt.label : String(opt.label || '');
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'ask-opt' + (q.multiSelect ? ' multi' : '');
        b.dataset.label = label;
        const radio = document.createElement('span');
        radio.className = 'ask-radio';
        const body = document.createElement('span');
        body.className = 'ask-opt-body';
        const lab = document.createElement('span');
        lab.className = 'ask-opt-label';
        lab.textContent = askLabelText(label);
        body.appendChild(lab);
        if (opt.description) {
          const d = document.createElement('span');
          d.className = 'ask-opt-desc';
          d.textContent = opt.description;
          body.appendChild(d);
        }
        b.append(radio, body);
        if (oi === 0) {
          const reco = document.createElement('span');
          reco.className = 'ask-reco';
          reco.textContent = '推荐';
          b.appendChild(reco);
        }
        b.addEventListener('click', () => {
          if (!askState) return;
          const sel = askState.selections[qi];
          if (q.multiSelect) {
            if (sel.has(label)) sel.delete(label); else sel.add(label);
          } else {
            sel.clear();
            sel.add(label);
          }
          for (const el of opts.querySelectorAll('.ask-opt')) {
            el.classList.toggle('sel', sel.has(el.dataset.label));
          }
        });
        opts.appendChild(b);
      }
      wrap.appendChild(opts);

      const other = document.createElement('input');
      other.type = 'text';
      other.className = 'ask-other';
      other.placeholder = q.multiSelect ? '其他选项（可选，多个用逗号分隔）' : '其他答案（也可以自己输入）';
      other.addEventListener('input', () => {
        if (askState) askState.others[qi] = other.value;
      });
      other.addEventListener('keydown', e => {
        if (e.isComposing || e.keyCode === 229) return;
        if (e.key === 'Enter') { e.preventDefault(); submitAsk(false); }
      });
      wrap.appendChild(other);
      panel.appendChild(wrap);
    });

    const foot = document.createElement('div');
    foot.className = 'ask-foot';
    const hint = document.createElement('div');
    hint.className = 'ask-hint';
    const skip = document.createElement('button');
    skip.type = 'button';
    skip.className = 'btn';
    skip.textContent = '跳过';
    skip.addEventListener('click', () => submitAsk(true));
    const ok = document.createElement('button');
    ok.type = 'button';
    ok.className = 'btn primary';
    ok.textContent = '提交';
    ok.addEventListener('click', () => submitAsk(false));
    foot.append(hint, skip, ok);
    panel.appendChild(foot);

    const setHint = () => {
      if (!askState || askState.ev.requestId !== ev.requestId) return;
      if (ev.major) {
        const mins = ev.cancelAt ? Math.max(1, Math.round((ev.cancelAt - Date.now()) / 60000)) : 30;
        hint.innerHTML = `方向性决定，会等你回答；约 ${mins} 分钟无人应答会自动暂停这一轮，不会自行决定。`;
        count.textContent = '等待你的选择';
        return;
      }
      const rem = Math.max(0, Math.ceil((Number(ev.autoAt || 0) - Date.now()) / 1000));
      const firstLabel = askLabelText(firstLabels[0]);
      const first = firstLabel ? `推荐：<b>${escapeHtml(firstLabel)}</b> · ` : '';
      hint.innerHTML = `${first}${rem > 0 ? `${rem} 秒后按推荐项自动继续` : '正在按推荐项继续…'}`;
      count.textContent = rem > 0 ? `${rem}s` : '自动继续';
    };
    setHint();
    if (askTimer) { clearInterval(askTimer); askTimer = null; }
    if (!ev.major) askTimer = setInterval(setHint, 1000);
  }

  function buildAskAnswers() {
    if (!askState) return null;
    const answers = {};
    askState.ev.questions.forEach((q, i) => {
      const sel = [...askState.selections[i]];
      const other = (askState.others[i] || '').trim();
      let value = sel.join(', ');
      if (other) value = value ? `${value}, ${other}` : other;
      if (!value) return;
      answers[q.question] = value;
    });
    return Object.keys(answers).length === askState.ev.questions.length ? answers : null;
  }

  async function submitAsk(cancel) {
    const st = askState;
    if (!st || !S.conv) return;
    const requestId = st.ev.requestId;
    const answers = cancel ? null : buildAskAnswers();
    if (!cancel && !answers) {
      toast('每个问题都选一个选项，或直接输入答案；也可以点「跳过」', 'error');
      return;
    }
    try {
      await api('/ask', {
        method: 'POST',
        body: JSON.stringify({ id: S.conv.id, requestId, answers, cancel })
      });
      hideAsk();
    } catch (e) {
      toast(e.message, 'error');
      if (String(e.message).includes('已经结束')) hideAsk();
    }
  }

  // ------------------------------------------------------------ 文件夹选择器

  let picker = null;

  function pickFolder(startPath) {
    if (picker) return Promise.resolve(null);
    return new Promise(resolve => {
      picker = { resolve, current: '', selected: null };
      $('#modal').hidden = false;
      loadPicker(startPath || S.currentFolder || S.app.home || '');
    });
  }

  function closePicker(result) {
    $('#modal').hidden = true;
    if (picker) {
      const r = picker.resolve;
      picker = null;
      r(result);
    }
  }

  async function loadPicker(p) {
    try {
      const data = await api('/fs?path=' + encodeURIComponent(p || ''));
      if (!picker) return;
      picker.current = data.path;
      renderPicker(data);
    } catch (e) {
      toast(e.message, 'error');
    }
  }

  function renderPicker(data) {
    $('#pickerPath').textContent = data.path || '此电脑';
    $('#pickerInput').value = data.path || '';
    $('#pickerUp').disabled = !data.parent;

    const side = $('#pickerSide');
    side.innerHTML = '';
    const addSide = (label, path, icon) => {
      const b = document.createElement('button');
      b.className = 'side-item' + (data.path === path ? ' active' : '');
      b.innerHTML = `${icon}<span>${escapeHtml(label)}</span>`;
      b.title = path;
      b.addEventListener('click', () => loadPicker(path));
      side.appendChild(b);
    };

    if (data.quick && data.quick.length) {
      const lbl = document.createElement('div');
      lbl.className = 'side-label';
      lbl.textContent = '快捷访问';
      side.appendChild(lbl);
      for (const q of data.quick) addSide(q.name, q.path, ICON.folder);
    }

    if (data.drives && data.drives.length) {
      const lbl = document.createElement('div');
      lbl.className = 'side-label';
      lbl.textContent = '驱动器';
      side.appendChild(lbl);
      for (const d of data.drives) addSide(d, d, ICON.folder);
    }

    const list = $('#pickerList');
    list.innerHTML = '';
    if (!data.entries.length) {
      list.innerHTML = '<div class="picker-empty">这里没有子文件夹</div>';
      return;
    }
    for (const e of data.entries) {
      const b = document.createElement('button');
      b.className = 'dir-item' + (e.hidden ? ' hidden-dir' : '');
      b.innerHTML = `${ICON.folder}<span>${escapeHtml(e.name)}</span>`;
      b.title = e.path;
      b.addEventListener('click', () => loadPicker(e.path));
      list.appendChild(b);
    }
  }

  // ------------------------------------------------------------ 启动

  async function refreshBoot() {
    try {
      const boot = await api('/bootstrap');
      S.folders = boot.folders;
      S.settings = { ...S.settings, ...boot.settings };
      S.app = { ...S.app, ...boot.app };
      if (!S.currentFolder) {
        const first = S.folders.find(f => f.exists);
        if (first) S.currentFolder = first.path;
      }
      primeAttentionFromFolders();
      const allConvs = S.folders.flatMap(f => f.conversations || []);
      if (S.conv) {
        const found = allConvs.find(c => c.id === S.conv.id);
        if (found && found.title) S.conv.title = found.title;
      }
      // 用界面服务的权威状态补上侧栏运行/提问标记（页面刷新、重连后也能显示）
      // 只增不删：删除交给 SSE 的 run_end / ask_resolved，避免和刚到达的事件抢状态
      for (const c of allConvs) {
        if (c.running) S.runningIds.add(c.id);
        if (c.asking) S.askIds.add(c.id);
      }
      renderFolders();
      updateChrome();
    } catch { /* ignore */ }
  }

  let bootTimer = null;
  function refreshBootSoon() {
    clearTimeout(bootTimer);
    bootTimer = setTimeout(refreshBoot, 500);
  }

  const EFFORT_LABELS = { low: '低', medium: '中', high: '高', xhigh: '极高', max: '最高' };
  const TIER_NAMES = { opus: 'Opus', sonnet: 'Sonnet', haiku: 'Haiku' };

  function effortText(level) {
    return level ? (EFFORT_LABELS[level] || level) : '';
  }

  /** 窄窗口时把「默认（deepseek-flash[1m]）」「低（low）」里的括号说明去掉，
     只保留主要文字；上下文徽标本身始终完整显示。 */
  function refreshSelectDisplay() {
    const short = window.innerWidth <= 1150;
    for (const sel of [$('#modelSelect'), $('#effortSelect')]) {
      if (!sel) continue;
      for (const opt of sel.options) {
        if (opt.dataset.fullLabel == null) opt.dataset.fullLabel = opt.textContent;
        const full = opt.dataset.fullLabel;
        const brief = full.replace(/（[^）]*）/g, '').replace(/\([^)]*\)/g, '').trim();
        const want = short ? (brief || full) : full;
        if (opt.textContent !== want) opt.textContent = want;
      }
    }
  }

  function buildSelects() {
    const perm = $('#permSelect');
    const modes = [
      ['bypassPermissions', '全部放行'],
      ['auto', '自动判断'],
      ['acceptEdits', '自动接受编辑'],
      ['plan', '只读规划']
    ];
    perm.innerHTML = modes.map(([v, l]) => `<option value="${v}">${l}</option>`).join('');

    const model = $('#modelSelect');
    const dm = S.settings.defaultModel || '';
    const models = Array.isArray(S.settings.availableModels) ? S.settings.availableModels : [];
    const modelLabel = m => {
      const id = typeof m === 'string' ? m : (m && m.id);
      const roles = m && Array.isArray(m.roles) ? m.roles : [];
      const tiers = roles.filter(r => TIER_NAMES[r]).map(r => TIER_NAMES[r]);
      return tiers.length ? `${id}（${tiers.join(' / ')} 档）` : id;
    };
    const opts = [['', dm ? `默认（${dm}）` : '默认']];
    for (const m of models) {
      const id = typeof m === 'string' ? m : (m && m.id);
      if (!id) continue;
      opts.push([id, modelLabel(m)]);
    }
    if (dm && !opts.some(([v]) => v === dm)) opts.push([dm, dm]);
    model.innerHTML = opts.map(([v, l]) => `<option value="${escapeHtml(v)}">${escapeHtml(l)}</option>`).join('');
    const wrap = $('#modelWrap');
    if (wrap) {
      const hit = models.find(m => (typeof m === 'string' ? m : m && m.id) === dm);
      const roles = hit && Array.isArray(hit.roles) ? hit.roles.filter(r => r !== '默认') : [];
      wrap.title = '模型档位' + (dm ? ` · 默认 ${dm}` : '') + (roles.length ? `（也用于 ${roles.join(' / ')}）` : '');
    }

    // 推理档位：low / medium / high / xhigh / max，空值表示跟随 settings.json
    const effort = $('#effortSelect');
    const envEffort = S.settings.envEffort || '';
    const levels = Array.isArray(S.settings.effortLevels) && S.settings.effortLevels.length
      ? S.settings.effortLevels
      : ['low', 'medium', 'high', 'xhigh', 'max'];
    const effortOpts = [['', envEffort ? `默认（${effortText(envEffort)}）` : '默认']];
    for (const lv of levels) effortOpts.push([lv, `${effortText(lv)}（${lv}）`]);
    effort.innerHTML = effortOpts.map(([v, l]) => `<option value="${escapeHtml(v)}">${escapeHtml(l)}</option>`).join('');
    const effortWrap = $('#effortWrap');
    if (effortWrap) {
      effortWrap.title = '推理档位：越高思考越深，速度越慢、消耗越多' +
        (envEffort ? `。默认跟随 settings.json（${effortText(envEffort)}）` : '');
    }
    refreshSelectDisplay();
    enhanceTopbarSelects();
  }

  // ------------------------------------------------------------ 自定义顶栏下拉
  // 原生 <select> 的弹层由系统绘制，样式无法统一；这里保留原生 select 的值和 change 逻辑，
  // 只把交互层换成自绘菜单。
  const TB_SELECT_CONFIG = [
    { id: 'modelSelect', wrap: 'modelWrap', kind: 'model', title: '模型', hint: '选择对话使用的模型' },
    { id: 'effortSelect', wrap: 'effortWrap', kind: 'effort', title: '推理档位', hint: '档位越高，思考越深、速度越慢' },
    { id: 'permSelect', wrap: 'permWrap', kind: 'perm', title: '权限模式', hint: '控制工具执行前的确认方式' }
  ];
  const TB_EFFORT_DESC = {
    '': '跟随 settings.json 的默认档位',
    low: '更快，思考更少',
    medium: '速度和思考深度均衡',
    high: '更深入的思考',
    xhigh: '很深的推理，速度更慢',
    max: '最深推理，最慢、消耗更多'
  };
  const TB_PERM_DESC = {
    bypassPermissions: '不询问、不拦截，仅在信任的文件夹使用',
    auto: '按风险自动判断是否询问',
    acceptEdits: '文件编辑自动接受，其他操作仍询问',
    plan: '只读规划，不会修改文件'
  };
  const TB_PERM_DOT = {
    bypassPermissions: 'var(--red)',
    auto: 'var(--green)',
    acceptEdits: 'var(--accent)',
    plan: 'var(--blue)'
  };

  let tbSelectMenu = null;
  let tbSelectCurrent = null;

  function closeTopbarSelect() {
    if (!tbSelectMenu || tbSelectMenu.hidden) return;
    tbSelectMenu.hidden = true;
    if (tbSelectCurrent && tbSelectCurrent.wrap) {
      tbSelectCurrent.wrap.dataset.tbOpen = '';
      tbSelectCurrent.wrap.setAttribute('aria-expanded', 'false');
    }
    tbSelectCurrent = null;
  }

  function openTopbarSelect(cfg, sel, wrap) {
    if (sel.disabled) return;
    if (tbSelectCurrent && tbSelectCurrent.sel !== sel) closeTopbarSelect();
    tbSelectCurrent = { cfg, sel, wrap };
    wrap.dataset.tbOpen = '1';
    wrap.setAttribute('aria-expanded', 'true');

    const items = [];
    for (const opt of sel.options) {
      const value = opt.value;
      const full = String(opt.dataset.fullLabel || opt.textContent || '').trim();
      let label = full;
      let desc = '';
      let dot = '';
      if (cfg.kind === 'model') {
        if (value === '') {
          label = '默认';
          const inner = full.replace(/^默认[（(]/, '').replace(/[）)]$/, '').trim();
          desc = inner ? `跟随设置：${inner}` : '跟随设置中的默认模型';
        } else {
          const m = full.match(/^([^（(]+?)[（(](.+?)[）)]$/);
          label = (m ? m[1] : full).trim();
          desc = m ? m[2].trim() : '';
        }
      } else if (cfg.kind === 'effort') {
        const m = full.match(/^([^（(]+?)[（(](.+?)[）)]$/);
        label = (m ? m[1] : full).trim();
        desc = [TB_EFFORT_DESC[value] || '', m ? m[2].trim() : ''].filter(Boolean).join(' · ');
      } else if (cfg.kind === 'perm') {
        desc = TB_PERM_DESC[value] || '';
        dot = TB_PERM_DOT[value] || '';
      }

      const item = document.createElement('button');
      item.type = 'button';
      item.className = 'tb-opt';
      item.dataset.value = value;
      item.setAttribute('role', 'option');
      item.setAttribute('aria-selected', value === sel.value ? 'true' : 'false');
      if (opt.disabled) item.disabled = true;

      if (dot) {
        const d = document.createElement('span');
        d.className = 'tb-opt-dot';
        d.style.background = dot;
        item.appendChild(d);
      }

      const main = document.createElement('span');
      main.className = 'tb-opt-main';
      const labelEl = document.createElement('span');
      labelEl.className = 'tb-opt-label' + (cfg.kind === 'model' && value ? ' mono' : '');
      labelEl.textContent = label;
      main.appendChild(labelEl);
      if (desc) {
        const descEl = document.createElement('span');
        descEl.className = 'tb-opt-desc';
        descEl.textContent = desc;
        main.appendChild(descEl);
      }
      item.appendChild(main);

      const check = document.createElement('span');
      check.className = 'tb-opt-check';
      check.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>';
      item.appendChild(check);

      item.addEventListener('click', () => {
        const next = value;
        closeTopbarSelect();
        if (sel.value !== next) {
          sel.value = next;
          sel.dispatchEvent(new Event('change', { bubbles: true }));
        }
        wrap.focus({ preventScroll: true });
      });
      items.push(item);
    }

    tbSelectMenu.innerHTML = '';
    const head = document.createElement('div');
    head.className = 'tb-menu-head';
    const title = document.createElement('div');
    title.className = 'tb-menu-title';
    title.textContent = cfg.title;
    const hint = document.createElement('div');
    hint.className = 'tb-menu-hint';
    hint.textContent = cfg.hint;
    head.append(title, hint);
    const list = document.createElement('div');
    list.className = 'tb-menu-list';
    for (const item of items) list.appendChild(item);
    tbSelectMenu.append(head, list);

    tbSelectMenu.hidden = false;
    tbSelectMenu.style.minWidth = (cfg.kind === 'perm' ? 300 : 280) + 'px';
    tbSelectMenu.style.left = '0px';
    tbSelectMenu.style.top = '0px';
    const r = wrap.getBoundingClientRect();
    const mw = tbSelectMenu.offsetWidth;
    const mh = tbSelectMenu.offsetHeight;
    let left = Math.min(r.left, window.innerWidth - mw - 12);
    left = Math.max(12, left);
    let top = r.bottom + 8;
    if (top + mh > window.innerHeight - 12) top = Math.max(12, r.top - mh - 8);
    tbSelectMenu.style.left = Math.round(left) + 'px';
    tbSelectMenu.style.top = Math.round(top) + 'px';

    const active = tbSelectMenu.querySelector('.tb-opt[aria-selected="true"]');
    if (active) {
      active.focus({ preventScroll: true });
      active.scrollIntoView({ block: 'nearest' });
    }
  }

  function enhanceTopbarSelects() {
    if (!tbSelectMenu) {
      const style = document.createElement('style');
      style.id = 'topbarSelectStyle';
      style.textContent = `
        .select-wrap[data-tb-select] { cursor: pointer; user-select: none; }
        .select-wrap[data-tb-select] > select { display: none !important; }
        .select-wrap[data-tb-select] .tb-select-value {
          max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
          font-size: 12px; color: var(--fg-2);
        }
        #modelWrap .tb-select-value { max-width: 210px; }
        .select-wrap[data-tb-select] .tb-select-chevron {
          display: flex; width: 12px; height: 12px; flex: 0 0 auto;
          color: var(--fg-4); transition: transform .15s;
        }
        .select-wrap[data-tb-select] .tb-select-chevron svg { width: 12px; height: 12px; }
        .select-wrap[data-tb-open="1"] { border-color: var(--accent-line); background: var(--panel-2); }
        .select-wrap[data-tb-open="1"] .tb-select-chevron { transform: rotate(180deg); }
        .tb-select-menu {
          position: fixed; z-index: 120; min-width: 240px;
          max-width: min(360px, calc(100vw - 24px)); padding: 6px;
          border: 1px solid var(--line-2); border-radius: 12px;
          background: var(--panel);
          box-shadow: 0 18px 50px rgba(0,0,0,.55), 0 2px 8px rgba(0,0,0,.3);
          animation: tbSelectIn .13s ease-out;
        }
        .tb-select-menu[hidden] { display: none !important; }
        @keyframes tbSelectIn {
          from { opacity: 0; transform: translateY(-4px) scale(.99); }
          to { opacity: 1; transform: none; }
        }
        .tb-menu-head { padding: 6px 9px 8px; border-bottom: 1px solid var(--line); margin-bottom: 4px; }
        .tb-menu-title { font-size: 12px; font-weight: 600; color: var(--fg); }
        .tb-menu-hint { margin-top: 2px; font-size: 10.5px; color: var(--fg-4); line-height: 1.4; }
        .tb-menu-list { max-height: min(360px, 60vh); overflow-y: auto; }
        .tb-opt {
          display: flex; align-items: center; gap: 9px; width: 100%;
          padding: 8px 9px; border-radius: 8px; border: 0;
          text-align: left; color: var(--fg-2); background: transparent;
        }
        .tb-opt:hover { background: var(--panel-2); color: var(--fg); }
        .tb-opt[aria-selected="true"] { background: var(--accent-soft); color: var(--fg); }
        .tb-opt:disabled { opacity: .45; cursor: default; }
        .tb-opt-main { display: flex; flex-direction: column; gap: 1px; min-width: 0; flex: 1; }
        .tb-opt-label {
          font-size: 12.5px; line-height: 1.4; white-space: nowrap;
          overflow: hidden; text-overflow: ellipsis;
        }
        .tb-opt-label.mono { font-family: var(--mono); font-size: 11.8px; }
        .tb-opt-desc { font-size: 10.5px; color: var(--fg-4); line-height: 1.4; }
        .tb-opt-check {
          width: 16px; height: 16px; flex: 0 0 auto;
          color: var(--accent); opacity: 0;
        }
        .tb-opt[aria-selected="true"] .tb-opt-check { opacity: 1; }
        .tb-opt-check svg { width: 16px; height: 16px; }
        .tb-opt-dot {
          width: 7px; height: 7px; border-radius: 50%; flex: 0 0 auto;
          box-shadow: 0 0 0 3px rgba(255,255,255,.04);
        }
        @media (max-width: 1100px) {
          .select-wrap[data-tb-select] .tb-select-value { max-width: 96px !important; }
        }
      `;
      document.head.appendChild(style);

      tbSelectMenu = document.createElement('div');
      tbSelectMenu.className = 'tb-select-menu';
      tbSelectMenu.hidden = true;
      tbSelectMenu.setAttribute('role', 'listbox');
      document.body.appendChild(tbSelectMenu);

      document.addEventListener('mousedown', e => {
        if (!tbSelectMenu.hidden && tbSelectCurrent &&
            !tbSelectCurrent.wrap.contains(e.target) && !tbSelectMenu.contains(e.target)) {
          closeTopbarSelect();
        }
      }, true);
      document.addEventListener('keydown', e => {
        if (e.key === 'Escape') closeTopbarSelect();
      });
      window.addEventListener('resize', closeTopbarSelect);
      tbSelectMenu.addEventListener('keydown', e => {
        if (e.key === 'Escape') {
          e.preventDefault();
          closeTopbarSelect();
          if (tbSelectCurrent) tbSelectCurrent.wrap.focus({ preventScroll: true });
          return;
        }
        if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
        const all = [...tbSelectMenu.querySelectorAll('.tb-opt:not(:disabled)')];
        if (!all.length) return;
        const idx = all.indexOf(document.activeElement);
        e.preventDefault();
        const next = e.key === 'ArrowDown'
          ? (idx + 1) % all.length
          : (idx - 1 + all.length) % all.length;
        all[next].focus();
      });
    }

    for (const cfg of TB_SELECT_CONFIG) {
      const sel = document.getElementById(cfg.id);
      const wrap = document.getElementById(cfg.wrap);
      if (!sel || !wrap || wrap.dataset.tbSelect === '1') continue;
      wrap.dataset.tbSelect = '1';
      wrap.tabIndex = 0;
      wrap.setAttribute('role', 'button');
      wrap.setAttribute('aria-haspopup', 'listbox');
      wrap.setAttribute('aria-expanded', 'false');

      const valueEl = document.createElement('span');
      valueEl.className = 'tb-select-value';
      const chev = document.createElement('span');
      chev.className = 'tb-select-chevron';
      chev.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 9l6 6 6-6"/></svg>';
      wrap.insertBefore(valueEl, sel);
      wrap.insertBefore(chev, sel);
      sel.style.display = 'none';

      const sync = () => {
        const opt = sel.options[sel.selectedIndex];
        const text = opt ? String(opt.textContent || '') : '';
        const full = opt ? String(opt.dataset.fullLabel || opt.textContent || '') : '';
        valueEl.textContent = text;
        valueEl.title = full || text;
        wrap.setAttribute('aria-label', cfg.title + '：' + (full || text));
        wrap.setAttribute('aria-disabled', sel.disabled ? 'true' : 'false');
      };

      const valueDesc = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value');
      Object.defineProperty(sel, 'value', {
        configurable: true,
        get() { return valueDesc.get.call(this); },
        set(v) { valueDesc.set.call(this, v); sync(); }
      });
      new MutationObserver(sync).observe(sel, { childList: true, subtree: true, characterData: true });
      sel.addEventListener('change', sync);

      wrap.addEventListener('click', e => {
        e.preventDefault();
        if (tbSelectCurrent && tbSelectCurrent.sel === sel) closeTopbarSelect();
        else openTopbarSelect(cfg, sel, wrap);
      });
      wrap.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') {
          e.preventDefault();
          openTopbarSelect(cfg, sel, wrap);
        } else if (e.key === 'Escape') {
          closeTopbarSelect();
        }
      });

      sync();
    }
  }

  // ------------------------------------------------------------ 桌宠
  // 桌宠 sidecar（E:\AI_Claude\dsh-pet\bridge\sidecar.js）独立运行在 4780-4789。
  // 这里只做按钮和状态同步；桌宠进程的启动/停止由 sidecar 负责。
  const PET_PORTS = Array.from({ length: 10 }, (_, i) => 4780 + i);
  const pet = { base: '', online: false, running: false, visible: false, busy: false, balanceBusy: false };

  async function fetchWithTimeout(url, opts = {}, ms = 1200) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), ms);
    try {
      return await fetch(url, { ...opts, signal: ctrl.signal });
    } finally {
      clearTimeout(timer);
    }
  }

  async function findPetSidecar() {
    for (const port of PET_PORTS) {
      try {
        const res = await fetchWithTimeout(`http://127.0.0.1:${port}/api/health`, { cache: 'no-store' }, 400);
        if (!res.ok) continue;
        const data = await res.json();
        if (data && data.app === 'dsh-pet-bridge') {
          pet.base = `http://127.0.0.1:${port}`;
          return true;
        }
      } catch { /* 试下一个端口 */ }
    }
    pet.base = '';
    return false;
  }

  function setPetButton(visible, online) {
    const btn = $('#petBtn');
    if (!btn) return;
    btn.classList.toggle('pet-on', !!visible);
    btn.classList.toggle('pet-offline', !online);
    btn.title = !online
      ? '桌宠服务未启动（重启客户端试试，或双击 dsh-pet\\bridge\\启动桌宠服务.cmd）'
      : visible ? '收起桌宠' : '打开桌宠';
  }

  let petStatusBusy = false;
  async function refreshPetStatus() {
    if (petStatusBusy) return;
    petStatusBusy = true;
    try {
      if (!pet.base && !(await findPetSidecar())) {
        pet.online = false;
        setPetButton(false, false);
        return;
      }
      const res = await fetchWithTimeout(pet.base + '/api/pet/status', {}, 1500);
      if (!res.ok) throw new Error('status');
      const data = await res.json();
      pet.online = true;
      const visible = data.visible !== undefined ? !!data.visible : !!data.running;
      pet.visible = visible;
      pet.running = visible;
      setPetButton(visible, true);
    } catch {
      pet.base = '';
      pet.online = false;
      pet.visible = false;
      setPetButton(false, false);
    } finally {
      petStatusBusy = false;
    }
  }

  async function togglePet() {
    if (pet.busy) return;
    if (!pet.base && !(await findPetSidecar())) {
      toast('桌宠服务未启动，请先双击 dsh-pet\\bridge\\启动桌宠服务.cmd', 'error');
      return;
    }
    pet.busy = true;
    try {
      const res = await fetchWithTimeout(pet.base + '/api/pet/toggle', { method: 'POST' }, 30000);
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.ok === false) throw new Error(data.error || '桌宠操作失败');
      pet.online = true;
      const visible = data.visible !== undefined ? !!data.visible : !!data.running;
      pet.visible = visible;
      pet.running = visible;
      setPetButton(visible, true);
      toast(visible ? '桌宠已打开' : '桌宠已收起');
    } catch (e) {
      toast(e.message || '桌宠操作失败', 'error');
      await refreshPetStatus();
    } finally {
      pet.busy = false;
    }
  }

  function formatBalanceText(data) {
    const list = Array.isArray(data && data.balances) ? data.balances : [];
    if (!list.length) return data && data.isAvailable === false ? 'DeepSeek 余额不可用' : 'DeepSeek 余额：暂无数据';
    return 'DeepSeek 余额：' + list.map(info => {
      const symbol = info.currency === 'CNY' ? '¥' : info.currency === 'USD' ? '$' : '';
      return symbol ? `${symbol}${info.total_balance ?? '-'}` : `${info.total_balance ?? '-'} ${info.currency || ''}`.trim();
    }).join(' / ');
  }

  async function checkBalance() {
    if (pet.balanceBusy) return;
    if (!pet.base && !(await findPetSidecar())) {
      toast('桌宠服务未启动，请先双击 dsh-pet\\bridge\\启动桌宠服务.cmd', 'error');
      return;
    }
    pet.balanceBusy = true;
    try {
      const res = await fetchWithTimeout(pet.base + '/api/balance?refresh=1', {}, 12000);
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.ok === false) throw new Error(data.error || '查询余额失败');
      toast(formatBalanceText(data), data.isAvailable === false ? 'error' : undefined);
    } catch (e) {
      toast(e.message || '查询余额失败', 'error');
    } finally {
      pet.balanceBusy = false;
    }
  }

  function initBalanceButton() {
    const btn = $('#balanceBtn');
    if (!btn) return;
    btn.addEventListener('click', checkBalance);
  }

  function initPetButton() {
    const btn = $('#petBtn');
    if (!btn) return;
    btn.addEventListener('click', togglePet);
    refreshPetStatus();
    // 客户端启动时会自动拉起 sidecar / 恢复桌宠，多探几次让按钮状态尽快跟上
    setTimeout(refreshPetStatus, 2000);
    setTimeout(refreshPetStatus, 5000);
    setInterval(refreshPetStatus, 12000);
    window.addEventListener('focus', () => {
      refreshPetStatus();
      setTimeout(refreshPetStatus, 2500);
    });
  }

  // ------------------------------------------------------------ 客户端内更新

  let updateCheckPromise = null;

  async function checkForUpdate(force = false) {
    // 浏览器版没有桌面主进程，不能一键关闭/替换，不显示更新按钮
    if (!(window.guiDesktop && typeof window.guiDesktop.startUpdate === 'function')) {
      S.updateInfo = null;
      renderUpdateButton();
      return false;
    }
    // 启动检查、定时检查和点开更新框可能撞在一起，复用同一次请求。
    if (updateCheckPromise) return updateCheckPromise;
    updateCheckPromise = (async () => {
      try {
        const data = await api('/update/check' + (force ? '?refresh=1' : ''));
        S.updateInfo = data && data.available ? data : null;
        renderUpdateButton();
        return true;
      } catch {
        // 网络失败时保留已有更新信息，避免把旧版本误清成“已是最新”。
        renderUpdateButton();
        return false;
      }
    })();
    try {
      return await updateCheckPromise;
    } finally {
      updateCheckPromise = null;
    }
  }

  function ensureUpdateModalStyle() {
    if (document.getElementById('updateModalStyle')) return;
    const style = document.createElement('style');
    style.id = 'updateModalStyle';
    style.textContent = `
.update-modal-backdrop { position: fixed; inset: 0; z-index: 70; display: flex; align-items: center; justify-content: center; padding: 24px; background: rgba(0,0,0,.55); backdrop-filter: blur(2px); }
.update-modal-backdrop[hidden] { display: none; }
.update-modal { width: min(480px, calc(100vw - 32px)); max-height: min(78vh, 620px); display: flex; flex-direction: column; overflow: hidden; color: var(--fg); background: var(--panel); border: 1px solid var(--line-2); border-radius: 14px; box-shadow: 0 20px 60px rgba(0,0,0,.55); }
.update-modal-head { flex: 0 0 auto; padding: 18px 20px 10px; }
.update-modal-title { font-size: 16px; line-height: 1.35; font-weight: 600; }
.update-modal-sub { margin-top: 5px; color: var(--fg-4); font-size: 11.5px; line-height: 1.5; }
.update-modal-body { flex: 1 1 auto; min-height: 0; padding: 2px 20px 6px; overflow: auto; overscroll-behavior: contain; }
.update-version { padding: 12px 0; border-top: 1px solid var(--line); }
.update-version:first-child { padding-top: 6px; border-top: 0; }
.update-version-head { display: flex; align-items: center; gap: 8px; min-height: 20px; }
.update-version-tag { font-size: 12.5px; font-weight: 600; color: var(--fg); }
.update-version-latest { padding: 0 5px; border: 1px solid var(--accent-line); border-radius: 99px; background: var(--accent-soft); color: var(--accent); font-size: 9.5px; line-height: 1.5; }
.update-version-date { margin-left: auto; color: var(--fg-4); font-size: 10.5px; font-variant-numeric: tabular-nums; }
.update-version-notes { margin-top: 5px; color: var(--fg-3); font-size: 12px; line-height: 1.65; white-space: pre-wrap; word-break: break-word; }
.update-modal-warn { margin: 4px 20px 0; padding: 7px 9px; border: 1px solid rgba(220,160,80,.35); border-radius: 8px; background: rgba(220,160,80,.08); color: var(--yellow); font-size: 11.5px; line-height: 1.5; }
.update-modal-warn[hidden], .update-modal-msg[hidden] { display: none; }
.update-modal-hint { margin: 8px 20px 0; color: var(--fg-4); font-size: 10.5px; line-height: 1.5; }
.update-modal-msg { margin: 8px 20px 0; color: var(--red); font-size: 11.5px; line-height: 1.5; word-break: break-word; }
.update-modal-msg.ok { color: var(--fg-3); }
.update-modal-foot { flex: 0 0 auto; display: flex; justify-content: flex-end; gap: 8px; padding: 14px 20px 17px; }
.update-modal-foot .btn { min-width: 78px; }
@media (max-width: 520px) {
  .update-modal-backdrop { padding: 12px; }
  .update-modal { width: calc(100vw - 24px); max-height: calc(100vh - 24px); }
  .update-modal-head { padding: 15px 16px 8px; }
  .update-modal-body { padding-left: 16px; padding-right: 16px; }
  .update-modal-warn, .update-modal-hint, .update-modal-msg { margin-left: 16px; margin-right: 16px; }
  .update-modal-foot { padding: 12px 16px 15px; }
}
`;
    document.head.appendChild(style);
  }

  function ensureUpdateModal() {
    ensureUpdateModalStyle();
    let root = document.getElementById('updateModal');
    if (root) return root;
    root = document.createElement('div');
    root.id = 'updateModal';
    root.className = 'update-modal-backdrop';
    root.hidden = true;
    root.innerHTML = `
      <div class="update-modal" role="dialog" aria-modal="true" aria-labelledby="updateModalTitle">
        <div class="update-modal-head">
          <div class="update-modal-title" id="updateModalTitle">发现新版本</div>
          <div class="update-modal-sub" id="updateModalSub"></div>
        </div>
        <div class="update-modal-body" id="updateModalBody"></div>
        <div class="update-modal-warn" id="updateModalWarn" hidden></div>
        <div class="update-modal-hint">更新期间会打开一个更新窗口，请不要关闭它；完成后客户端会自动重新打开。</div>
        <div class="update-modal-msg" id="updateModalMsg" hidden></div>
        <div class="update-modal-foot">
          <button type="button" class="btn" id="updateLater">稍后</button>
          <button type="button" class="btn primary" id="updateStart">开始更新</button>
        </div>
      </div>`;
    document.body.appendChild(root);
    root.addEventListener('mousedown', e => {
      if (e.target === root && !S.updateBusy) closeUpdateModal();
    });
    root.querySelector('#updateLater').addEventListener('click', () => { if (!S.updateBusy) closeUpdateModal(); });
    root.querySelector('#updateStart').addEventListener('click', confirmUpdateFromUI);
    return root;
  }

  function updateSizeLabel(n) {
    const bytes = Number(n) || 0;
    if (!bytes) return '';
    if (bytes >= 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + ' MB';
    return Math.max(1, Math.round(bytes / 1024)) + ' KB';
  }

  function updateDateLabel(value) {
    const m = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
    return m ? Number(m[2]) + '月' + Number(m[3]) + '日' : '';
  }

  function renderUpdateModal(info) {
    const root = ensureUpdateModal();
    const changes = Array.isArray(info.changes) && info.changes.length
      ? info.changes
      : [{ version: info.version, date: '', notes: info.notes || '' }];
    const versions = [];
    const seen = new Set();
    for (const c of changes) {
      if (!c || !c.version || seen.has(String(c.version))) continue;
      seen.add(String(c.version));
      versions.push(c);
    }

    root.querySelector('#updateModalTitle').textContent = '发现新版本 v' + info.version;
    const sub = [];
    if (info.current) sub.push('当前 v' + info.current);
    if (versions.length > 1) sub.push('跨越 ' + versions.length + ' 个版本');
    const size = updateSizeLabel(info.size);
    if (size) sub.push('更新包 ' + size);
    root.querySelector('#updateModalSub').textContent = sub.join(' · ');

    const body = root.querySelector('#updateModalBody');
    body.innerHTML = '';
    for (const c of versions) {
      const block = document.createElement('div');
      block.className = 'update-version';
      const head = document.createElement('div');
      head.className = 'update-version-head';
      const tag = document.createElement('span');
      tag.className = 'update-version-tag';
      tag.textContent = 'v' + c.version;
      head.appendChild(tag);
      if (String(c.version) === String(info.version)) {
        const latest = document.createElement('span');
        latest.className = 'update-version-latest';
        latest.textContent = '最新';
        head.appendChild(latest);
      }
      const date = updateDateLabel(c.date);
      if (date) {
        const dateEl = document.createElement('span');
        dateEl.className = 'update-version-date';
        dateEl.textContent = date;
        head.appendChild(dateEl);
      }
      block.appendChild(head);
      const notes = document.createElement('div');
      notes.className = 'update-version-notes';
      notes.textContent = String(c.notes || '').trim() || '包含稳定性改进和细节优化。';
      block.appendChild(notes);
      body.appendChild(block);
    }
    body.scrollTop = 0;

    const running = S.runningIds.size > 0 || S.running;
    const warn = root.querySelector('#updateModalWarn');
    warn.hidden = !running;
    warn.textContent = running ? '当前有任务正在运行，开始更新会中断该任务。' : '';

    const msg = root.querySelector('#updateModalMsg');
    msg.hidden = true;
    msg.textContent = '';
    msg.className = 'update-modal-msg';
    const start = root.querySelector('#updateStart');
    start.disabled = false;
    start.textContent = '开始更新';
    root.querySelector('#updateLater').disabled = false;
  }

  async function openUpdateModal() {
    if (S.updateBusy) return;
    // 点开更新框时再强制查一次；否则页面里缓存的 1.2.19 会一直显示下去。
    const ok = await checkForUpdate(true);
    const info = S.updateInfo;
    if (!info) {
      toast(ok ? '已是最新版本' : '检查更新失败，请稍后再试', ok ? '' : 'error');
      return;
    }
    renderUpdateModal(info);
    const root = ensureUpdateModal();
    root.hidden = false;
  }

  function closeUpdateModal() {
    if (S.updateBusy) return;
    const root = document.getElementById('updateModal');
    if (root) root.hidden = true;
  }

  async function confirmUpdateFromUI() {
    const info = S.updateInfo;
    if (!info || S.updateBusy) return;
    if (!window.guiDesktop || typeof window.guiDesktop.startUpdate !== 'function') {
      toast('请在桌面客户端里更新', 'warn');
      return;
    }
    S.updateBusy = true;
    const root = ensureUpdateModal();
    const start = root.querySelector('#updateStart');
    const later = root.querySelector('#updateLater');
    const msg = root.querySelector('#updateModalMsg');
    start.disabled = true;
    later.disabled = true;
    start.textContent = '正在准备更新…';
    msg.hidden = true;
    msg.className = 'update-modal-msg';
    try {
      const r = await window.guiDesktop.startUpdate({
        manifestUrl: info.manifestUrl,
        version: info.version,
        notes: info.notes || '',
        confirmed: true
      });
      if (r && r.ok) {
        start.textContent = '正在更新，客户端即将重启…';
        msg.hidden = false;
        msg.className = 'update-modal-msg ok';
        msg.textContent = '更新程序已经启动。';
        return;
      }
      if (r && r.cancelled) {
        S.updateBusy = false;
        start.disabled = false;
        later.disabled = false;
        start.textContent = '开始更新';
        return;
      }
      throw new Error((r && r.error) || '无法开始更新');
    } catch (e) {
      S.updateBusy = false;
      start.disabled = false;
      later.disabled = false;
      start.textContent = '开始更新';
      msg.hidden = false;
      msg.className = 'update-modal-msg';
      msg.textContent = e.message;
    }
  }

  function renderUpdateButton() {
    const host = document.getElementById('statusLine') || document.querySelector('.sb-foot');
    let btn = document.getElementById('updateBtn');
    if (!S.updateInfo || !host) {
      if (btn) btn.remove();
      const modal = document.getElementById('updateModal');
      if (modal && !modal.hidden && !S.updateBusy) modal.hidden = true;
      return;
    }
    if (!btn) {
      btn = document.createElement('button');
      btn.id = 'updateBtn';
      btn.type = 'button';
      btn.className = 'update-btn';
      btn.addEventListener('click', openUpdateModal);
      host.appendChild(btn);
    } else if (btn.parentElement !== host) {
      host.appendChild(btn);
    }
    const info = S.updateInfo;
    btn.disabled = false;
    btn.textContent = '更新 v' + info.version;
    btn.title = '查看 v' + info.version + ' 的更新内容';
  }

  // ------------------------------------------------------------ 浏览器按钮

  async function openChromeFromWorkbench() {
    let data = await api('/browser/open', { method: 'POST' });
    if (data && data.needChrome) {
      if (!window.guiDesktop || typeof window.guiDesktop.pickChrome !== 'function') {
        throw new Error('没有找到 Chrome。请先安装 Chrome，或在桌面客户端里选择 Chrome 安装目录');
      }
      const picked = await window.guiDesktop.pickChrome();
      if (!picked || picked.canceled) throw new Error('已取消选择 Chrome');
      if (!picked.path) throw new Error(picked.error || '所选目录里没有 chrome.exe');
      await api('/browser/chrome-path', {
        method: 'POST',
        body: JSON.stringify({ path: picked.path })
      });
      data = await api('/browser/open', { method: 'POST' });
    }
    if (data && data.ok === false) throw new Error(data.error || '打开 Chrome 失败');
    return data || { ok: true };
  }

  function injectBrowserLaunchButton() {
    const topActions = $('.top-actions');
    if (!topActions || $('#browserBtn')) return;

    const btn = document.createElement('button');
    btn.className = 'icon-btn';
    btn.id = 'browserBtn';
    btn.type = 'button';
    btn.title = '打开 Chrome';
    btn.setAttribute('aria-label', '打开 Chrome');
    btn.innerHTML = '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18"/><circle cx="6.5" cy="6.5" r=".6"/></svg>';
    btn.addEventListener('click', async () => {
      if (btn.disabled) return;
      btn.disabled = true;
      btn.style.opacity = '.55';
      try {
        await openChromeFromWorkbench();
        toast('Chrome 已打开');
      } catch (e) {
        toast('打开 Chrome 失败：' + e.message, 'error');
      } finally {
        setTimeout(() => {
          btn.disabled = false;
          btn.style.opacity = '';
        }, 500);
      }
    });

    const before = $('#balanceBtn');
    if (before && before.parentElement === topActions) topActions.insertBefore(btn, before);
    else topActions.appendChild(btn);
  }

  // ------------------------------------------------------------ 手机连接
  // 侧栏「工作台」旁的小手机按钮：打开后可以取 APK、开手机访问、复制连接地址。
  // DOM 和样式都由脚本注入，兼容 index.html 被只读 ACL 锁住的安装。
  function phoneFormatSize(bytes) {
    const n = Number(bytes) || 0;
    if (n >= 1024 * 1024 * 1024) return (n / 1024 / 1024 / 1024).toFixed(1) + ' GB';
    if (n >= 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' MB';
    if (n >= 1024) return Math.round(n / 1024) + ' KB';
    return n + ' B';
  }

  function injectPhoneEntry() {
    if ($('#phoneEntryBtn')) return;
    const head = document.querySelector('.sb-head');
    if (!head) return;

    const style = document.createElement('style');
    style.id = 'phone-style';
    style.textContent = `
      .sb-head .phone-entry{margin-left:auto;color:var(--fg-3)}
      .sb-head .phone-entry:hover{color:var(--accent)}
      .sb-head .phone-entry.on{color:var(--accent)}
      .sb-head .phone-entry ~ .icon-btn{margin-left:0}
      .phone-modal{width:min(560px,calc(100vw - 36px));height:auto;max-height:calc(100vh - 48px)}
      .phone-body{padding:16px 18px 18px;overflow:auto;min-height:0;display:flex;flex-direction:column;gap:12px}
      .phone-hero{display:flex;gap:12px;align-items:flex-start;padding:2px 2px 4px}
      .phone-hero-ic{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;flex:0 0 auto;color:var(--accent);background:linear-gradient(160deg,rgba(224,138,95,.2),rgba(224,138,95,.05));border:1px solid rgba(224,138,95,.25)}
      .phone-hero-ic svg{width:22px;height:22px}
      .phone-hero-title{font-size:14px;font-weight:600;color:var(--fg)}
      .phone-hero-sub{margin-top:4px;font-size:11.5px;line-height:1.6;color:var(--fg-4)}
      .phone-card{border:1px solid var(--line);border-radius:11px;background:var(--panel);padding:12px 13px;display:flex;flex-direction:column;gap:9px}
      .phone-card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}
      .phone-card-title{font-size:12.5px;font-weight:600;color:var(--fg)}
      .phone-card-desc{margin-top:3px;font-size:11px;line-height:1.6;color:var(--fg-4)}
      .phone-apk-list{display:flex;flex-direction:column;gap:5px}
      .phone-apk{display:flex;align-items:center;gap:7px;min-width:0;padding:6px 8px;border:1px solid var(--line);border-radius:7px;background:var(--bg-soft)}
      .phone-apk-ic{color:var(--accent);display:flex;flex:0 0 auto}
      .phone-apk-ic svg{width:14px;height:14px}
      .phone-apk-main{display:flex;flex-direction:column;min-width:0;line-height:1.35}
      .phone-apk-name{font-family:var(--mono);font-size:10.5px;color:var(--fg-2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .phone-apk-meta{font-size:9.5px;color:var(--fg-4)}
      .phone-empty{padding:8px;border:1px dashed var(--line-2);border-radius:7px;text-align:center;font-size:11px;line-height:1.6;color:var(--fg-4)}
      .phone-actions{display:flex;gap:7px;flex-wrap:wrap}
      .phone-actions .btn{height:29px;padding:0 10px;font-size:11.5px}
      .phone-actions a.btn{display:inline-flex;align-items:center;text-decoration:none;box-sizing:border-box}
      .phone-status{display:flex;align-items:center;gap:5px;flex:0 0 auto;font-size:10.5px;color:var(--fg-4);white-space:nowrap;margin-top:2px}
      .phone-dot{width:6px;height:6px;border-radius:50%;background:var(--fg-4)}
      .phone-dot.on{background:#6cc98a;box-shadow:0 0 0 3px rgba(108,201,138,.12)}
      .phone-urls{display:flex;flex-direction:column;gap:5px}
      .phone-url-row{display:flex;align-items:center;gap:6px;min-width:0;padding:5px 7px;border:1px solid var(--line);border-radius:7px;background:var(--bg-soft)}
      .phone-url-tag{flex:0 0 auto;font-size:9px;padding:1px 5px;border-radius:99px;border:1px solid var(--line-2);color:var(--fg-4)}
      .phone-url-tag.ts{color:var(--accent);border-color:var(--accent-line)}
      .phone-url-text{flex:1;min-width:0;font-family:var(--mono);font-size:10px;color:var(--fg-3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .phone-url-row .btn{height:24px;padding:0 7px;font-size:10.5px;flex:0 0 auto}
      .phone-tabs{display:flex;gap:4px;padding:2px;border:1px solid var(--line);border-radius:9px;background:var(--bg-soft)}
      .phone-tab{flex:1;padding:6px 8px;border-radius:7px;font-size:11.5px;color:var(--fg-3);text-align:center;cursor:pointer;border:0;background:none}
      .phone-tab:hover{color:var(--fg-2);background:var(--panel-2)}
      .phone-tab.active{background:var(--panel-2);color:var(--fg);box-shadow:inset 0 0 0 1px var(--line-2)}
      .phone-panel{display:flex;flex-direction:column;gap:8px}
      .phone-panel[hidden]{display:none}
      .phone-mode-note{font-size:11px;line-height:1.65;color:var(--fg-3);padding:7px 9px;border-radius:8px;background:var(--bg-soft);border:1px solid var(--line)}
      .phone-mode-note b{color:var(--fg-2);font-weight:600}
      .phone-ts-status{font-size:11px;line-height:1.65;color:var(--fg-3);padding:7px 9px;border-radius:8px;background:var(--bg-soft);border:1px solid var(--line)}
      .phone-ts-status .ok{color:#6cc98a}
      .phone-ts-status .bad{color:var(--red)}
      .phone-head-right{display:flex;align-items:center;gap:6px;flex:0 0 auto;flex-wrap:wrap;justify-content:flex-end}
      .phone-toggle{height:26px;padding:0 8px;font-size:10.5px}
      .phone-small{font-size:10px;color:var(--fg-4);line-height:1.55}
      .phone-steps{margin:0;padding-left:17px;display:flex;flex-direction:column;gap:3px;font-size:11px;line-height:1.6;color:var(--fg-3)}
      .phone-steps b{color:var(--fg-2);font-weight:500}
      .phone-note{font-size:10.5px;line-height:1.6;color:var(--fg-4);text-align:center;padding:0 6px}
      .phone-download-note{font-size:10.5px;line-height:1.55;color:var(--fg-3);padding:1px 2px}
      .phone-download-note.bad{color:var(--red)}
      .phone-link{font-size:10.5px;color:var(--fg-4);text-decoration:underline;text-underline-offset:2px}
      .phone-link:hover{color:var(--fg-2)}
      @media (max-width:520px){
        .phone-modal{width:calc(100vw - 20px);max-height:calc(100vh - 24px)}
        .phone-body{padding:13px 13px 15px}
        .phone-actions .btn{flex:1;min-width:120px}
      }
    `;
    document.head.appendChild(style);

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.id = 'phoneEntryBtn';
    btn.className = 'icon-btn phone-entry';
    btn.title = '手机连接 / 下载安卓 App';
    btn.setAttribute('aria-label', '手机连接');
    btn.innerHTML = '<svg viewBox="0 0 24 24"><rect x="6.5" y="2.5" width="11" height="19" rx="2.5"/><path d="M10.5 18.5h3"/></svg>';
    const brand = head.querySelector('.brand');
    if (brand) brand.insertAdjacentElement('afterend', btn);
    else head.appendChild(btn);

    const modal = document.createElement('div');
    modal.className = 'modal-backdrop';
    modal.id = 'phoneModal';
    modal.hidden = true;
    modal.innerHTML = `
      <div class="modal phone-modal" role="dialog" aria-modal="true" aria-labelledby="phoneTitle">
        <div class="modal-head">
          <b id="phoneTitle">手机连接</b>
          <button class="icon-btn" id="phoneClose" title="关闭（Esc）">
            <svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>
          </button>
        </div>
        <div class="phone-body">
          <div class="phone-hero">
            <div class="phone-hero-ic">
              <svg viewBox="0 0 24 24"><rect x="6.5" y="2.5" width="11" height="19" rx="2.5"/><path d="M10.5 18.5h3"/><path d="M9.5 7h5M9.5 10h5"/></svg>
            </div>
            <div>
              <div class="phone-hero-title">把手机接到工作台</div>
              <div class="phone-hero-sub">在家用同一 Wi-Fi 最简单，不需要 Tailscale 账号；出门在外再按里面的步骤配置。不感兴趣可以直接关闭。</div>
            </div>
          </div>

          <div class="phone-card">
            <div class="phone-card-head">
              <div>
                <div class="phone-card-title">1. 安装安卓 App</div>
                <div class="phone-card-desc">安装包放在电脑的 apk 文件夹里。传到手机安装即可，安卓 8.0 以上、arm64。</div>
              </div>
            </div>
            <div class="phone-apk-list" id="phoneApkList"></div>
            <div class="phone-actions">
              <button class="btn primary" id="phoneOpenFolder" type="button">打开 APK 文件夹</button>
              <button class="btn" id="phoneDownloadFull" type="button">下载完整包</button>
              <button class="btn" id="phoneDownloadSlim" type="button">下载精简包</button>
            </div>
            <div class="phone-download-note" id="phoneDownloadNote" hidden></div>
            <a class="phone-link" href="https://github.com/enneliang-stack/claude-workbench-remote/releases/latest" target="_blank" rel="noreferrer">下载失败？打开 GitHub Release 页面</a>
          </div>

          <div class="phone-card">
            <div class="phone-card-head">
              <div>
                <div class="phone-card-title">2. 连接电脑端</div>
                <div class="phone-card-desc">先选手机现在和电脑是不是同一个 Wi-Fi；不确定就选第一个。</div>
              </div>
              <div class="phone-head-right">
                <span class="phone-status"><span class="phone-dot" id="phoneRemoteDot"></span><span id="phoneRemoteState">检查中…</span></span>
                <button class="btn phone-toggle" id="phoneRemoteToggle" type="button">开启</button>
              </div>
            </div>

            <div class="phone-tabs" role="tablist">
              <button class="phone-tab active" type="button" data-phone-mode="lan">同一 Wi-Fi（推荐）</button>
              <button class="phone-tab" type="button" data-phone-mode="ts">出门在外</button>
            </div>

            <div class="phone-panel" id="phoneLanPanel">
              <div class="phone-mode-note"><b>不用 Tailscale，也不用注册账号。</b>手机和电脑连同一个路由器即可；在家、办公室都适用。</div>
              <div class="phone-urls" id="phoneLanUrls"></div>
              <div class="phone-actions">
                <button class="btn primary" id="phoneCopyLan" type="button" hidden>复制连接地址</button>
              </div>
              <ol class="phone-steps">
                <li>手机安装上面的 APK。</li>
                <li>手机和电脑连同一个 Wi-Fi。</li>
                <li>点右上角「开启」，再点「复制连接地址」，发到手机（微信/QQ/文件传输助手）。</li>
                <li>手机打开 App → 电脑端 → 粘贴地址 → 连接。</li>
              </ol>
              <div class="phone-small">App 里如果还写着「远程访问.cmd」，不用管，直接把复制的地址粘贴进去即可。地址里的 token 相当于钥匙，不要把地址发给别人。</div>
            </div>

            <div class="phone-panel" id="phoneTsPanel" hidden>
              <div class="phone-mode-note">
                <b>只有不在家/不在同一 Wi-Fi 时才需要。</b>电脑登录 Tailscale；手机不用登录账号，也不用装 Tailscale App，
                用电脑账号生成一个 <b>reusable key</b> 填到手机里即可。
              </div>
              <div class="phone-ts-status" id="phoneTsStatus">正在检查电脑上的 Tailscale…</div>
              <div class="phone-urls" id="phoneTsUrls"></div>
              <div class="phone-actions">
                <button class="btn" id="phoneCopyTs" type="button" hidden>复制电脑 Tailscale 地址</button>
                <button class="btn primary" id="phoneInstallTs" type="button" hidden>安装 Tailscale</button>
                <button class="btn" id="phoneOpenTs" type="button" hidden>打开 Tailscale 登录</button>
                <a class="btn" id="phoneTsKeys" href="https://login.tailscale.com/admin/settings/keys" target="_blank" rel="noreferrer">打开后台生成 key</a>
              </div>
              <ol class="phone-steps">
                <li>电脑点「安装 Tailscale」安装并登录（只需一次，安装包随客户端提供）。</li>
                <li>点「打开后台生成 key」→ <b>Generate auth key</b> → 勾选 <b>Reusable</b> → 复制 <code>tskey-auth-…</code>。</li>
                <li>手机 App → 设置 →「内置 Tailscale」→ 粘贴 key 和上面的电脑 Tailscale 地址。</li>
                <li>以后出门打开 App，会自动走内置 Tailscale。</li>
              </ol>
              <div class="phone-small">安装会弹一次管理员确认；登录需要你自己的 Tailscale 账号。电脑端只需要登录 Tailscale；手机用的是从电脑账号生成的 key，不需要在手机上再登录一次。key 只保存在手机本地。</div>
            </div>
          </div>

          <div class="phone-card">
            <div class="phone-card-title" style="margin-bottom:2px">说明</div>
            <div class="phone-card-desc">同一 Wi-Fi 是最简单的用法，完全不碰 Tailscale；出门在外再按「出门在外」里的步骤配置。iPhone 不能装这个安卓包，可以在 Safari 打开手机页后「添加到主屏幕」。</div>
          </div>

          <div class="phone-note">这个入口只是可选功能，不用的话放着不管即可。</div>
        </div>
      </div>`;
    document.body.appendChild(modal);

    let pollTimer = 0;
    let lastInfo = null;
    let lastDownload = null;

    function closePhoneModal() {
      modal.hidden = true;
      if (pollTimer) { clearInterval(pollTimer); pollTimer = 0; }
    }

    function renderPhoneInfo(info) {
      lastInfo = info || {};
      const apkList = $('#phoneApkList');
      const apks = Array.isArray(info && info.apks) ? info.apks : [];
      if (apkList) {
        if (!apks.length) {
          apkList.innerHTML = '<div class="phone-empty">apk 文件夹里还没有安装包。可以点「下载完整包」，或把 APK 手动放进去。</div>';
        } else {
          apkList.innerHTML = apks.slice(0, 6).map(a => `
            <div class="phone-apk">
              <span class="phone-apk-ic"><svg viewBox="0 0 24 24"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg></span>
              <span class="phone-apk-main">
                <span class="phone-apk-name" title="${escapeHtml(a.name)}">${escapeHtml(a.name)}</span>
                <span class="phone-apk-meta">${phoneFormatSize(a.size)}</span>
              </span>
            </div>`).join('');
        }
      }

      const remote = (info && info.remote) || {};
      const on = !!remote.enabled;
      const dot = $('#phoneRemoteDot');
      const state = $('#phoneRemoteState');
      if (dot) dot.classList.toggle('on', on);
      if (state) state.textContent = on ? '已开启' : '未开启';
      const toggle = $('#phoneRemoteToggle');
      if (toggle) toggle.textContent = on ? '关闭' : '开启';
      btn.classList.toggle('on', on);

      const urls = Array.isArray(remote.urls) ? remote.urls : [];
      const lanUrls = urls.filter(u => !u.tailscale);
      const tsUrls = urls.filter(u => u.tailscale);
      const rows = list => list.map(u => `
        <div class="phone-url-row">
          <span class="phone-url-tag${u.tailscale ? ' ts' : ''}">${u.tailscale ? 'Tailscale' : '局域网'}</span>
          <span class="phone-url-text" title="${escapeHtml(u.url)}">${escapeHtml(u.url)}</span>
          <button class="btn phone-copy" type="button" data-url="${escapeHtml(u.url)}">复制</button>
        </div>`).join('');
      const lanWrap = $('#phoneLanUrls');
      if (lanWrap) {
        lanWrap.hidden = !on || !lanUrls.length;
        lanWrap.innerHTML = lanUrls.length ? rows(lanUrls)
          : (on ? '<div class="phone-empty">没有检测到局域网地址。电脑可能没连 Wi-Fi；可以让电脑连手机热点，或改用「出门在外」。</div>' : '');
      }
      const tsWrap = $('#phoneTsUrls');
      if (tsWrap) {
        tsWrap.hidden = !on || !tsUrls.length;
        tsWrap.innerHTML = tsUrls.length ? rows(tsUrls) : '';
      }
      const copyLan = $('#phoneCopyLan');
      if (copyLan) copyLan.hidden = !on || !lanUrls.length;
      const copyTs = $('#phoneCopyTs');
      if (copyTs) copyTs.hidden = !on || !tsUrls.length;

      const ts = (info && info.tailscale) || {};
      const tsBox = $('#phoneTsStatus');
      if (tsBox) {
        if (!ts.installed) {
          tsBox.innerHTML = '电脑还没装 Tailscale。<span class="bad">在家用同一 Wi-Fi 不需要它</span>；要出门再点下面的「安装 Tailscale」。安装包已经随客户端带了，会弹一次管理员确认。';
        } else if (!ts.running) {
          tsBox.innerHTML = '电脑装了 Tailscale，但<span class="bad">没有登录或没有运行</span>。点下面的「打开 Tailscale 登录」，登录后这里会自动变成已登录。';
        } else {
          const name = ts.dnsName || ts.ip || '已登录';
          tsBox.innerHTML = `电脑 Tailscale <span class="ok">已登录</span>：<b>${escapeHtml(name)}</b>${ts.ip ? ' · ' + escapeHtml(ts.ip) : ''}`;
        }
        if (on && tsUrls.length) {
          tsBox.innerHTML += '<br><span style="color:var(--fg-4)">手机里填上面这条带 token 的地址。</span>';
        } else if (!on) {
          tsBox.innerHTML += '<br><span style="color:var(--fg-4)">先点右上角「开启」，才会出现电脑地址。</span>';
        }
      }
      const installTs = $('#phoneInstallTs');
      if (installTs) installTs.hidden = !!ts.installed;
      const openTs = $('#phoneOpenTs');
      if (openTs) openTs.hidden = !ts.installed;

      const dl = (info && info.download) || {};
      const note = $('#phoneDownloadNote');
      if (note) {
        note.hidden = !(dl.active || dl.error || dl.done);
        note.classList.toggle('bad', !!dl.error);
        if (dl.active) {
          const pct = dl.total ? Math.min(100, Math.round(dl.received / dl.total * 100)) : 0;
          note.textContent = `正在下载${dl.kind === 'slim' ? '精简包' : '完整包'}… ${pct}% (${phoneFormatSize(dl.received)}${dl.total ? ' / ' + phoneFormatSize(dl.total) : ''})`;
        } else if (dl.error) {
          note.textContent = '下载失败：' + dl.error;
        } else if (dl.done) {
          note.textContent = '已下载：' + (dl.name || '安装包');
        }
      }
      const fullBtn = $('#phoneDownloadFull');
      const slimBtn = $('#phoneDownloadSlim');
      if (fullBtn) fullBtn.disabled = !!dl.active;
      if (slimBtn) slimBtn.disabled = !!dl.active;
      if (lastDownload && lastDownload.active && !dl.active && dl.done) toast('安装包下载完成');
      lastDownload = dl;
    }

    async function refreshPhoneInfo() {
      try {
        renderPhoneInfo(await api('/phone-app/info'));
      } catch (e) {
        const state = $('#phoneRemoteState');
        if (state) state.textContent = '读取失败';
        const note = $('#phoneDownloadNote');
        if (note && !note.textContent) {
          note.hidden = false;
          note.classList.add('bad');
          note.textContent = '需要重启客户端后生效：' + e.message;
        }
      }
    }

    function openPhoneModal() {
      modal.hidden = false;
      refreshPhoneInfo();
      if (pollTimer) clearInterval(pollTimer);
      pollTimer = setInterval(refreshPhoneInfo, 1200);
    }

    async function copyText(text) {
      if (!text) return;
      try {
        await navigator.clipboard.writeText(text);
        toast('地址已复制');
      } catch {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); toast('地址已复制'); }
        catch { toast('复制失败，请手动选择地址', 'error'); }
        ta.remove();
      }
    }

    async function startDownload(kind) {
      try {
        const r = await api('/phone-app/download', { method: 'POST', body: JSON.stringify({ kind }) });
        if (r && r.download) renderPhoneInfo({ ...(lastInfo || {}), download: r.download });
        toast(kind === 'slim' ? '开始下载精简包' : '开始下载完整包');
      } catch (e) { toast(e.message, 'error'); }
    }

    btn.addEventListener('click', openPhoneModal);
    $('#phoneClose').addEventListener('click', closePhoneModal);
    $('#phoneOpenFolder').addEventListener('click', async () => {
      try {
        await api('/phone-app/open-folder', { method: 'POST', body: '{}' });
        toast('已打开 apk 文件夹');
      } catch (e) { toast(e.message, 'error'); }
    });
    $('#phoneDownloadFull').addEventListener('click', () => startDownload('full'));
    $('#phoneDownloadSlim').addEventListener('click', () => startDownload('slim'));
    $('#phoneRemoteToggle').addEventListener('click', async () => {
      const on = !!(lastInfo && lastInfo.remote && lastInfo.remote.enabled);
      const toggle = $('#phoneRemoteToggle');
      if (toggle) toggle.disabled = true;
      try {
        await api('/remote', { method: 'POST', body: JSON.stringify({ enabled: !on }) });
        toast(!on ? '手机访问已开启' : '手机访问已关闭');
        setTimeout(refreshPhoneInfo, 700);
      } catch (e) { toast(e.message, 'error'); }
      finally { if (toggle) toggle.disabled = false; }
    });
    modal.querySelectorAll('[data-phone-mode]').forEach(tab => {
      tab.addEventListener('click', () => {
        const mode = tab.dataset.phoneMode === 'ts' ? 'ts' : 'lan';
        modal.querySelectorAll('[data-phone-mode]').forEach(t => {
          t.classList.toggle('active', t.dataset.phoneMode === mode);
        });
        const lan = $('#phoneLanPanel');
        const tsPanel = $('#phoneTsPanel');
        if (lan) lan.hidden = mode !== 'lan';
        if (tsPanel) tsPanel.hidden = mode !== 'ts';
      });
    });
    $('#phoneCopyLan').addEventListener('click', () => {
      const urls = (lastInfo && lastInfo.remote && lastInfo.remote.urls) || [];
      const first = urls.find(u => !u.tailscale);
      if (first) copyText(first.url);
    });
    $('#phoneCopyTs').addEventListener('click', () => {
      const urls = (lastInfo && lastInfo.remote && lastInfo.remote.urls) || [];
      const first = urls.find(u => u.tailscale);
      if (first) copyText(first.url);
    });
    $('#phoneInstallTs').addEventListener('click', async () => {
      try {
        const r = await api('/phone-app/install-tailscale', { method: 'POST', body: '{}' });
        toast(r && r.installed ? 'Tailscale 已安装，正在打开登录界面' : '已打开 Tailscale 安装程序，请完成安装');
        setTimeout(refreshPhoneInfo, 1500);
      } catch (e) { toast(e.message, 'error'); }
    });
    $('#phoneOpenTs').addEventListener('click', async () => {
      try {
        await api('/phone-app/open-tailscale', { method: 'POST', body: '{}' });
        toast('已打开 Tailscale，请登录');
      } catch (e) { toast(e.message, 'error'); }
    });
    modal.addEventListener('click', e => {
      const copy = e.target.closest && e.target.closest('.phone-copy');
      if (copy) { copyText(copy.dataset.url || ''); return; }
      if (e.target === modal) closePhoneModal();
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && !modal.hidden) closePhoneModal();
    });
  }

  async function init() {
    injectFeatures();
    injectPhoneEntry();
    injectBrowserLaunchButton();
    bindEvents();
    initQuoteSelection();
    await digestReady;
    const boot = await api('/bootstrap');
    S.folders = boot.folders;
    S.settings = { ...S.settings, ...boot.settings };
    S.app = { ...S.app, ...boot.app };
    S.currentFolder = (S.folders.find(f => f.exists) || {}).path || null;
    primeAttentionFromFolders();

    buildSelects();
    renderFolders();
    updateChrome();
    updateComposerState();

    const m = location.hash.match(/^#\/c\/([0-9a-fA-F-]+)/);
    const last = m ? m[1] : localStorage.getItem('lastConversation');
    if (last) {
      await openConversation(last);
      if (!S.conv) renderEmpty();
    } else {
      renderEmpty();
    }

    connectSSE();
    checkForUpdate();
    setInterval(() => checkForUpdate(false), 30 * 60 * 1000);
    autoGrow();
    setTimeout(() => inputEl.focus(), 50);

    // 通知点击 → 打开对应对话
    window.guiDesktop?.onOpenConversation?.((id) => {
      if (id) openConversation(id);
    });
    window.addEventListener('focus', clearCurrentAttention);
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && document.hasFocus()) clearCurrentAttention();
    });
    refreshAttention();
  }

  function autoGrow() {
    inputEl.style.height = 'auto';
    inputEl.style.height = Math.min(inputEl.scrollHeight, 260) + 'px';
  }

  function closeSidebarMobile() {
    $('#sidebar').classList.remove('open');
    $('#sidebarScrim').classList.remove('show');
  }

  function bindEvents() {
    injectComposerAttach();
    // 输入
    inputEl.addEventListener('input', () => {
      autoGrow();
      updateComposerState();
    });
    inputEl.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
        e.preventDefault();
        send();
      }
    });
    inputEl.addEventListener('contextmenu', e => {
      e.preventDefault();
      showInputMenu(e.clientX, e.clientY);
    });
    sendBtn.addEventListener('click', send);
    $('#composer').addEventListener('paste', handlePaste);

    // 把图片拖进输入框
    const composer = $('#composer');
    const isFileDrag = dt => !!dt && (
      Array.from(dt.types || []).includes('Files') ||
      !!(dt.files && dt.files.length) ||
      Array.from(dt.items || []).some(it => it.kind === 'file')
    );
    composer.addEventListener('dragenter', e => {
      if (!isFileDrag(e.dataTransfer)) return;
      e.preventDefault();
      composer.classList.add('dragover');
    });
    composer.addEventListener('dragover', e => {
      if (!isFileDrag(e.dataTransfer)) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
      composer.classList.add('dragover');
    });
    composer.addEventListener('dragleave', e => {
      if (!composer.contains(e.relatedTarget)) composer.classList.remove('dragover');
    });
    composer.addEventListener('drop', e => {
      const dt = e.dataTransfer;
      composer.classList.remove('dragover');
      if (!isFileDrag(dt)) return;
      e.preventDefault();

      const imageFiles = [];
      const fileRefs = [];
      const seenPaths = new Set();
      let noPath = 0;

      const addDroppedFile = (file, isDir) => {
        if (!file) return;
        if (!isDir && /^image\/(png|jpeg|webp|gif)$/i.test(file.type || '')) {
          imageFiles.push(file);
          return;
        }
        const path = getDroppedPath(file);
        if (!path) { noPath++; return; }
        const key = path.toLowerCase();
        if (seenPaths.has(key)) return;
        seenPaths.add(key);
        fileRefs.push({ path, name: file.name || baseNameOfPath(path), isDir: !!isDir });
      };

      const items = Array.from(dt.items || []);
      if (items.length) {
        for (const item of items) {
          if (item.kind !== 'file') continue;
          const file = item.getAsFile();
          if (!file) continue;
          let entry = null;
          try { entry = item.webkitGetAsEntry && item.webkitGetAsEntry(); } catch { }
          addDroppedFile(file, !!(entry && entry.isDirectory));
        }
      } else {
        for (const file of Array.from(dt.files || [])) addDroppedFile(file, false);
      }

      if (imageFiles.length) stageFiles(imageFiles);
      if (fileRefs.length) stageFileRefs(fileRefs);
      if (!imageFiles.length && !fileRefs.length) {
        toast(noPath ? '无法读取文件路径，请从资源管理器拖入文件或文件夹' : '没有可引用的文件');
      }
      inputEl.focus();
    });
    // 防止图片拖到输入框以外时窗口直接打开文件
    window.addEventListener('dragover', e => {
      if (isFileDrag(e.dataTransfer)) e.preventDefault();
    });
    window.addEventListener('drop', e => {
      if (isFileDrag(e.dataTransfer)) e.preventDefault();
    });

    // 单击图片查看大图（输入框中的待发送图片和已发送图片都支持）
    attachStrip.addEventListener('click', e => {
      if (e.target.closest('.attach-x')) return;
      const img = e.target.closest('.attach-item img');
      if (img) openImageViewer(img.src);
    });
    messagesEl.addEventListener('click', e => {
      const wrap = e.target.closest('.bubble-image');
      const img = wrap && wrap.querySelector('img');
      if (img) openImageViewer(img.src);
    });
    $('#viewerClose').addEventListener('click', closeImageViewer);
    $('#imageViewer').addEventListener('click', e => {
      if (e.target === $('#imageViewer')) closeImageViewer();
    });

    // 右键菜单：复制选中的文字；图片（含大图查看器里的图片）可直接复制到剪贴板
    document.addEventListener('contextmenu', e => {
      if (e.defaultPrevented) return; // 输入框有自己的右键菜单
      hideSelectionToolbar();
      const img = e.target.closest('#messages img, #attachStrip img, #imageViewer img');
      const sel = window.getSelection ? String(window.getSelection()) : '';
      const items = [];
      if (img && img.src) {
        items.push({ label: '复制图片', onClick: () => copyImageToClipboard(img.src) });
      }
      if (sel.trim()) {
        items.push({ label: '复制文字', onClick: () => copyTextToClipboard(sel) });
      }
      if (!items.length) return; // 没选中文字也不在图片上：保留浏览器默认右键
      e.preventDefault();
      showMenu(e.clientX, e.clientY, items);
      // 大图查看器的层级比普通菜单高，菜单要临时提到它上面
      if (S.menuEl && e.target.closest('#imageViewer')) S.menuEl.style.zIndex = '95';
    });
    stopBtn.addEventListener('click', async () => {
      if (!S.conv) return;
      try { await api('/stop', { method: 'POST', body: JSON.stringify({ id: S.conv.id }) }); }
      catch (e) { toast(e.message, 'error'); }
    });

    // 新对话
    $('#newChat').addEventListener('click', () => newChat());
    $('#addFolderBtn').addEventListener('click', () => chooseFolder());

    // 搜索
    $('#searchInput').addEventListener('input', e => {
      S.search = e.target.value;
      renderFolders();
    });

    // 顶栏
    $('#folderPath').addEventListener('click', () => {
      const p = (S.conv && S.conv.cwd) || S.currentFolder;
      revealPath(p);
    });
    $('#revealBtn').addEventListener('click', () => {
      const p = (S.conv && S.conv.cwd) || S.currentFolder;
      revealPath(p);
    });

    // 桌宠按钮（sidecar 独立进程）
    initPetButton();
    initBalanceButton();

    $('#permSelect').addEventListener('change', async e => {
      const mode = e.target.value;
      if (S.conv) {
        S.conv.permissionMode = mode;
        await api('/conversation?id=' + encodeURIComponent(S.conv.id), {
          method: 'PATCH', body: JSON.stringify({ permissionMode: mode })
        }).catch(err => toast(err.message, 'error'));
      } else {
        S.settings.defaultPermissionMode = mode;
        await api('/settings', { method: 'POST', body: JSON.stringify({ defaultPermissionMode: mode }) })
          .catch(err => toast(err.message, 'error'));
      }
      updateChrome();
    });

    $('#modelSelect').addEventListener('change', async e => {
      const model = e.target.value;
      if (S.conv) {
        S.conv.model = model;
        await api('/conversation?id=' + encodeURIComponent(S.conv.id), {
          method: 'PATCH', body: JSON.stringify({ model })
        }).catch(err => toast(err.message, 'error'));
        if (S.running) toast('模型已切换，下一条消息生效');
      } else {
        S.settings.defaultModel = model;
        S.settings.defaultModelChoice = model;
        await api('/settings', { method: 'POST', body: JSON.stringify({ defaultModel: model }) })
          .catch(err => toast(err.message, 'error'));
      }
      updateChrome();
    });

    $('#effortSelect').addEventListener('change', async e => {
      const effort = e.target.value;
      if (S.conv) {
        S.conv.effort = effort;
        await api('/conversation?id=' + encodeURIComponent(S.conv.id), {
          method: 'PATCH', body: JSON.stringify({ effort })
        }).catch(err => toast(err.message, 'error'));
        if (S.running) toast('档位已切换，下一条消息生效');
      } else {
        S.settings.defaultEffort = effort;
        await api('/settings', { method: 'POST', body: JSON.stringify({ defaultEffort: effort }) })
          .catch(err => toast(err.message, 'error'));
      }
      updateChrome();
    });

    // 空状态按钮
    messagesEl.addEventListener('click', async e => {
      const btn = e.target.closest('[data-copy]');
      if (btn) {
        const pre = btn.closest('.code-block').querySelector('pre');
        try {
          await navigator.clipboard.writeText(pre.innerText);
          btn.textContent = '已复制';
          setTimeout(() => { btn.textContent = '复制'; }, 1200);
        } catch { toast('复制失败', 'error'); }
        return;
      }

      const act = e.target.closest('[data-act]');
      if (!act) return;
      if (act.dataset.act === 'pick') {
        const p = await chooseFolder();
        if (p) { renderEmpty(); updateChrome(); }
      } else if (act.dataset.act === 'new') {
        newChat();
      }
    });

    // 选择器
    $('#modalClose').addEventListener('click', () => closePicker(null));
    $('#pickerCancel').addEventListener('click', () => closePicker(null));
    $('#pickerOk').addEventListener('click', () => {
      if (!picker || !picker.current) { toast('请先进入一个文件夹'); return; }
      closePicker(picker.current);
    });
    $('#pickerUp').addEventListener('click', async () => {
      const data = await api('/fs?path=' + encodeURIComponent(picker.current || ''));
      if (data.parent) loadPicker(data.parent);
      else loadPicker('');
    });
    $('#pickerInput').addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        loadPicker(e.target.value.trim());
      }
    });
    $('#pickerMkdir').addEventListener('click', async () => {
      if (!picker || !picker.current) { toast('请先进入一个文件夹'); return; }
      const name = await askText({ title: '新建文件夹', placeholder: '文件夹名称', okText: '创建' });
      if (name === null) return;
      const trimmed = name.trim();
      if (!trimmed) return;
      try {
        const r = await api('/fs/mkdir', {
          method: 'POST', body: JSON.stringify({ path: picker.current, name: trimmed })
        });
        await loadPicker(r.path);
      } catch (e) { toast(e.message, 'error'); }
    });
    $('#modal').addEventListener('mousedown', e => {
      if (e.target === $('#modal')) closePicker(null);
    });

    // 输入弹窗
    $('#promptOk').addEventListener('click', () => closeAskText($('#promptInput').value));
    $('#promptCancel').addEventListener('click', () => closeAskText(null));
    $('#promptClose').addEventListener('click', () => closeAskText(null));
    $('#promptInput').addEventListener('keydown', e => {
      if (e.isComposing || e.keyCode === 229) return;
      if (e.key === 'Enter') {
        e.preventDefault();
        e.stopPropagation();
        closeAskText($('#promptInput').value);
      } else if (e.key === 'Escape') {
        e.stopPropagation();
        closeAskText(null);
      }
    });
    $('#promptModal').addEventListener('mousedown', e => {
      if (e.target === $('#promptModal')) closeAskText(null);
    });

    // 移动端侧栏
    $('#openSidebar').addEventListener('click', () => {
      $('#sidebar').classList.add('open');
      $('#sidebarScrim').classList.add('show');
    });
    $('#closeSidebar').addEventListener('click', closeSidebarMobile);
    $('#sidebarScrim').addEventListener('click', closeSidebarMobile);

    // 快捷键
    document.addEventListener('keydown', e => {
      const updateModal = document.getElementById('updateModal');
      if (updateModal && !updateModal.hidden) {
        if (e.key === 'Escape') { e.preventDefault(); closeUpdateModal(); }
        return;
      }
      if (promptState) {
        if (e.key === 'Escape') { e.preventDefault(); closeAskText(null); }
        return;
      }
      if (e.ctrlKey && !e.shiftKey && e.key.toLowerCase() === 'n') {
        e.preventDefault();
        newChat();
      }
      if (e.key === 'Escape') {
        if (!$('#imageViewer').hidden) { closeImageViewer(); return; }
        if (picker) { closePicker(null); return; }
        closeMenu();
      }
    });

    // 切回窗口时刷新列表
    let lastFocus = 0;
    window.addEventListener('focus', () => {
      if (Date.now() - lastFocus < 4000) return;
      lastFocus = Date.now();
      refreshBoot();
    });

    bindFeatureEvents();
  }

  init().catch(e => {
    console.error(e);
    toast('界面初始化失败：' + e.message, 'error');
  });
})();
