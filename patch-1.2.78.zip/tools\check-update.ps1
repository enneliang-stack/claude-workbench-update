﻿# Claude 工作台 —— 版本检测与一键更新
# 兼容 Windows PowerShell 5.1（系统自带）和 PowerShell 7。
#
# 用法：
#   检查更新.cmd                         双击运行
#   powershell -File check-update.ps1 -InstallDir "D:\AI_Claude" -CheckOnly
#   powershell -File check-update.ps1 -Manifest "https://.../latest.json" -DryRun -NoGui
#
# 安全：只接受 https / file / 本地路径；下载后必须通过清单里的 SHA256 校验；
#       补丁包解压时拒绝跳出安装目录的路径，并保留 claude-gui\data 用户数据。

param(
  [string]$InstallDir = '',
  [string]$Manifest = '',
  [switch]$CheckOnly,
  [switch]$DryRun,
  [switch]$Yes,
  [switch]$NoGui,
  [switch]$NoLaunch,
  [switch]$NoSuccessInfo
)

$ErrorActionPreference = 'Stop'
$script:ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:Gui = $true
if ($NoGui -or $env:CLAUDE_UPDATE_NOGUI -eq '1') { $script:Gui = $false }

function Log([string]$msg) {
  Write-Host ("[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $msg)
}

function Show-Info([string]$msg) {
  Log $msg
  if ($script:Gui) {
    try {
      Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
      [void][System.Windows.Forms.MessageBox]::Show($msg, 'Claude 工作台更新',
        [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
    } catch { }
  }
}

function Show-ErrorAndExit([string]$msg) {
  Log ("错误：" + $msg)
  if ($script:Gui) {
    try {
      Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
      [void][System.Windows.Forms.MessageBox]::Show($msg, 'Claude 工作台更新',
        [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    } catch { }
  }
  exit 1
}

function Ask-YesNo([string]$msg) {
  if ($Yes) { return $true }
  if ($script:Gui) {
    try {
      Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
      $r = [System.Windows.Forms.MessageBox]::Show($msg, 'Claude 工作台更新',
        [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
      return ($r -eq [System.Windows.Forms.DialogResult]::Yes)
    } catch { }
  }
  $a = Read-Host ($msg + ' [y/N]')
  return ($a -match '^(y|yes|是|好)$')
}

function Find-InstallDir([string]$hint) {
  $candidates = New-Object System.Collections.Generic.List[string]
  if ($hint) { $candidates.Add($hint) }
  if ($script:ScriptDir) {
    $candidates.Add((Split-Path -Parent $script:ScriptDir))
  }
  if ($env:LOCALAPPDATA) {
    $candidates.Add((Join-Path $env:LOCALAPPDATA 'Programs\AI_Claude'))
  }
  if ($env:USERPROFILE) {
    $candidates.Add((Join-Path $env:USERPROFILE 'AI_Claude'))
  }
  # 手动解压/绿色版常见放在各盘根目录
  foreach ($drive in @('C', 'D', 'E', 'F')) {
    $candidates.Add(('{0}:\AI_Claude' -f $drive))
  }
  $regKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\{69C6605A-8A3A-4C8D-BDB7-780404135C1E}_is1'
  try {
    $loc = (Get-ItemProperty -Path $regKey -ErrorAction Stop).InstallLocation
    if ($loc) { $candidates.Add([string]$loc) }
  } catch { }
  foreach ($c in $candidates) {
    if (-not $c) { continue }
    try {
      $full = [IO.Path]::GetFullPath($c)
      if ((Test-Path -LiteralPath (Join-Path $full 'claude-gui\server.js')) -or
          (Test-Path -LiteralPath (Join-Path $full 'update-backup\pending.json') -PathType Leaf)) { return $full }
    } catch { }
  }
  return $null
}

function Get-LocalVersion([string]$dir) {
  $f = Join-Path $dir 'claude-gui\version.json'
  if (-not (Test-Path -LiteralPath $f)) { return $null }
  try {
    $j = Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json
    return [string]$j.version
  } catch { return $null }
}

function Get-DshPetVersion([string]$dir) {
  $f = Join-Path $dir 'dsh-pet\node_modules\dsh-pet\package.json'
  if (-not (Test-Path -LiteralPath $f)) { return $null }
  try {
    $j = Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json
    return [string]$j.version
  } catch { return $null }
}

function Compare-Version([string]$a, [string]$b) {
  try {
    $va = [version]$a
    $vb = [version]$b
    return $va.CompareTo($vb)
  } catch {
    if ($a -eq $b) { return 0 }
    if ($a -gt $b) { return 1 }
    return -1
  }
}

function Get-ManifestSource([string]$dir, [string]$override) {
  if ($override) { return $override }

  $cfgPaths = @(
    (Join-Path $dir 'claude-gui\update-config.json'),
    (Join-Path $dir 'tools\update-config.json')
  )
  foreach ($cfgPath in $cfgPaths) {
    if (-not (Test-Path -LiteralPath $cfgPath)) { continue }
    try {
      $cfg = Get-Content -LiteralPath $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
      if ($cfg.manifestUrl) {
        $u = [string]$cfg.manifestUrl
        if ($u -match '^[a-zA-Z][a-zA-Z0-9+.-]*://') { return $u }
        return [IO.Path]::GetFullPath((Join-Path (Split-Path -Parent $cfgPath) $u))
      }
    } catch { }
  }

  $locals = @(
    (Join-Path $dir 'latest.json'),
    (Join-Path $dir 'update\latest.json'),
    (Join-Path $script:ScriptDir 'latest.json'),
    (Join-Path (Split-Path -Parent $script:ScriptDir) 'latest.json')
  )
  foreach ($p in $locals) {
    if (Test-Path -LiteralPath $p) { return [IO.Path]::GetFullPath($p) }
  }
  return $null
}

function Read-TextFrom([string]$src) {
  if ($src -match '^https?://') {
    $lastError = ''
    foreach ($url in (Get-DownloadCandidates $src)) {
      for ($attempt = 1; $attempt -le 2; $attempt++) {
        try {
          Log ("正在读取更新清单（第 $attempt 次）：" + $url)
          $r = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 30
          try {
            if ($r.RawContentStream) {
              return [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
            }
          } catch { }
          return [string]$r.Content
        } catch {
          $lastError = $_.Exception.Message
          Log ('读取更新清单失败：' + $url + '：' + $lastError)
          if ($attempt -lt 2) { Start-Sleep -Seconds 2 }
        }
      }
    }
    throw ('读取更新清单失败（已尝试镜像和重试）：' + $src + '；最后错误：' + $lastError)
  }
  $p = $src
  if ($src -match '^file://') { $p = ([Uri]$src).LocalPath }
  return (Get-Content -LiteralPath $p -Raw -Encoding UTF8)
}

function Resolve-Ref([string]$manifestSource, [string]$ref) {
  if (-not $ref) { return $null }
  if ($ref -match '^[a-zA-Z][a-zA-Z0-9+.-]*://') { return $ref }
  if ($manifestSource -match '^https?://') {
    return ([Uri]::new([Uri]$manifestSource, $ref)).AbsoluteUri
  }
  $p = $manifestSource
  if ($p -match '^file://') { $p = ([Uri]$p).LocalPath }
  $baseDir = Split-Path -Parent ([IO.Path]::GetFullPath($p))
  return [IO.Path]::GetFullPath((Join-Path $baseDir $ref))
}

function Test-HttpUrl([string]$url) {
  return ($url -match '^https?://')
}

function Get-DownloadCandidates([string]$url) {
  $list = New-Object System.Collections.Generic.List[string]
  $list.Add($url)
  if ($url -match '^https://ghfast\.top/(https?://.+)$') {
    $direct = $Matches[1]
    if (-not $list.Contains($direct)) { $list.Add($direct) }
  } elseif ($url -match '^https://raw\.githubusercontent\.com/.+') {
    $mirror = 'https://ghfast.top/' + $url
    if (-not $list.Contains($mirror)) { $list.Add($mirror) }
  }
  return $list
}

function Test-DownloadSpeed([string]$url, [int]$sampleBytes = 524288, [int]$timeoutMs = 8000) {
  if (-not (Test-HttpUrl $url)) { return 0 }
  try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
  Add-Type -AssemblyName System.Net.Http -ErrorAction SilentlyContinue
  $handler = New-Object System.Net.Http.HttpClientHandler
  $handler.AllowAutoRedirect = $true
  $client = New-Object System.Net.Http.HttpClient($handler)
  $client.Timeout = [TimeSpan]::FromMilliseconds($timeoutMs)
  $req = New-Object System.Net.Http.HttpRequestMessage([System.Net.Http.HttpMethod]::Get, $url)
  [void]$req.Headers.TryAddWithoutValidation('Range', ('bytes=0-' + ($sampleBytes - 1)))
  $resp = $null
  $stream = $null
  $cts = New-Object System.Threading.CancellationTokenSource
  try {
    $cts.CancelAfter($timeoutMs)
    $resp = $client.SendAsync($req, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead, $cts.Token).GetAwaiter().GetResult()
    if (-not $resp.IsSuccessStatusCode) { return 0 }
    $stream = $resp.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
    $buf = New-Object byte[] 65536
    $total = 0
    $sw = [Diagnostics.Stopwatch]::StartNew()
    while ($total -lt $sampleBytes -and $sw.ElapsedMilliseconds -lt $timeoutMs) {
      $left = $timeoutMs - [int]$sw.ElapsedMilliseconds
      if ($left -le 0) { break }
      $readTask = $stream.ReadAsync($buf, 0, $buf.Length, $cts.Token)
      if (-not $readTask.Wait($left)) { break }
      $n = $readTask.Result
      if ($n -le 0) { break }
      $total += $n
    }
    $sw.Stop()
    if ($total -le 0) { return 0 }
    return ([double]$total / [math]::Max($sw.Elapsed.TotalSeconds, 0.001))
  } catch {
    return 0
  } finally {
    try { if ($cts) { $cts.Cancel() } } catch { }
    try { if ($stream) { $stream.Dispose() } } catch { }
    try { if ($resp) { $resp.Dispose() } } catch { }
    try { if ($req) { $req.Dispose() } } catch { }
    try { if ($client) { $client.Dispose() } } catch { }
    try { if ($cts) { $cts.Dispose() } } catch { }
  }
}

function Get-FastestDownloadCandidates([string]$url) {
  $candidates = @(Get-DownloadCandidates $url)
  $httpCandidates = @($candidates | Where-Object { Test-HttpUrl $_ })
  if ($httpCandidates.Count -le 1) { return $candidates }

  Log '正在测速下载节点…'
  $scored = @()
  foreach ($c in $httpCandidates) {
    $speed = Test-DownloadSpeed $c
    $scored += [pscustomobject]@{ Url = $c; Speed = $speed }
    Log ('测速：' + $c + ' = ' + [math]::Round($speed / 1KB, 1) + ' KB/s')
  }
  if (@($scored | Where-Object { $_.Speed -gt 0 }).Count -eq 0) {
    Log '测速全部失败，按原候选顺序下载'
    return $candidates
  }
  $ordered = @($scored | Sort-Object -Property Speed -Descending | ForEach-Object { $_.Url })
  foreach ($c in $candidates) {
    if ($ordered -notcontains $c) { $ordered += $c }
  }
  Log ('选择最快的下载节点：' + $ordered[0])
  return $ordered
}

function Download-File([string]$url, [string]$dest, $item = $null) {
  $dir = Split-Path -Parent $dest
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $bits = $null
  if (Test-HttpUrl $url) {
    $bits = Get-Command Start-BitsTransfer -ErrorAction SilentlyContinue
  }
  $lastError = ''
  foreach ($src in (Get-FastestDownloadCandidates $url)) {
    for ($attempt = 1; $attempt -le 2; $attempt++) {
      try {
        if (Test-HttpUrl $src) {
          if ($attempt -eq 1 -and $bits) {
            try {
              Log ('使用 BITS 下载：' + $src)
              Start-BitsTransfer -Source $src -Destination $dest -Description 'Claude 工作台更新' -ErrorAction Stop
              if ($item) { Test-Downloaded $dest $item }
              return
            } catch {
              $lastError = $_.Exception.Message
              Log ('BITS 下载失败，改用 HTTP 方式：' + $lastError)
              if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue }
            }
          }
          Log ("正在下载（第 $attempt 次）：" + $src)
          Invoke-WebRequest -Uri $src -OutFile $dest -UseBasicParsing -TimeoutSec 600
          if ($item) { Test-Downloaded $dest $item }
          return
        }
        $local = $src
        if ($src -match '^file://') { $local = ([Uri]$src).LocalPath }
        Log ('从本地复制：' + $local)
        Copy-Item -LiteralPath $local -Destination $dest -Force
        if ($item) { Test-Downloaded $dest $item }
        return
      } catch {
        $lastError = $_.Exception.Message
        Log ('下载失败：' + $src + '：' + $lastError)
        if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue }
        if ($attempt -lt 2) { Start-Sleep -Seconds 2 }
      }
    }
  }
  throw ('下载失败（已尝试镜像和重试）：' + $url + '；最后错误：' + $lastError)
}

function Test-Downloaded([string]$path, $item) {
  if (-not (Test-Path -LiteralPath $path)) { throw '下载失败，文件不存在' }
  if ($item.size) {
    $actual = (Get-Item -LiteralPath $path).Length
    if ([long]$actual -ne [long]$item.size) {
      throw ("文件大小不一致：期望 " + $item.size + "，实际 " + $actual)
    }
  }
  if ($item.sha256) {
    $h = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower()
    if ($h -ne ([string]$item.sha256).ToLower()) {
      throw 'SHA256 校验失败，文件可能不完整或被篡改'
    }
    Log 'SHA256 校验通过'
  } else {
    Log '警告：清单没有提供 SHA256，跳过校验'
  }
}

function Stop-Client([string]$dir, [switch]$ForRecovery) {
  $full = [IO.Path]::GetFullPath($dir).TrimEnd('\') + '\'
  $procs = @()
  try {
    $procs = @(Get-CimInstance Win32_Process -Filter "Name='node.exe' OR Name='electron.exe' OR Name='electron-workbench.exe'")
  } catch { }

  if ($ForRecovery) {
    $desktop = Join-Path $full 'claude-gui\desktop\node_modules\electron\dist'
    $executables = @((Join-Path $desktop 'electron.exe'), (Join-Path $desktop 'electron-workbench.exe'))
    $serverScript = Join-Path $full 'claude-gui\server.js'
    $runtimeFile = Join-Path $full 'claude-gui\data\runtime.json'
    $runtime = $null
    try { $runtime = Get-Content -LiteralPath $runtimeFile -Raw -Encoding UTF8 | ConvertFrom-Json } catch { }
    $petExecutables = @((Join-Path $full 'dsh-pet\runtime\node.exe'), (Join-Path $full 'dsh-pet\runtime\electron\electron.exe'))
    $desktopProcesses = @($procs | Where-Object { $_.ExecutablePath -in $executables })
    # 浏览器版.cmd 在 claude-gui 下运行 node server.js；node.exe 也可能来自系统 PATH。
    $nodeCommand = '^\s*(?:"[^"]+"|\S+)\s+'
    $absolute = $nodeCommand + '(?:"' + [regex]::Escape($serverScript) + '"|' + [regex]::Escape($serverScript) + ')(?:\s|$)'
    $relative = $nodeCommand + '"?(?:\.\\)?server\.js"?(?:\s|$)'
    $browserServers = @($procs | Where-Object {
      if ($_.Name -ne 'node.exe' -or -not $_.ExecutablePath) { return $false }
      $command = ([string]$_.CommandLine).Replace('/', '\')
      if ($command -match $absolute) { return $true }
      if ($command -notmatch $relative -or -not $runtime -or $_.ProcessId -ne $runtime.pid) { return $false }
      # 陈旧 runtime.json 中的 PID 可能已被其他程序重新使用。
      try { return $_.CreationDate.ToUniversalTime() -le ([datetimeoffset]$runtime.updatedAt).UtcDateTime }
      catch { return $false }
    })
    $procs = $desktopProcesses + $browserServers + @($procs | Where-Object { $_.ExecutablePath -in $petExecutables })
    if (-not $procs.Count) { return $false }
  } else {
    $procs = @($procs | Where-Object {
      $_.ExecutablePath -and ([IO.Path]::GetFullPath($_.ExecutablePath)).StartsWith($full, [StringComparison]::OrdinalIgnoreCase)
    })
  }

  $killed = 0
  $oldEap = $ErrorActionPreference
  try {
    # 进程可能刚好已经退出，taskkill 的 "not found" 在 Stop 模式下会中断更新。
    # 这里临时降为 SilentlyContinue，同时保留 taskkill /T 的整棵进程树清理能力。
    $ErrorActionPreference = 'SilentlyContinue'
    foreach ($p in $procs) {
      if ($p.Name -match '^(electron|electron-workbench)\.exe$') {
        Log ("关闭工作台进程 PID " + $p.ProcessId)
        & taskkill.exe /PID $p.ProcessId /T /F 2>&1 | Out-Null
        $killed++
      }
    }
    Start-Sleep -Milliseconds 900
    foreach ($p in $procs) {
      if ($p.Name -match '^(node|electron|electron-workbench)\.exe$') {
        # 第一轮已经关掉的 PID 再处理一次是正常情况，不会再报错。
        & taskkill.exe /PID $p.ProcessId /T /F 2>&1 | Out-Null
        $killed++
      }
    }
  } finally {
    $ErrorActionPreference = $oldEap
  }
  if ($killed -eq 0) { Log '工作台没有在运行（或未找到进程）' }
  Start-Sleep -Milliseconds 500
  if ($ForRecovery) {
    if ($desktopProcesses.Count) { return 'desktop' }
    if ($browserServers.Count) { return 'browser' }
  }
}

# 补丁先在临时目录完整展开，再记录旧文件。pending.json 一旦发布，即可反复回滚。
function Get-PatchPath([string]$root, [string]$relative) {
  $rel = $relative.Replace('/', '\')
  foreach ($part in $rel.Split('\')) {
    if (-not $part -or $part -match '[<>:"|?*\x00-\x1f]|[ .]$|^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\.|$)') {
      throw ('补丁文件路径无效：' + $relative)
    }
  }
  $base = [IO.Path]::GetFullPath($root).TrimEnd('\') + '\'
  $target = [IO.Path]::GetFullPath([IO.Path]::Combine($base, $rel))
  if (-not $target.StartsWith($base, [StringComparison]::OrdinalIgnoreCase)) { throw ('路径超出目录：' + $relative) }
  $p = $target
  while ($p.Length -ge $base.Length) {
    $longP = Get-LongPath $p
    if (([IO.File]::Exists($longP) -or [IO.Directory]::Exists($longP)) -and
        (([IO.File]::GetAttributes($longP) -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
      throw ('补丁路径经过文件系统链接：' + $p)
    }
    if ($p -ne $target -and [IO.File]::Exists($longP)) { throw ('补丁目录与现有文件冲突：' + $p) }
    $p = [IO.Path]::GetDirectoryName($p)
  }
  return $target
}

function Test-SkippedPatchPath([string]$rel) {
  return $rel -match '^(claude-gui\\data|_test-profile|update-backup)(\\|$)|^tools\\update-config\.json$'
}

# Windows 传统 API 默认限制 260 字符；playwright-core 等深层文件会超过。
# 给 .NET 文件 API 加 \\?\ 前缀可以绕过（UNC 路径用 \\?\UNC\）。
function Get-LongPath([string]$path) {
  if (-not $path) { return $path }
  if ($path.StartsWith('\\?\')) { return $path }
  $full = [IO.Path]::GetFullPath($path)
  if ($full.StartsWith('\\')) { return ('\\?\UNC\' + $full.Substring(2)) }
  return ('\\?\' + $full)
}

function Get-Sha256File([string]$path) {
  $sha = [Security.Cryptography.SHA256]::Create()
  $stream = [IO.File]::OpenRead((Get-LongPath $path))
  try {
    return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '').ToLowerInvariant()
  } finally {
    $stream.Dispose()
    $sha.Dispose()
  }
}

function Prepare-Patch([string]$zipPath, [string]$dir, [string]$expectedVersion, [string]$marker) {
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  # 临时目录用短名，且只留一层子目录；旧版双层 GUID 加长文件名会超过 260 字符。
  $stage = Join-Path ([IO.Path]::GetDirectoryName($zipPath)) 's'
  [void][IO.Directory]::CreateDirectory($stage)
  $files = New-Object 'System.Collections.Generic.List[string]'
  $seen = @{}
  $archive = [IO.Compression.ZipFile]::OpenRead($zipPath)
  try {
    foreach ($e in $archive.Entries) {
      if (-not $e.Name) { continue }
      $rel = $e.FullName.Replace('/', '\')
      $target = Get-PatchPath $dir $rel
      if (Test-SkippedPatchPath $rel) { continue }
      if ($seen.ContainsKey($rel) -or [IO.Directory]::Exists((Get-LongPath $target))) { throw ('补丁文件重名或与目录冲突：' + $rel) }
      $seen[$rel] = $true
      $out = Join-Path $stage $rel
      [void][IO.Directory]::CreateDirectory((Get-LongPath ([IO.Path]::GetDirectoryName($out))))
      [IO.Compression.ZipFileExtensions]::ExtractToFile($e, (Get-LongPath $out), $false)
      if ($rel -ne $marker -and $rel -ne 'claude-gui\public\version.json') { $files.Add($rel) }
    }
    if (-not $seen.ContainsKey($marker)) { throw ('补丁缺少版本文件：' + $marker) }
    foreach ($rel in @('claude-gui\public\version.json', $marker)) {
      if (-not $seen.ContainsKey($rel)) { continue }
      $version = (Get-Content -LiteralPath (Join-Path $stage $rel) -Raw -Encoding UTF8 | ConvertFrom-Json).version
      if (-not $version -or (Compare-Version ([string]$version) $expectedVersion) -ne 0) {
        throw ('补丁版本与清单不符：' + $rel)
      }
      $files.Add($rel)
    }
    return [pscustomobject]@{ stage = $stage; files = $files }
  } finally {
    $archive.Dispose()
  }
}

function Copy-PatchFile([string]$source, [string]$dest) {
  $inputFile = [IO.File]::OpenRead((Get-LongPath $source))
  try {
    $outputFile = [IO.File]::Open((Get-LongPath $dest), [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
      $inputFile.CopyTo($outputFile)
      $outputFile.Flush($true)
    } finally { $outputFile.Dispose() }
  } finally { $inputFile.Dispose() }
  try { [IO.File]::SetLastWriteTimeUtc((Get-LongPath $dest), [IO.File]::GetLastWriteTimeUtc((Get-LongPath $source))) } catch { }
}

function Install-PatchFile([string]$source, [string]$dest, [string]$scratch) {
  [IO.File]::Delete((Get-LongPath $scratch))
  Copy-PatchFile $source $scratch
  if ([IO.File]::Exists((Get-LongPath $dest))) {
    # PowerShell 的 $null 会传为 System.String.Empty；用 NullString 表示不另建 Replace 备份。
    [IO.File]::Replace((Get-LongPath $scratch), (Get-LongPath $dest), [System.Management.Automation.Language.NullString]::Value, $true)
  } else { [IO.File]::Move((Get-LongPath $scratch), (Get-LongPath $dest)) }
}

function Read-PendingPatch([string]$dir) {
  $journal = Get-PatchPath $dir 'update-backup\pending.json'
  if (-not [IO.File]::Exists($journal)) { return }
  $txn = Get-Content -LiteralPath $journal -Raw -Encoding UTF8 | ConvertFrom-Json
  if ($txn.format -ne 1 -or $txn.id -notmatch '^\d{8}-\d{6}-[a-f0-9]{32}$' -or -not $txn.files) {
    throw ('无法读取更新恢复记录：' + $journal)
  }
  $backup = Get-PatchPath $dir ('update-backup\' + $txn.id)
  $files = New-Object 'System.Collections.Generic.List[object]'
  foreach ($entry in $txn.files) {
    $rel = ([string]$entry.path).Replace('/', '\')
    if ($entry.existed -isnot [bool] -or (Test-SkippedPatchPath $rel)) { throw '更新恢复记录的文件信息无效' }
    $target = Get-PatchPath $dir $rel
    $old = $null
    if ($entry.existed) {
      $old = Get-PatchPath $backup ('original\' + $rel)
      if (-not [IO.File]::Exists((Get-LongPath $old))) { throw ('找不到更新前的备份：' + $old) }
    }
    $files.Add([pscustomobject]@{ target = $target; original = $old })
  }
  return [pscustomobject]@{ files = $files; journal = $journal; backup = $backup; scratch = (Get-PatchPath $backup 'replace.tmp') }
}

function Restore-PendingPatch([string]$dir, $recovery = $null) {
  if (-not $recovery) { $recovery = Read-PendingPatch $dir }
  if (-not $recovery) { return }
  foreach ($entry in $recovery.files) {
    $target = $entry.target
    $old = $entry.original
    if ($old) {
      if ([IO.File]::Exists((Get-LongPath $target)) -and
          (Get-Sha256File $target) -eq (Get-Sha256File $old)) { continue }
      [void][IO.Directory]::CreateDirectory((Get-LongPath ([IO.Path]::GetDirectoryName($target))))
      Install-PatchFile $old $target $recovery.scratch
    } else { [IO.File]::Delete((Get-LongPath $target)) }
  }
  [IO.File]::Delete((Get-LongPath $recovery.scratch))
  [IO.File]::Delete((Get-LongPath $recovery.journal))
  Log ('已恢复更新前的文件。备份位于 ' + $recovery.backup)
}

function Apply-Patch($plan, [string]$dir) {
  $id = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N')
  $backup = Get-PatchPath $dir ('update-backup\' + $id)
  [void][IO.Directory]::CreateDirectory((Get-LongPath $backup))
  $journal = Get-PatchPath $dir 'update-backup\pending.json'
  $scratch = Join-Path $backup 'replace.tmp'
  $entries = New-Object 'System.Collections.Generic.List[object]'
  foreach ($rel in $plan.files) {
    $dest = Get-PatchPath $dir $rel
    $exists = [IO.File]::Exists((Get-LongPath $dest))
    if ($exists) {
      $saved = Join-Path $backup ('original\' + $rel)
      [void][IO.Directory]::CreateDirectory((Get-LongPath ([IO.Path]::GetDirectoryName($saved))))
      Copy-PatchFile $dest $saved
    }
    $entries.Add([pscustomobject]@{path = $rel; existed = $exists})
  }
  $record = [ordered]@{format = 1; id = $id; files = $entries}
  $bytes = [Text.Encoding]::UTF8.GetBytes(($record | ConvertTo-Json -Depth 4 -Compress))
  $tmp = Join-Path $backup 'pending.tmp'
  $stream = [IO.File]::Create((Get-LongPath $tmp))
  try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
  [IO.File]::Move((Get-LongPath $tmp), (Get-LongPath $journal))
  try {
    foreach ($entry in $entries) {
      $dest = Get-PatchPath $dir $entry.path
      [void][IO.Directory]::CreateDirectory((Get-LongPath ([IO.Path]::GetDirectoryName($dest))))
      Install-PatchFile (Join-Path $plan.stage $entry.path) $dest $scratch
    }
    [IO.File]::Delete((Get-LongPath $journal))
  } catch {
    $failure = $_.Exception.Message
    try { Restore-PendingPatch $dir }
    catch { throw ('更新失败：' + $failure + '。未能完成恢复，下次检查将重试：' + $_.Exception.Message) }
    throw ('更新失败，已恢复旧文件：' + $failure)
  }
  Log ('已替换 ' + $entries.Count + ' 个文件；旧文件备份在 ' + $backup)
}

function Run-Installer([string]$exe) {
  Log '正在运行安装程序（静默升级，保留对话和 API Key）…'
  $p = Start-Process -FilePath $exe -ArgumentList '/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART' -Wait -PassThru
  if ($p.ExitCode -ne 0) { throw ('安装程序返回代码 ' + $p.ExitCode) }
}

# 桌宠补丁：更新包只带 bridge\patch-dsh-pet.js，安装后按当前 dsh-pet 版本重打补丁。
# 这样 0.3.8 / 0.4.7 都能兼容，也不会把已升级的 0.4.7 helper 降级成旧版。
function Update-DshPetPatch([string]$dir) {
  $bridge = Join-Path $dir 'dsh-pet\bridge\patch-dsh-pet.js'
  if (-not (Test-Path -LiteralPath $bridge)) { return }
  $node = Join-Path $dir 'dsh-pet\runtime\node.exe'
  if (-not (Test-Path -LiteralPath $node)) {
    $node = Join-Path $dir 'claude-gui\runtime\node.exe'
  }
  if (-not (Test-Path -LiteralPath $node)) {
    Log '桌宠补丁跳过：找不到可用的 node.exe'
    return
  }
  Log '正在重打桌宠集成补丁…'
  try {
    $out = & $node $bridge 2>&1
    foreach ($line in @($out)) {
      if ($line) { Log ('  ' + [string]$line) }
    }
    if ($LASTEXITCODE -ne 0) { Log ('桌宠补丁返回代码 ' + $LASTEXITCODE) }
  } catch {
    Log ('桌宠补丁失败：' + $_.Exception.Message)
  }
}

function Get-WorkbenchLaunchTargets([string]$dir) {
  $desktopDir = Join-Path $dir 'claude-gui\desktop'
  return [pscustomobject]@{
    DesktopDir = $desktopDir
    Exe = Join-Path $desktopDir 'node_modules\electron\dist\electron.exe'
    Vbs = Join-Path $dir 'claude-gui\启动界面.vbs'
    Icon = Join-Path $desktopDir 'icon.ico'
  }
}

# 旧版桌面/开始菜单快捷方式指向 启动工作台.cmd，会先开一个 cmd 窗口，
# Electron 附在上面：关掉窗口会连工作台一起退出，部分系统还会报内存错误。
# 更新时顺手把已有的快捷方式改成直接指向 electron.exe。
function Test-StandardWorkbenchShortcut($shortcut, [string]$dir, $targets) {
  $target = [Environment]::ExpandEnvironmentVariables([string]$shortcut.TargetPath)
  if ($target -notmatch '^(?:[A-Z]:[\\/]|\\\\)') { return $false }
  $target = [IO.Path]::GetFullPath($target)
  $arguments = ([string]$shortcut.Arguments).Trim()
  $legacy = @((Join-Path $dir '启动工作台.cmd'), (Join-Path $dir 'claude-gui\启动界面.cmd'), $targets.Vbs)
  if ($target -in $legacy) { return ($arguments.Length -eq 0) }

  $alternate = Join-Path ([IO.Path]::GetDirectoryName($targets.Exe)) 'electron-workbench.exe'
  if ($target -in @($targets.Exe, $alternate)) {
    # 同一个 Electron 也能运行别的项目或使用专用启动参数。
    return (($arguments -eq '' -and $shortcut.WorkingDirectory -eq $targets.DesktopDir) -or
        $arguments -eq ('"' + $targets.DesktopDir + '"') -or
        ($targets.DesktopDir -notmatch '\s' -and $arguments -eq $targets.DesktopDir))
  }

  $hostDir = [IO.Path]::GetDirectoryName($target)
  if ($hostDir -notin @((Join-Path $env:SystemRoot 'System32'), (Join-Path $env:SystemRoot 'SysWOW64'))) { return $false }
  $hostName = [IO.Path]::GetFileName($target)
  if ($hostName -eq 'wscript.exe') {
    $scriptArg = $arguments -replace '^(?i://nologo)\s+', ''
    return ($scriptArg -eq ('"' + $targets.Vbs + '"') -or ($targets.Vbs -notmatch '\s' -and $scriptArg -eq $targets.Vbs))
  }
  if ($hostName -ne 'cmd.exe' -or $arguments -notmatch '^(?:/d\s+)?/c\s+(.+)$') { return $false }
  $command = $Matches[1]
  foreach ($file in $legacy) {
    if ([IO.Path]::GetExtension($file) -ne '.cmd') { continue }
    if ($command -eq ('"' + $file + '"') -or $command -eq ('""' + $file + '""') -or
        ($file -notmatch '[\s&|<>()^%!"\x00-\x1f]' -and $command -eq $file)) { return $true }
  }
  return $false
}

function Repair-Shortcuts([string]$dir,
    [string]$desktop = [Environment]::GetFolderPath('Desktop'),
    [string]$programs = [Environment]::GetFolderPath('Programs')) {
  $dir = [IO.Path]::GetFullPath($dir)
  $t = Get-WorkbenchLaunchTargets $dir
  if (-not (Test-Path -LiteralPath $t.Exe)) { return }

  $paths = New-Object System.Collections.Generic.List[string]
  if ($desktop) {
    $paths.Add((Join-Path $desktop 'Claude 工作台.lnk'))
    $paths.Add((Join-Path $desktop 'Claude Code Workbench.lnk'))
  }
  if ($programs) {
    $paths.Add((Join-Path (Join-Path $programs 'Claude 工作台') 'Claude 工作台.lnk'))
  }

  $ws = $null
  try { $ws = New-Object -ComObject WScript.Shell } catch { return }
  foreach ($p in $paths) {
    if (-not (Test-Path -LiteralPath $p)) { continue }
    try {
      $s = $ws.CreateShortcut($p)
      if (-not (Test-StandardWorkbenchShortcut $s $dir $t)) { continue }
      if ($s.TargetPath -eq $t.Exe -and $s.Arguments -eq ('"' + $t.DesktopDir + '"') -and
          $s.WorkingDirectory -eq $t.DesktopDir) { continue }
      $s.TargetPath = $t.Exe
      $s.Arguments = '"' + $t.DesktopDir + '"'
      $s.WorkingDirectory = $t.DesktopDir
      $s.IconLocation = $t.Icon + ',0'
      $s.Save()
      Log ('已修复快捷方式：' + $p)
    } catch {
      Log ('快捷方式更新失败：' + $p + ' — ' + $_.Exception.Message)
    }
  }
}

function Start-Workbench([string]$dir, [string]$mode = 'desktop') {
  if ($NoLaunch) { Log '已按参数跳过启动'; return }
  if ($mode -eq 'browser') {
    $guiDir = Join-Path $dir 'claude-gui'
    $browserLauncher = Join-Path $guiDir '浏览器版.cmd'
    if (Test-Path -LiteralPath $browserLauncher -PathType Leaf) {
      Log '正在重新启动浏览器版工作台…'
      Start-Process -FilePath $browserLauncher -WorkingDirectory $guiDir
      return
    }
  }
  $t = Get-WorkbenchLaunchTargets $dir
  if (Test-Path -LiteralPath $t.Vbs) {
    # wscript 没有控制台，能保证工作台不挂在更新窗口上。
    Log '正在重新启动工作台…'
    Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\wscript.exe') -ArgumentList '//nologo', ('"' + $t.Vbs + '"')
    return
  }
  if (Test-Path -LiteralPath $t.Exe) {
    Log '正在重新启动工作台…'
    Start-Process -FilePath $t.Exe -ArgumentList ('"' + $t.DesktopDir + '"') -WorkingDirectory $t.DesktopDir
    return
  }
  $launcher = Join-Path $dir '启动工作台.cmd'
  if (Test-Path -LiteralPath $launcher) {
    Log '正在重新启动工作台…'
    Start-Process -FilePath $launcher -WorkingDirectory $dir
  } else {
    Log '没找到 启动工作台.cmd，请手动打开工作台'
  }
}

function Main {
  if (-not $Manifest) { $Manifest = [string]$env:WORKBENCH_UPDATE_MANIFEST }
  $dir = Find-InstallDir $InstallDir
  if (-not $dir) {
    Show-ErrorAndExit "找不到 Claude 工作台安装目录。`n`n默认应该在：$env:LOCALAPPDATA\Programs\AI_Claude`n请把本工具放到安装目录，或用 -InstallDir 指定。"
  }
  Log ("安装目录：" + $dir)

  # 以安装目录为单位串行化检查、恢复和替换，进程被强停时操作系统会释放锁。
  $hash = [Security.Cryptography.SHA256]::Create()
  try {
    $name = [BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($dir.TrimEnd('\').ToUpperInvariant()))).Replace('-', '')
  } finally { $hash.Dispose() }
  $script:UpdateLock = New-Object Threading.Mutex($false, ('Global\ClaudeWorkbenchUpdate-' + $name))
  try { $script:LockOwned = $script:UpdateLock.WaitOne(0) }
  catch [Threading.AbandonedMutexException] { $script:LockOwned = $true }
  if (-not $script:LockOwned) { Show-Info '此安装目录的更新检查已在运行'; return }
  $reopen = $false
  $journal = Get-PatchPath $dir 'update-backup\pending.json'
  if ([IO.File]::Exists($journal)) {
    if ($CheckOnly -or $DryRun) {
      Show-Info '检测到上次更新尚未完成。请运行常规更新以恢复原版本，再检查新版本。'
      return
    }
    $recovery = Read-PendingPatch $dir
    $prompt = '上次更新尚未完成。恢复会关闭此安装目录的工作台和桌宠，中断正在运行的任务，并还原更新前的程序文件。现在恢复并继续检查更新吗？'
    Log $prompt
    if (-not (Ask-YesNo $prompt)) { Log '已取消恢复'; return }
    $wasRunning = Stop-Client $dir -ForRecovery
    try { Restore-PendingPatch $dir $recovery }
    catch { throw ('恢复未完成，记录已保留。请关闭占用程序后重试。' + $_.Exception.Message) }
    $reopen = $wasRunning
  }
  try {
    Update-Workbench $dir ([ref]$reopen)
  } finally {
    # 恢复后若已是最新版、用户取消或获取清单失败，重新打开原先运行的工作台。
    if ($reopen) { Start-Workbench $dir $reopen }
  }
}

function Update-Workbench([string]$dir, [ref]$reopenAfterRecovery) {
  $localVer = Get-LocalVersion $dir
  if (-not $localVer) {
    Show-ErrorAndExit '读不到 claude-gui\version.json，安装可能不完整'
  }
  Log ("当前版本：" + $localVer)

  $src = Get-ManifestSource $dir $Manifest
  if (-not $src) {
    Show-ErrorAndExit "还没有配置更新地址。`n`n请让分享者把 latest.json 的链接填到：`n$dir\tools\update-config.json`n或者把 latest.json 放到安装目录/update 子目录。"
  }
  Log ("更新清单：" + $src)

  $text = Read-TextFrom $src
  $m = $text | ConvertFrom-Json
  if ($m.app -and [string]$m.app -ne 'claude-workbench') {
    throw ('清单的 app 不是 claude-workbench：' + $m.app)
  }
  $remoteVer = [string]$m.version
  if (-not $remoteVer) { throw '清单缺少 version 字段' }
  Log ("最新版本：" + $remoteVer)

  $clientNeedsUpdate = (Compare-Version $localVer $remoteVer) -lt 0
  $dshPet = $m.dshPet
  $localDsh = Get-DshPetVersion $dir
  $needDshPet = $false
  if ($dshPet -and $dshPet.url -and $dshPet.version) {
    $needDshPet = (-not $localDsh) -or
      ((Compare-Version $localDsh ([string]$dshPet.version)) -lt 0)
  }

  if (-not $clientNeedsUpdate -and -not $needDshPet) {
    if (-not $NoSuccessInfo) { Show-Info ("已经是最新版本 " + $localVer) }
    return
  }

  $notes = [string]$m.notes
  if ($clientNeedsUpdate) {
    $msg = "发现新版本 $remoteVer`n当前版本：$localVer`n"
    if ($notes) { $msg += "`n更新内容：`n$notes`n" }
  } else {
    $msg = "发现桌宠更新 " + [string]$dshPet.version + "`n当前桌宠：" +
      $(if ($localDsh) { $localDsh } else { '未安装' }) + "`n"
  }
  $msg += "`n现在更新吗？"

  if ($CheckOnly) {
    Show-Info $msg
    return
  }
  if (-not (Ask-YesNo $msg)) { Log '已取消'; return }

  $item = $null
  $kind = ''
  $url = ''
  if ($clientNeedsUpdate) {
    $patch = $m.patch
    $full = $m.full
    $usePatch = $false
    if ($patch -and $patch.url) {
      $usePatch = $true
      if ($patch.fromVersion) {
        if ((Compare-Version $localVer ([string]$patch.fromVersion)) -lt 0) {
          Log ('当前版本低于补丁的起始版本 ' + $patch.fromVersion + '，改用完整安装包')
          $usePatch = $false
        }
      }
    }
    if ($usePatch) { $item = $patch; $kind = 'patch' }
    elseif ($full -and $full.url) { $item = $full; $kind = 'full' }
    else { throw '清单里没有可用的更新文件（patch/full 都为空）' }
    $url = Resolve-Ref $src ([string]$item.url)
    Log ("更新方式：" + $(if ($kind -eq 'patch') { '增量补丁' } else { '完整安装包' }))
    Log ("下载地址：" + $url)
  }

  # 桌宠单独打包：本地已经是清单版本就跳过；否则和客户端补丁一起下载、一起应用。
  $dshPetUrl = ''
  if ($needDshPet) {
    $dshPetUrl = Resolve-Ref $src ([string]$dshPet.url)
    Log ("桌宠版本：" + $(if ($localDsh) { $localDsh } else { '未安装' }) +
      "，将一并更新到 " + $dshPet.version)
    Log ("桌宠更新包：" + $dshPetUrl)
  } elseif ($dshPet -and $dshPet.version) {
    Log ("桌宠已是最新：" + $localDsh)
  }

  if ($DryRun) {
    $dry = if ($kind -eq 'patch') {
      "演练模式：将下载`n$url`n`n然后替换程序文件"
    } elseif ($kind -eq 'full') {
      "演练模式：将下载`n$url`n`n然后运行安装程序"
    } else {
      "演练模式：只更新桌宠"
    }
    if ($needDshPet) { $dry += "`n`n再应用桌宠更新包`n$dshPetUrl" }
    Show-Info $dry
    return
  }

  # 临时目录用短名：旧名加两层 GUID 会让 playwright-core 的深层文件超过 260 字符。
  $tempRoot = Join-Path $env:TEMP ('cw\' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force -Path $tempRoot | Out-Null
  $script:DownloadDir = $tempRoot
  $dest = $null
  if ($item) {
    $fileName = ''
    try { $fileName = [IO.Path]::GetFileName(([Uri]$url).AbsolutePath) } catch { $fileName = '' }
    if (-not $fileName) { $fileName = [IO.Path]::GetFileName($url) }
    if (-not $fileName) { $fileName = 'update.bin' }
    $dest = Join-Path $tempRoot $fileName
    Download-File $url $dest $item
  }

  $clientPlan = $null
  if ($kind -eq 'patch') {
    $clientPlan = Prepare-Patch $dest $dir $remoteVer 'claude-gui\version.json'
  }
  $dshDest = $null
  if ($needDshPet) {
    $dshName = ''
    try { $dshName = [IO.Path]::GetFileName(([Uri]$dshPetUrl).AbsolutePath) } catch { $dshName = '' }
    if (-not $dshName) { $dshName = [IO.Path]::GetFileName($dshPetUrl) }
    if (-not $dshName) { $dshName = 'dsh-pet.zip' }
    $dshDest = Join-Path (Join-Path $tempRoot 'pet') $dshName
    Download-File $dshPetUrl $dshDest $dshPet
  }

  if ($needDshPet) {
    $petPlan = Prepare-Patch $dshDest $dir ([string]$dshPet.version) 'dsh-pet\node_modules\dsh-pet\package.json'
  }
  # 已确认并准备好实际更新，正常更新流程接管关闭和重启。
  $launchMode = $reopenAfterRecovery.Value
  $reopenAfterRecovery.Value = $false
  Stop-Client $dir

  if ($kind -eq 'patch') {
    Log '正在应用增量补丁…'
    Apply-Patch $clientPlan $dir
  } elseif ($kind -eq 'full') {
    Run-Installer $dest
  }

  if ($needDshPet -and $dshDest) {
    Log ('正在应用桌宠更新 ' + [string]$dshPet.version + '…')
    Apply-Patch $petPlan $dir
    $nowDsh = Get-DshPetVersion $dir
    if ($nowDsh) { Log ("桌宠更新后版本：" + $nowDsh) }
    if ($nowDsh -and (Compare-Version $nowDsh ([string]$dshPet.version)) -ne 0) {
      Log ("警告：桌宠版本是 " + $nowDsh + "，清单写的是 " + $dshPet.version)
    }
  }

  Update-DshPetPatch $dir

  $now = Get-LocalVersion $dir
  if ($now) { Log ("更新后版本：" + $now) }
  Repair-Shortcuts $dir

  # 客户端内更新（更新按钮/manual 检查更新）默认也会检查 Chrome；一键更新包用
  # -NoGui 调用本脚本，随后由一键更新.cmd 单独运行 tools\setup-chrome.ps1。
  if ($script:Gui) {
    $chromeSetup = Join-Path $dir 'claude-gui\tools\setup-chrome.ps1'
    if (Test-Path -LiteralPath $chromeSetup) {
      Log '正在检查/配置 Chrome…'
      $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
      try {
        & $psExe -NoProfile -ExecutionPolicy Bypass -File $chromeSetup -InstallDir $dir
      } catch {
        Log ('Chrome 配置失败：' + $_.Exception.Message)
      }
    }
  }

  if (-not $NoSuccessInfo) {
    Show-Info ("更新完成，当前版本 " + $(if ($now) { $now } else { $remoteVer }))
  }
  Start-Workbench $dir $launchMode
}

try {
  Main
} catch {
  Show-ErrorAndExit $_.Exception.Message
} finally {
  if ($script:LockOwned) { $script:UpdateLock.ReleaseMutex() }
  if ($script:UpdateLock) { $script:UpdateLock.Dispose() }
  if ($script:DownloadDir) {
    $downloadRoot = [IO.Path]::GetFullPath((Join-Path $env:TEMP 'cw'))
    $downloadDir = [IO.Path]::GetFullPath($script:DownloadDir)
    if ([IO.Path]::GetDirectoryName($downloadDir) -eq $downloadRoot -and
        [IO.Path]::GetFileName($downloadDir) -match '^[a-f0-9]{32}$') {
      Remove-Item -LiteralPath $downloadDir -Recurse -Force -ErrorAction SilentlyContinue
    }
  }
}
