param([int]$BrowserPid, [string]$Marker = '', [int]$AlertUser = 0, [switch]$ForegroundOnly)
$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;

public static class WorkbenchWindow {
    private delegate bool EnumProc(IntPtr hwnd, IntPtr arg);
    [DllImport("user32.dll")] private static extern bool EnumWindows(EnumProc callback, IntPtr arg);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] private static extern int GetWindowText(IntPtr hwnd, StringBuilder text, int count);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] private static extern int GetClassName(IntPtr hwnd, StringBuilder text, int count);
    [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern bool IsIconic(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern bool ShowWindow(IntPtr hwnd, int state);
    [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("kernel32.dll")] private static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")] private static extern bool AttachThreadInput(uint a, uint b, bool attach);
    [DllImport("user32.dll")] private static extern bool SetForegroundWindow(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern bool FlashWindow(IntPtr hwnd, bool invert);

    private static bool Matches(IntPtr hwnd, uint pid, string marker) {
        uint owner;
        GetWindowThreadProcessId(hwnd, out owner);
        if (owner != pid || !IsWindowVisible(hwnd)) return false;
        var name = new StringBuilder(256);
        GetClassName(hwnd, name, name.Capacity);
        if (!name.ToString().StartsWith("Chrome_WidgetWin_")) return false;
        if (String.IsNullOrEmpty(marker)) return true;
        var title = new StringBuilder(2048);
        GetWindowText(hwnd, title, title.Capacity);
        return title.ToString().IndexOf(marker, StringComparison.Ordinal) >= 0;
    }

    public static string ForegroundTitle(uint pid) {
        IntPtr hwnd = GetForegroundWindow();
        if (!Matches(hwnd, pid, "") || IsIconic(hwnd)) return null;
        StringBuilder title = new StringBuilder(2048);
        GetWindowText(hwnd, title, title.Capacity);
        return GetForegroundWindow() == hwnd ? title.ToString() : null;
    }

    public static long Show(uint pid, string marker, bool alert) {
        IntPtr target = IntPtr.Zero;
        // Chrome posts the active tab title to its native window asynchronously.
        for (int i = 0; i < 20 && target == IntPtr.Zero; ++i) {
            EnumWindows(delegate(IntPtr hwnd, IntPtr unused) {
                if (!Matches(hwnd, pid, marker)) return true;
                target = hwnd;
                return false;
            }, IntPtr.Zero);
            if (target == IntPtr.Zero) Thread.Sleep(50);
        }
        if (target == IntPtr.Zero) return 0;
        uint unusedPid;
        uint oldThread = GetWindowThreadProcessId(GetForegroundWindow(), out unusedPid);
        uint thisThread = GetCurrentThreadId();
        bool attached = oldThread != 0 && thisThread != oldThread && AttachThreadInput(thisThread, oldThread, true);
        try {
            if (!Matches(target, pid, marker)) return 0;
            if (IsIconic(target)) ShowWindow(target, 9);
            SetForegroundWindow(target);
            if (GetForegroundWindow() != target || !Matches(target, pid, marker)) return 0;
            if (alert) FlashWindow(target, true);
            return target.ToInt64();
        } finally {
            if (attached) AttachThreadInput(thisThread, oldThread, false);
        }
    }
}
'@
if ($ForegroundOnly) {
    [Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
    $title = [WorkbenchWindow]::ForegroundTitle($BrowserPid)
    [pscustomobject]@{foreground = $null -ne $title; title = $title} | ConvertTo-Json -Compress
    exit
}
$window = [WorkbenchWindow]::Show($BrowserPid, $Marker, [bool]$AlertUser)
if ($window -and $AlertUser) { [System.Media.SystemSounds]::Exclamation.Play() }
Write-Output $window
