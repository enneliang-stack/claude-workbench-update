'use strict';

// The CLI and its Playwright server share one process. Use the same context
// and target IDs as the bundled Chromium adapter, including empty contexts.
function chromiumContext(context) {
  const impl = context._connection.toImpl?.(context);
  if (impl?._browser.options.name !== 'chromium' || !impl._browser._session)
    throw new Error('This command requires the workbench Chromium CDP connection.');
  return impl;
}

async function createWindow(context) {
  const impl = chromiumContext(context);
  const session = impl._browser._session;
  const created = session.send('Target.createTarget', {
    url: 'about:blank',
    browserContextId: impl._browserContextId,
    newWindow: true,
    background: true
  });
  // Concurrent tabs and popups can arrive before the createTarget reply.
  const ownPage = context.waitForEvent('page', {
    predicate: async page => {
      const { targetId } = await created;
      if (page.isClosed())
        return false;
      try {
        return page._connection.toImpl(page).delegate._targetId === targetId;
      } catch {
        // A short-lived popup may already have lost its dispatcher.
        return false;
      }
    },
    timeout: 10000
  });
  try {
    const [, page] = await Promise.all([created, ownPage]);
    return page;
  } catch (error) {
    // If Chrome accepted the request but the page never attached, remove only
    // the target created by this call. Don't hold an error response indefinitely.
    void created.then(({ targetId }) => session.send('Target.closeTarget', { targetId })).catch(() => {});
    throw error;
  }
}

// One extra CDP session per opted-in default-profile page. Detaching releases
// its visibility override. Closing the target or the daemon also detaches it.
const renderSessions = new WeakMap();
const renderOperations = new WeakMap();

const IDLE_LIMIT = 30 * 60 * 1000;

function queueRendering(page, action) {
  const pending = renderOperations.get(page) || Promise.resolve();
  const operation = pending.catch(() => {}).then(action);
  renderOperations.set(page, operation);
  return operation.finally(() => {
    if (renderOperations.get(page) === operation)
      renderOperations.delete(page);
  });
}

function scheduleExpiry(entry) {
  clearTimeout(entry.timer);
  entry.timer = setTimeout(entry.expire, IDLE_LIMIT);
  entry.timer.unref();
}

function touchRendering(page, tab) {
  const entry = renderSessions.get(page);
  if (!entry) return;
  if (tab) entry.tab = tab;
  entry.lastUse = Date.now();
  scheduleExpiry(entry);
}

function recheckCap(page, tab) {
  if (!tab?.context) return;
  const pending = renderOperations.get(page);
  if (pending) {
    const retry = () => recheckCap(page, tab);
    pending.then(retry, retry);
  } else if (!renderSessions.has(page) && !page.isClosed() && tab.context.tabs().includes(tab)) {
    tab.context._scheduleTabCap();
  }
}

function forgetSession(page, entry) {
  clearTimeout(entry.timer);
  if (renderSessions.get(page) !== entry) return;
  renderSessions.delete(page);
  recheckCap(page, entry.tab);
}

async function release(page, entry) {
  await entry.session.detach();
  forgetSession(page, entry);
}

function watchSession(page, session, tab) {
  const entry = { session, tab, lastUse: Date.now() };
  entry.expire = () => {
    // The last command may have failed before the model could send "off".
    // Long-running commands keep their lease until they release this tab.
    queueRendering(page, async () => {
      if (renderSessions.get(page) !== entry) return;
      if (entry.tab?.workbenchInUse || Date.now() - entry.lastUse < IDLE_LIMIT) {
        scheduleExpiry(entry);
        return;
      }
      await release(page, entry);
    }).catch(() => {
      if (renderSessions.get(page) === entry) scheduleExpiry(entry);
    });
  };
  scheduleExpiry(entry);
  renderSessions.set(page, entry);
  session.once('close', () => forgetSession(page, entry));
}

async function setRendering(page, mode, tab) {
  if (mode !== 'on' && mode !== 'off')
    throw new Error('Expected tab-render on or tab-render off.');
  const impl = chromiumContext(page.context());
  if (!impl._browser.options.noDefaults || impl._browser._defaultContext !== impl)
    return { requested: mode, rendering: 'on', managedBy: 'playwright', released: false };
  return queueRendering(page, async () => {
    const existing = renderSessions.get(page);
    if (mode === 'on' && !existing) {
      const session = await page.context().newCDPSession(page);
      try {
        await session.send('Emulation.setFocusEmulationEnabled', { enabled: true });
        watchSession(page, session, tab);
      } catch (error) {
        await session.detach().catch(() => {});
        throw error;
      }
    } else if (mode === 'on') {
      touchRendering(page, tab);
    } else if (existing) {
      await release(page, existing);
    }
    return { requested: mode, rendering: mode, managedBy: 'workbench', released: mode === 'off' && !!existing };
  });
}

function isRendering(page) {
  return renderSessions.has(page) || renderOperations.has(page);
}

module.exports = { createWindow, isRendering, setRendering, touchRendering };
