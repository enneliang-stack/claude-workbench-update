param(
  [Parameter(Mandatory = $true)][string]$InstallDir,
  [Parameter(Mandatory = $true)][string]$Icon,
  [string]$IconKey = ''
)

# Refresh desktop / Start Menu / taskbar shortcuts after the app icon changes.
# Windows caches shortcut icons; pointing them at a content-keyed icon file
# forces Explorer to load the new image without a full icon-cache rebuild.

$ErrorActionPreference = 'SilentlyContinue'
try {
  $install = [IO.Path]::GetFullPath($InstallDir).TrimEnd('\')
  $icon = [IO.Path]::GetFullPath($Icon)
  if (-not (Test-Path -LiteralPath $icon)) { exit 0 }
  if (-not $IconKey) { $IconKey = (Get-Date -Format 'yyyyMMddHHmmss') }
  $safeKey = ($IconKey -replace '[^0-9A-Za-z._-]', '_')
  $versioned = Join-Path (Split-Path -Parent $icon) ('icon-' + $safeKey + '.ico')
  if ($versioned -ne $icon) {
    Copy-Item -LiteralPath $icon -Destination $versioned -Force
  }

  $dirs = @(
    [Environment]::GetFolderPath('Desktop'),
    [Environment]::GetFolderPath('CommonDesktopDirectory'),
    [Environment]::GetFolderPath('Programs'),
    [Environment]::GetFolderPath('CommonPrograms'),
    (Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar')
  ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }

  $ws = New-Object -ComObject WScript.Shell
  $changed = 0
  foreach ($d in $dirs) {
    $links = Get-ChildItem -LiteralPath $d -Filter *.lnk -File -Recurse -ErrorAction SilentlyContinue
    foreach ($lnk in @($links)) {
      if (-not $lnk) { continue }
      $s = $ws.CreateShortcut($lnk.FullName)
      $target = [string]$s.TargetPath
      $oldIcon = [string]$s.IconLocation
      $underInstall = ($target -and $target.StartsWith($install, [StringComparison]::OrdinalIgnoreCase)) -or
                      ($oldIcon -and $oldIcon.StartsWith($install, [StringComparison]::OrdinalIgnoreCase))
      if (-not $underInstall) { continue }
      $newIcon = $versioned + ',0'
      if ($oldIcon -ne $newIcon) {
        $s.IconLocation = $newIcon
        $s.Save()
        $changed++
      }
    }
  }

  try {
    Add-Type -Namespace ClaudeWorkbench -Name ShellNotify -MemberDefinition '[DllImport("shell32.dll")] public static extern void SHChangeNotify(int eventId, uint flags, System.IntPtr item1, System.IntPtr item2);'
    [ClaudeWorkbench.ShellNotify]::SHChangeNotify(0x08000000, 0x0000, [System.IntPtr]::Zero, [System.IntPtr]::Zero)
  } catch { }

  Write-Output ("shortcut icons updated: " + $changed)
  exit 0
} catch {
  exit 1
}
