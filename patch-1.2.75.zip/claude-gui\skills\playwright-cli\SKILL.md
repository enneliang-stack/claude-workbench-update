---
name: playwright-cli
description: Use the workbench Chrome browser to inspect rendered pages and media, operate logged-in sites, take screenshots, and test web interactions.
allowed-tools: Bash(playwright-cli:*) Bash(npx playwright:*) Bash(npx --no-install playwright:*)
---

# 工作台浏览器

需要查看页面实际呈现、点击、输入、截图或复用登录态时使用此技能。简单的文本提取或批量请求可直接使用 HTTP 工具。

## 在后台操作

在工作台的 Bash 中启动或复用专用 Chrome。登录态保存在这份配置里。`msedge` 是 CLI 连接名。冷启动时窗口和标签会重新创建。若启动器环境变量为空，可请用户点工作台顶栏的浏览器按钮建立连接。

```bash
node "$WORKBENCH_CHROME_BROWSER" --background
playwright-cli -s=msedge tab-new https://example.com
playwright-cli -s=msedge snapshot
playwright-cli -s=msedge click e5
```

每个工作台对话各自绑定目标页。后续 `goto`、`eval`、`screenshot`、`run-code` 都作用于当前对话选中的页。例子里的 `e5` 应替换为最近一次 snapshot 给出的元素引用。需要其他命令或参数时运行 `playwright-cli --help` 或 `playwright-cli --help <命令>`。

- **接着操作已有页面**　用户预先打开的网站可以直接用。`tab-list` 找到目标，`tab-use <pageId>` 在后台选中，即可沿用已有的登录态和表单内容。已绑定其他对话的页由原对话继续操作；目标关闭后重新选择。
- **标签清理**　超过 15 页才开始按最近使用顺序回收，手动页和 AI 页都参与。用户最近 60 秒点击、滚动或按键且仍在前台查看的页会保留。正在执行命令或由工作台保持渲染的页可暂时超额，操作结束后再清理。
- **链接与弹窗**　普通文章或详情链接用 `tab-new <url>` 后台打开。可用 `eval "el => el.closest('a').href" <元素引用>` 获取完整地址。工作台的普通 `click` 遇到声明为新标签的网页链接会先给出提示。授权、下载或依赖来源页、opener、单击脚本的流程应保留网站原有行为。需要单独窗口时用一次 `tab-new --window <url>`，之后复用该页。`click <元素引用> left` 执行原生单击；弹出页可用 `tab-list` 找到并用 `tab-use <pageId>` 接着操作。网站原生弹窗仍可能激活 Chrome。
- **动画和 WebGL**　画面停滞时检查资源进度，并在实际渲染的 frame 中观察帧数。确有停帧时在目标页执行 `tab-render on`，完成或移交时执行 `tab-render off`。工作台开启的模拟空闲 30 分钟后自动释放，长命令执行期间会续期。若返回 `managedBy: "playwright"`，该页的模拟随 Playwright 页面或上下文结束；`rendering: "on"` 表示它仍在运行。
- **自定义脚本**　`run-code` 使用传入的 `page`。后台脚本保留用户当前窗口和键盘焦点，避免调用 `bringToFront()`、`window.focus()`、全屏或 CDP 激活目标。需要切换操作目标时使用 `tab-use`。

## 展示和接管

用户要求查看页面时展示该页。遇到扫码、验证码、双重验证、支付或系统权限等需要用户操作的步骤，提醒用户并说明要完成哪一步。收到完成消息后，回到对应页面用 snapshot 核对。

- 用户要查看指定页面时，运行 `node "$WORKBENCH_CHROME_BROWSER" --focus --page=<pageId>`。需要用户接管时使用 `--alert --page=<pageId>`，将占位符替换成 `tab-list` 中的实际 ID。`tab-show <pageId>` 用于显式展示，工作台顶栏浏览器按钮供用户主动查看。
- 对话中供模型继续操作的切页使用 `tab-use`。`tab-select` 是兼容旧命令的展示操作。

## 按需参考

以下为上游命令示例。工作台内的启动、连接名和标签操作以上述约定为准，保留共享浏览器供其他任务使用。

完整命令速查随工具包安装，包含键鼠、网络、存储、Windows shell 引号、独立 CLI 安装与示例。从 `WORKBENCH_CHROME_BROWSER` 启动脚本所在目录读取 `tools/playwright-cli/skills/playwright-cli/SKILL.md` 即可。含 `&` 的网址作为一个带引号的参数传入。工作台运行时优先使用随包的 CLI。

- [自定义 Playwright 代码](references/running-code.md) · [查元素属性](references/element-attributes.md)
- [请求模拟](references/request-mocking.md) · [存储状态](references/storage-state.md) · [浏览器会话](references/session-management.md)
- [运行测试](references/playwright-tests.md) · [生成测试](references/test-generation.md)
- [追踪](references/tracing.md) · [录屏](references/video-recording.md) · [在 PR 中附图](references/pr-attachments.md)
