'use strict';

const { promisify } = require('node:util');
const execFile = promisify(require('node:child_process').execFile);
const { isRendering } = require('./workbench-render');
const recentInputMs = 60000;

async function readForeground(page) {
  if (process.platform !== 'win32') return null;
  const impl = page.context()._connection.toImpl(page.context());
  const browser = impl._browser;
  const observation = await page.evaluate(() => ({
    focused: document.hasFocus(), visible: !document.hidden, title: document.title
  }));
  if (!observation.focused || !observation.visible) return false;
  const { processInfo } = await browser._session.send('SystemInfo.getProcessInfo');
  const pid = processInfo.find(info => info.type === 'browser')?.id;
  if (!pid) return null;
  const script = require('node:path').join(__dirname, 'workbench-window.ps1');
  const { stdout } = await execFile('powershell.exe', ['-NoProfile', '-NonInteractive',
    '-ExecutionPolicy', 'Bypass', '-File', script, '-BrowserPid', String(pid), '-ForegroundOnly'],
  { windowsHide: true, timeout: 3500 });
  const native = JSON.parse(stdout.trim());
  if (!native.foreground) return false;
  // Chrome updates its native title asynchronously and Win32 can truncate it.
  if (observation.title && native.title && !native.title.includes(observation.title)) return null;
  if (!browser.options.noDefaults || browser._defaultContext !== impl) return null;
  return true;
}

async function trimTabs(tabs, limit, foreground = readForeground, rendering = isRendering) {
  if (tabs.length <= limit) return;
  const busy = tab => tab.workbenchInUse > 0 || rendering(tab.page);
  const recent = tab => Date.now() - tab.workbenchUserInput < recentInputMs;
  const candidates = [...tabs].sort((a, b) => a._lastUsed - b._lastUsed);
  async function close(tab, lastUsed) {
    if (tabs.length <= limit || tab._lastUsed !== lastUsed || busy(tab) || tab.page.isClosed()) return;
    tab.workbenchClosing = true;
    try { await tab.page.close(); }
    catch { /* A failed close can be retried on the next cleanup. */ }
    finally { tab.workbenchClosing = false; }
  }
  for (const tab of candidates) {
    if (tabs.length <= limit) break;
    if (tab.page.isClosed() || tab.workbenchClosing || busy(tab)) continue;
    const lastUsed = tab._lastUsed;
    if (recent(tab)) {
      let timeout;
      let focused;
      try {
        focused = await Promise.race([foreground(tab.page),
          new Promise(resolve => { timeout = setTimeout(() => resolve(null), 4000); })]);
      } catch { focused = null; }
      finally { clearTimeout(timeout); }
      if (recent(tab) && focused !== false) continue;
    }
    await close(tab, lastUsed);
  }
}

module.exports = { trimTabs, readForeground, recentInputMs };
