'use strict';

/**
 * Claude 工作台 —— 真实 Chrome 启动/聚焦
 *
 * 1. 使用专用 profile 启动本机真实 Chrome（保持登录态）；
 * 2. 开启 CDP 9222；
 * 3. 以 msedge 会话名 attach，后续 playwright-cli 命令照旧可用。
 *
 * 默认后台：AI 网页任务不抢焦点、不盖住用户当前应用，遮挡状态下也能操作和截图。
 * --focus：置前（顶栏浏览器按钮、用户要求打开给他看）。
 * --alert：置前 + 任务栏闪烁 + 提示音（登录/验证码/权限确认等需要用户介入）。
 *
 * 幂等：Chrome 已在跑、会话已 attach 时直接返回。
 * 输出最后一行 JSON，供工作台主服务解析。
 */

const fs = require('fs');
const path = require('path');
const { spawn, spawnSync } = require('child_process');

const PORT = Number(process.env.CHROME_DEBUG_PORT || 9222);
const SESSION = process.env.WORKBENCH_CHROME_SESSION || 'msedge';
const PROFILE = path.resolve(process.env.CHROME_PROFILE_DIR ||
  path.join(process.env.LOCALAPPDATA || '', 'ClaudeWorkbenchChrome'));
const CLI_CWD = path.join(__dirname, '..');
const CHROME_CONFIG = path.join(__dirname, 'data', 'chrome-path.json');

// 兼容：旧版顶栏按钮调用本脚本时不带参数，仍应置前；AI 会话由工作台注入
// WORKBENCH_CHROME_BROWSER 环境变量，无参数时仍走后台。
const ARGV = process.argv.slice(2).map(arg => String(arg).toLowerCase());
const ALERT = ARGV.includes('--alert');
const TOOLBAR = ARGV.includes('--toolbar');
const PAGE_ID = process.argv.slice(2).find(arg => arg.startsWith('--page='))?.slice(7);
const EXPLICIT_BACKGROUND = ARGV.includes('--background');
const EXPLICIT_FOCUS = ALERT || ARGV.includes('--focus') || ARGV.includes('--foreground');
const FOCUS = EXPLICIT_FOCUS ||
  (!EXPLICIT_BACKGROUND && ARGV.length === 0 && !process.env.WORKBENCH_CHROME_BROWSER);

// 后台窗口被遮挡时别让 Chrome 降低定时器/rAF 频率，否则个别站点会变慢或截到空白。
const LAUNCH_FLAGS = [
  '--disable-backgrounding-occluded-windows',
  '--disable-renderer-backgrounding',
  '--disable-background-timer-throttling',
  '--disable-features=CalculateNativeWinOcclusion'
];

function readChromeConfig() {
  try {
    const data = JSON.parse(fs.readFileSync(CHROME_CONFIG, 'utf8'));
    if (!data || typeof data !== 'object') return null;
    const pathValue = typeof data.path === 'string' ? data.path.trim() : '';
    const dirValue = typeof data.dir === 'string' ? data.dir.trim() : '';
    return pathValue || dirValue ? { path: pathValue, dir: dirValue } : null;
  } catch {
    return null;
  }
}

// 用户可能选择 chrome.exe，也可能选择 Application / Google\Chrome / 便携版目录。
function resolveChromeExe(input) {
  if (!input) return '';
  const candidates = [input];
  try {
    if (fs.statSync(input).isDirectory()) {
      candidates.push(
        path.join(input, 'chrome.exe'),
        path.join(input, 'Application', 'chrome.exe'),
        path.join(input, 'chrome-win64', 'chrome.exe'),
        path.join(input, 'chrome-win32', 'chrome.exe')
      );
    }
  } catch { /* 不存在时只按文件路径判断 */ }
  return candidates.find(file => {
    try { return fs.statSync(file).isFile(); } catch { return false; }
  }) || '';
}

function findChrome() {
  const config = readChromeConfig();
  const configured = config ? resolveChromeExe(config.path || config.dir) : '';
  if (configured) return configured;

  const chromeRoots = [
    process.env.LOCALAPPDATA || '',
    process.env.PROGRAMFILES || '',
    process.env['PROGRAMFILES(X86)'] || ''
  ].filter(Boolean);
  const chromeChannels = ['Chrome', 'Chrome Beta', 'Chrome Dev', 'Chrome SxS'];
  const candidates = [
    process.env.CHROME_PATH,
    ...chromeRoots.flatMap(root => chromeChannels.map(channel =>
      path.join(root, 'Google', channel, 'Application', 'chrome.exe')))
  ].filter(Boolean);
  return candidates.map(resolveChromeExe).find(Boolean) || '';
}

function runCli(args, timeout = 60000, extraEnv = {}) {
  const executable = path.join(__dirname, 'tools', 'playwright-cli', 'playwright-cli.js');
  const result = spawnSync(process.execPath, [executable, ...args], {
    cwd: CLI_CWD, windowsHide: true, encoding: 'utf8', timeout,
    env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', WORKBENCH_CHROME_BROWSER: __filename, NO_UPDATE_NOTIFIER: '1', ...extraEnv }
  });
  return { code: result.status ?? -1, out: result.stdout || '', err: result.stderr || result.error?.message || '' };
}

function parseJsonObject(text) {
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('无法解析 playwright-cli 输出');
  return JSON.parse(text.slice(start, end + 1));
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function getJson(url, timeout = 1500) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok) return null;
    return await response.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function chromeVersion() {
  const version = await getJson(`http://127.0.0.1:${PORT}/json/version`);
  if (!version) return null;
  if (!/Chrome\//i.test(version.Browser || ''))
    throw new Error(`端口 ${PORT} 的服务不是工作台需要的 Chrome：${version.Browser || '未知'}`);
  return version;
}

function ensureSession(version) {
  const endpoint = version.webSocketDebuggerUrl;
  if (!endpoint) throw new Error('浏览器没有提供 CDP 实例地址。');
  const result = runCli(['attach', '--session=' + SESSION, '--cdp=' + endpoint], 30000, {
    WORKBENCH_ENSURE_SESSION: '1', WORKBENCH_BROWSER_TASK: ''
  });
  if (result.code !== 0) throw new Error((result.err || result.out).trim() || '无法确认工作台浏览器连接。');
  const status = parseJsonObject(result.out);
  if (typeof status.reused !== 'boolean') throw new Error('工作台浏览器握手返回了无效状态。');
  return status;
}

async function waitForChrome(timeout = 30000) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    const version = await chromeVersion();
    if (version) return version;
    await sleep(300);
  }
  return null;
}

function clearChromeSessionState() {
  // 冷启动前清掉“恢复上次会话”的数据：每次从新标签页开始，不恢复旧窗口/标签。
  // 只动 session 相关文件，Cookies、登录态、历史、书签都不受影响。
  try {
    const defaultDir = path.join(PROFILE, 'Default');
    for (const name of ['Current Session', 'Current Tabs', 'Last Session', 'Last Tabs']) {
      try { fs.rmSync(path.join(defaultDir, name), { force: true }); } catch { /* ignore */ }
    }
    for (const name of ['Sessions', 'Sessions_Encrypted']) {
      try { fs.rmSync(path.join(defaultDir, name), { recursive: true, force: true }); } catch { /* ignore */ }
    }
    const prefsPath = path.join(defaultDir, 'Preferences');
    if (!fs.existsSync(prefsPath)) return;
    const prefs = JSON.parse(fs.readFileSync(prefsPath, 'utf8'));
    prefs.session = prefs.session || {};
    prefs.session.restore_on_startup = 5; // 5 = 打开新标签页
    prefs.session.startup_urls = [];
    prefs.profile = prefs.profile || {};
    prefs.profile.exit_type = 'Normal';
    prefs.profile.exited_cleanly = true;
    fs.writeFileSync(prefsPath, JSON.stringify(prefs));
  } catch { /* 清理失败不阻塞启动 */ }
}

// Start Chrome without asking Windows to display a window. Creating the first
// target via CDP lets Chrome itself show the normal window without activation.
async function ensureBackgroundWindow(version) {
  const { chromium } = require('./tools/playwright-cli/node_modules/playwright');
  const { createWindow } = require('./tools/playwright-cli/workbench-render');
  const browser = await chromium.connectOverCDP(version.webSocketDebuggerUrl, { noDefaults: true, timeout: 10000 });
  try {
    const context = browser.contexts()[0];
    if (!context.pages().length)
      await createWindow(context);
  } finally {
    // This temporary connectOverCDP client disconnects the transport on close.
    await browser.close();
  }
}

async function showBrowser() {
  const args = ['-s=' + SESSION, '--raw', 'tab-show', ...(PAGE_ID ? [PAGE_ID] : []), '--native'];
  if (TOOLBAR || (!PAGE_ID && !process.env.WORKBENCH_BROWSER_TASK)) args.push('--toolbar');
  if (ALERT) args.push('--alert');
  const result = runCli(args, 20000);
  if (result.code !== 0) throw new Error((result.err || result.out).trim() || '无法展示浏览器窗口。');
  const info = parseJsonObject(result.out);
  if (!info.focused) throw new Error('已请求显示，但未验证工作台浏览器窗口在前台。');
  return info;
}

async function main() {
  if (PAGE_ID !== undefined && (!FOCUS || !/^page@[a-zA-Z0-9_-]+$/.test(PAGE_ID))) throw new Error('指定页面需使用 --focus 或 --alert 和 tab-list 给出的页面 ID。');
  if (!fs.existsSync(PROFILE)) {
    try { fs.mkdirSync(PROFILE, { recursive: true }); } catch { /* ignore */ }
  }

  let launched = false;
  let launchMode = 'reused';
  let version = await chromeVersion();

  if (!version && (PAGE_ID || (process.env.WORKBENCH_BROWSER_TASK && FOCUS && !TOOLBAR))) throw new Error('原浏览器及其目标页面已关闭。');
  if (!version) {
    const chromePath = findChrome();
    if (!chromePath) {
      const error = new Error('没有找到本机 Chrome（chrome.exe）');
      error.code = 'CHROME_NOT_FOUND';
      throw error;
    }

    if (FOCUS) clearChromeSessionState();
    const args = [
      `--remote-debugging-port=${PORT}`,
      `--user-data-dir=${PROFILE}`,
      '--no-first-run', '--no-default-browser-check', '--remote-allow-origins=*',
      '--hide-crash-restore-bubble', ...LAUNCH_FLAGS
    ];
    if (!FOCUS) args.push('--no-startup-window');
    const child = spawn(chromePath, args, { detached: true, stdio: 'ignore', windowsHide: !FOCUS });
    await new Promise((resolve, reject) => {
      child.once('spawn', resolve);
      child.once('error', reject);
    });
    child.unref();
    launched = true;
    launchMode = FOCUS ? 'spawn' : 'no-startup-window';

    version = await waitForChrome(30000);
    if (!version) {
      throw new Error(`真实 Chrome 已启动，但 CDP ${PORT} 端口未就绪；请检查是否有其他 Chrome 占用了专用 profile`);
    }
  }

  // A previous cold start can leave a live CDP endpoint with no page if the
  // caller disconnected mid-startup. Recover before attaching in that case.
  if (!FOCUS) {
    const targets = await getJson(`http://127.0.0.1:${PORT}/json/list`);
    if (!Array.isArray(targets) || !targets.some(target => target.type === 'page'))
      await ensureBackgroundWindow(version);
  }

  const { reused } = ensureSession(version);
  const display = FOCUS ? await showBrowser() : { focused: false };
  return { ok: true, session: SESSION, port: PORT, launched, reused,
    launchMode, browser: version.Browser, ...display };
}

// Independent CLI invocations can cold-start together. A named pipe serializes
// the check, first window and daemon attach; Windows releases it on process exit.
async function startOnce() {
  if (process.platform !== 'win32') return main();
  const { createServer } = require('node:net');
  const { once } = require('node:events');
  const pipe = String.raw`\\.\pipe\claude-workbench-chrome-start-${PORT}`;
  const deadline = Date.now() + 60000;
  while (true) {
    const lock = createServer(socket => socket.destroy());
    try {
      await once(lock.listen(pipe), 'listening');
    } catch (error) {
      if (error.code !== 'EADDRINUSE' || Date.now() >= deadline) throw error;
      await sleep(150);
      continue;
    }
    try { return await main(); }
    finally { lock.close(); }
  }
}

startOnce()
  .then(result => {
    process.stdout.write(JSON.stringify(result) + '\n');
    process.exit(0);
  })
  .catch(error => {
    const message = String(error && error.message ? error.message : error);
    process.stderr.write((error && error.code ? error.code + ': ' : '') + message + '\n');
    process.exit(1);
  });
