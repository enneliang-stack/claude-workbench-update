'use strict';

const { AsyncLocalStorage } = require('node:async_hooks');
const requests = new AsyncLocalStorage();

// A CLI daemon serves multiple chats. Each request captures its own target,
// including the response/snapshot rendered after the tool has completed.
async function run(task, tool, action) {
  const sendsInput = /^(browser_(click|drag|type|press_key|fill_form|select_option|hover|mouse|keyboard|run_code|navigate|tabs))/.test(tool);
  const request = { task, tool, sendsInput, tab: null, used: new Set() };
  try { return await requests.run(request, action); }
  finally {
    for (const tab of request.used) {
      tab.workbenchInUse--;
      if (request.sendsInput) {
        tab.workbenchInputRequests--;
        tab.workbenchLastAction = Date.now();
      }
      tab.context._scheduleTabCap();
    }
  }
}

function pin(request, tab) {
  if (request.used.has(tab)) return;
  request.used.add(tab);
  tab.workbenchInUse = (tab.workbenchInUse || 0) + 1;
  if (request.sendsInput) tab.workbenchInputRequests = (tab.workbenchInputRequests || 0) + 1;
  require('./workbench-render').touchRendering(tab.page, tab);
}

async function showNativeWindow(browserPid, marker = '', alert = false) {
  const script = require('node:path').join(__dirname, 'workbench-window.ps1');
  const exec = require('node:util').promisify(require('node:child_process').execFile);
  const { stdout } = await exec('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
    '-File', script, '-BrowserPid', String(browserPid), ...(marker ? ['-Marker', marker] : []),
    '-AlertUser', alert ? '1' : '0'], { windowsHide: true, timeout: 8000 });
  const hwnd = Number(stdout.trim());
  return { hwnd: hwnd || null, focused: hwnd > 0 };
}

const pendingDisplays = new WeakMap();

function queueDisplay(context, action) {
  const browser = context._connection.toImpl(context)._browser;
  const previous = pendingDisplays.get(browser) || Promise.resolve();
  const next = previous.catch(() => {}).then(() => action(browser));
  pendingDisplays.set(browser, next);
  return next.finally(() => {
    if (pendingDisplays.get(browser) === next) pendingDisplays.delete(browser);
  });
}

function showTarget(page, native, alert) {
  return queueDisplay(page.context(), async browser => {
    await page.bringToFront();
    return inspectTarget(page, browser, native, alert);
  });
}

async function nativeBrowserPid(browser) {
  if (process.platform !== 'win32') return null;
  const version = await browser._session.send('Browser.getVersion');
  if (/HeadlessChrome\//.test(version.userAgent)) return null;
  const { processInfo } = await browser._session.send('SystemInfo.getProcessInfo');
  const pid = processInfo.find(p => p.type === 'browser')?.id;
  if (!pid) throw new Error('无法识别目标 Chrome 进程。');
  return pid;
}

function showGenericWindow(context, alert) {
  return queueDisplay(context, async browser => {
    const pid = await nativeBrowserPid(browser);
    if (!pid) return { focused: null, verification: 'unavailable' };
    return showNativeWindow(pid, '', alert);
  });
}

async function inspectTarget(page, browser, native, alert) {
  const cdp = await page.context().newCDPSession(page);
  try {
    const [{ targetInfo }, { windowId }] = await Promise.all([
      cdp.send('Target.getTargetInfo'), cdp.send('Browser.getWindowForTarget')
    ]);
    const info = { pageId: page._guid, targetId: targetInfo.targetId, windowId, activationRequested: true };
    if (!native) return info;
    const pid = await nativeBrowserPid(browser);
    if (!pid) return { ...info, focused: null, verification: 'unavailable' };
    // Identical page titles are common across tabs and windows. Windows only
    // shows the selected tab title on its top-level HWND.
    const marker = 'WB-' + require('node:crypto').randomUUID();
    const previous = await page.evaluate(tag => {
      const previous = { title: document.title, hadTitle: !!document.querySelector('title') };
      document.title = tag + ' ' + previous.title;
      return previous;
    }, marker);
    try { return { ...info, ...await showNativeWindow(pid, marker, alert) }; }
    finally {
      await page.evaluate(({ marker, previous }) => {
        if (document.title !== marker + ' ' + previous.title) return;
        if (previous.hadTitle) document.title = previous.title;
        else document.querySelector('title')?.remove();
      }, { marker, previous }).catch(() => {});
    }
  } finally { await cdp.detach().catch(() => {}); }
}

function checkActivation(method) {
  if (requests.getStore()?.tool === 'browser_run_code_unsafe' &&
      (method === 'Page.bringToFront' || method === 'Target.activateTarget')) {
    throw new Error('后台 run-code 无法激活浏览器。需要向用户展示时，请使用 tab-show。');
  }
}

class TaskPages {
  constructor() {
    this.selected = new Map();
    this.pending = new Map();
  }

  request() {
    return requests.getStore();
  }

  current() {
    const request = this.request();
    const tab = request?.tab || this.selected.get(request?.task);
    return tab && !tab.page.isClosed() ? tab : null;
  }

  bind(tab) {
    const request = this.request();
    if (!request?.task) return;
    if (tab.workbenchOwner && tab.workbenchOwner !== request.task)
      throw new Error('该标签属于其他对话。请为当前对话创建标签。');
    if (tab.page.isClosed() || tab.crashed || tab.workbenchClosing)
      throw new Error('该标签已关闭或失效。请用 tab-list、tab-use 或 tab-new 选择目标。');
    tab.workbenchOwner = request.task;
    pin(request, tab);
    request.tab = tab;
    this.selected.set(request.task, tab);
  }

  async ensure(create) {
    const request = this.request();
    let tab = this.current();
    if (!tab) {
      if (this.selected.has(request.task))
        throw new Error('当前对话的标签已关闭。请用 tab-use 或 tab-new 选择目标。');
      let pending = this.pending.get(request.task);
      if (!pending) {
        pending = create();
        this.pending.set(request.task, pending);
      }
      try { tab = await pending; }
      finally { if (this.pending.get(request.task) === pending) this.pending.delete(request.task); }
    }
    if (tab.crashed || tab.page.isClosed() || tab.workbenchClosing)
      throw new Error('目标标签已关闭或崩溃。请用 tab-use 或 tab-new 选择目标。');
    request.tab = tab;
    tab._lastUsed = Date.now();
    pin(request, tab);
    await tab.waitForInitialized();
    return tab;
  }

  closed(tab) {
    if (tab.workbenchOwner && this.selected.get(tab.workbenchOwner) === tab)
      this.selected.set(tab.workbenchOwner, null);
  }
}

module.exports = { TaskPages, run, checkActivation, showTarget, showGenericWindow };
