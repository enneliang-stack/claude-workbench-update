@echo off
chcp 65001 >nul
cd /d "%~dp0"

set "PS=powershell.exe"
where pwsh.exe >nul 2>nul && set "PS=pwsh.exe"

echo.
echo   Claude Workbench - update client
echo   =================================
echo   1. Update the client to 1.2.0
if exist "%~dp0tools\setup-env.ps1" if exist "%~dp0env" (
  echo   2. Set context compaction and install/check Python, PowerShell 7, jq
  echo.
  echo   A UAC prompt will appear for PowerShell 7. Click Yes.
  echo   This may take 5-10 minutes. Do not close this window.
)
if exist "%~dp0tools\setup-chrome.ps1" (
  echo   3. Check/install Chrome and choose the Chrome install directory
  echo   Chrome is used by the browser button and playwright-cli.
)
echo   Do NOT run this package as administrator; double-click is enough.
echo.

"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\check-update.ps1" -Manifest "%~dp0latest.json" -Yes -NoGui
if errorlevel 1 (
  echo.
  echo Client update failed. Send the text above to the person who shared this package.
  echo.
  pause
  exit /b 1
)

if exist "%~dp0tools\setup-env.ps1" if exist "%~dp0env" (
  "%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\setup-env.ps1" -EnvDir "%~dp0env"
  if errorlevel 1 (
    echo.
    echo Environment setup did not finish. Send the text above and the log to the person who shared this package.
    echo.
    pause
    exit /b 1
  )
)

if exist "%~dp0tools\setup-chrome.ps1" (
  "%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\setup-chrome.ps1"
  if errorlevel 1 (
    echo.
    echo Chrome is not configured. The client is updated; install Chrome or pick its folder from the browser button later.
  )
)

exit /b 0
