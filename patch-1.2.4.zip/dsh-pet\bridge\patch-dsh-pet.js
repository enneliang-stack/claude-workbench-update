#!/usr/bin/env node
'use strict';

/**
 * dsh-pet 工作台集成补丁：
 *  1. 桌面 helper 不创建系统托盘图标（由 claude-gui 顶栏控制）；
 *  2. 右键菜单「查看余额」改走工作台 sidecar，避免 standalone 没有 balance provider 时提示不可用；
 *  3. 鼠标离开窗口时立刻收起悬浮名，避免提示赖在屏幕上；
 *  4. 置顶看门狗默认开启，桌宠持续压在所有窗口之上。
 *
 * 兼容 0.3.x（单文件 helper）与 0.4.x（helper 拆成 main/、sprite/ 子目录）。
 * 升级 dsh-pet（npm install dsh-pet@...）后重新运行本脚本即可。补丁文件会保留 .bak-dsh-pet-integration 备份。
 */

const fs = require('fs');
const path = require('path');

const pkg = path.join(__dirname, '..', 'node_modules', 'dsh-pet');
const helperDir = path.join(pkg, 'runtime', 'electron-helper');

function pick(...files) {
  return files.find((file) => fs.existsSync(file));
}

// 0.4.x：托盘在 main/tray.js，桥接路由在 main/bridge.js，余额菜单在 sprite/menu.js
// 0.3.x：都在 main.js / sprite.js 里
const helper = path.join(helperDir, 'main.js');
const trayFile = pick(path.join(helperDir, 'main', 'tray.js'), helper);
const bridgeFile = pick(path.join(helperDir, 'main', 'bridge.js'), helper);
const windowsFile = pick(path.join(helperDir, 'main', 'windows.js'), helper);
const constants = path.join(helperDir, 'constants.js');
const sharedCore = path.join(helperDir, 'shared-core.js');
const topmostWatchdog = path.join(helperDir, 'topmost-watchdog.js');
const sprite = pick(path.join(helperDir, 'sprite', 'menu.js'), path.join(helperDir, 'sprite.js'));
const rendererFile = pick(path.join(helperDir, 'sprite', 'init.js'), path.join(helperDir, 'sprite.js'));

function read(file) {
  try { return fs.readFileSync(file, 'utf8'); }
  catch (e) { throw new Error('找不到 dsh-pet 文件：' + file); }
}

function backup(file) {
  const bak = file + '.bak-dsh-pet-integration';
  try {
    if (!fs.existsSync(bak)) fs.copyFileSync(file, bak);
  } catch { /* ignore */ }
}

function writeIfChanged(file, source, changed) {
  if (!changed) return false;
  backup(file);
  fs.writeFileSync(file, source, 'utf8');
  return true;
}

const report = {
  version: require(path.join(pkg, 'package.json')).version,
  ok: true,
  tray: {},
  bridge: {},
  constants: {},
  sprite: {},
  topmost: {},
  topmostLevel: {},
  tooltip: {},
  tooltipInstant: {},
  pointerAway: {},
  pointerZone: {}
};

// 1) 关闭系统托盘
{
  let src = read(trayFile);
  if (!src.includes('DSH_PET_NO_TRAY')) {
    const re = /async function startTray\(\) \{\n(\s*)try \{/;
    if (!re.test(src)) {
      throw new Error('未找到 startTray 模板；dsh-pet 版本可能已变化，请手动检查：' + trayFile);
    }
    src = src.replace(re, [
      'async function startTray() {',
      '  // 本集成由 claude-gui 的桌宠按钮控制显示；不需要额外的系统托盘图标。',
      "  if (process.env.DSH_PET_NO_TRAY === '1') return;",
      '$1try {'
    ].join('\n'));
    report.tray.patched = writeIfChanged(trayFile, src, true);
  } else {
    report.tray.already = true;
  }
  report.tray.file = path.relative(pkg, trayFile);
}

// 2) 右键「查看余额」→ 工作台 sidecar
{
  let src = read(bridgeFile);
  if (!src.includes('DSH_PET_SIDECAR_BALANCE')) {
    const anchor = '  const url = new URL(request.url); // dsh-pet-bridge://dsh-pet/dsh-pet-7340/...';
    if (!src.includes(anchor)) {
      throw new Error('未找到 handleBridgeRequest 模板；dsh-pet 版本可能已变化，请手动检查：' + bridgeFile);
    }
    const route = [
      '  // DSH_PET_SIDECAR_BALANCE：右键菜单「查看余额」走工作台 sidecar 的余额接口。',
      '  // standalone 本身没有 balance provider，直接打 /dsh-pet-7340/balance 会提示不可用。',
      '  if (url.pathname === "/sidecar-balance") {',
      '    for (let port = 4780; port <= 4789; port += 1) {',
      '      const ctrl = new AbortController();',
      '      const timer = setTimeout(() => ctrl.abort(), 12000);',
      '      try {',
      '        const resp = await fetch("http://127.0.0.1:" + port + "/api/balance?refresh=1", { signal: ctrl.signal });',
      '        const text = await resp.text();',
      '        let data = null;',
      '        try { data = JSON.parse(text); } catch { /* ignore */ }',
      '        if (resp.ok && data && data.ok) {',
      '          return new Response(text, {',
      '            status: 200,',
      '            headers: { "content-type": "application/json", "access-control-allow-origin": "*" }',
      '          });',
      '        }',
      '      } catch { /* try next port */ }',
      '      finally { clearTimeout(timer); }',
      '    }',
      '    return new Response(JSON.stringify({ ok: false, error: "桌宠服务未连接，请先打开工作台桌宠" }), {',
      '      status: 502,',
      '      headers: { "content-type": "application/json", "access-control-allow-origin": "*" }',
      '    });',
      '  }'
    ].join('\n');
    src = src.replace(anchor, anchor + '\n\n' + route);
    report.bridge.patched = writeIfChanged(bridgeFile, src, true);
  } else {
    report.bridge.already = true;
  }
  report.bridge.file = path.relative(pkg, bridgeFile);
}

// 3) 余额菜单指向 sidecar 路由
{
  let src = read(constants);
  if (!src.includes('SIDECAR_BALANCE_URL')) {
    const needle = "const BALANCE_URL = BASE + '/balance'; // 余额刷新动作（POST，写 S；数据本身从 /state 读）";
    if (!src.includes(needle)) {
      throw new Error('未找到 BALANCE_URL 定义；dsh-pet 版本可能已变化，请手动检查：' + constants);
    }
    src = src.replace(
      needle,
      needle + "\nconst SIDECAR_BALANCE_URL = BRIDGE ? 'dsh-pet-bridge://dsh-pet/sidecar-balance' : BALANCE_URL;"
    );
    report.constants.patched = writeIfChanged(constants, src, true);
  } else {
    report.constants.already = true;
  }
}

{
  let src = read(sprite);
  if (!src.includes('SIDECAR_BALANCE_URL')) {
    const needle = 'S.postAction(BALANCE_URL)';
    if (!src.includes(needle)) {
      throw new Error('未找到 show-balance 菜单动作；dsh-pet 版本可能已变化，请手动检查：' + sprite);
    }
    src = src.replace(needle, 'S.postAction(SIDECAR_BALANCE_URL)');
    report.sprite.patched = writeIfChanged(sprite, src, true);
  } else {
    report.sprite.already = true;
  }
  report.sprite.file = path.relative(pkg, sprite);
}

// 4) 悬浮名：窗口变穿透/失焦时主动收起
{
  const input = pick(path.join(helperDir, 'sprite', 'input.js'), path.join(helperDir, 'sprite.js'));
  let src = read(input);
  if (!src.includes('DSH_PET_HIDE_TIP_ON_LEAVE')) {
    const needle = '  setInteractive(flag) {\n    const next = !!flag;\n    if (next === this._interactive) return;';
    if (!src.includes(needle)) {
      throw new Error('未找到 setInteractive 模板；dsh-pet 版本可能已变化，请手动检查：' + input);
    }
    src = src.replace(needle, [
      '  setInteractive(flag) {',
      '    const next = !!flag;',
      '    // DSH_PET_HIDE_TIP_ON_LEAVE：窗口变穿透/失焦时主动收起悬浮名，避免鼠标移走后提示赖在屏幕上。',
      '    if (!next && this.tipOn) this.setTip(false);',
      '    if (next === this._interactive) return;'
    ].join('\n'));
    report.tooltip.patched = writeIfChanged(input, src, true);
  } else {
    report.tooltip.already = true;
  }
  report.tooltip.file = path.relative(pkg, input);
}

// 5) 置顶看门狗默认开启
{
  const topmost = path.join(helperDir, 'topmost-watchdog.js');
  let src = read(topmost);
  if (!src.includes('const TOPMOST_WATCHDOG_ENABLED = true;')) {
    const needle = 'const TOPMOST_WATCHDOG_ENABLED = false;';
    if (!src.includes(needle)) {
      throw new Error('未找到 TOPMOST_WATCHDOG_ENABLED；dsh-pet 版本可能已变化，请手动检查：' + topmost);
    }
    src = src.replace(needle, 'const TOPMOST_WATCHDOG_ENABLED = true;');
    report.topmost.patched = writeIfChanged(topmost, src, true);
  } else {
    report.topmost.already = true;
  }
  report.topmost.file = path.relative(pkg, topmost);
}

// 6) 穿透兜底：主进程判定光标离开时，通知渲染端收起悬浮名
{
  let src = read(windowsFile);
  if (!src.includes('DSH_PET_POINTER_AWAY')) {
    const re = /(^|\n)([ \t]*)function setWindowIgnore\(win, ignore\) \{\n([ \t]*)win\.setIgnoreMouseEvents\(ignore, \{ forward: true \}\);\n([ \t]*)windowIgnore\.set\(win\.id, ignore\);\n([ \t]*)\}/;
    if (!re.test(src)) {
      throw new Error('未找到 setWindowIgnore 模板；dsh-pet 版本可能已变化，请手动检查：' + windowsFile);
    }
    src = src.replace(re, (m, lead, indent) => [
      lead + indent + 'function setWindowIgnore(win, ignore) {',
      indent + '  const prev = windowIgnore.get(win.id);',
      indent + '  win.setIgnoreMouseEvents(ignore, { forward: true });',
      indent + '  windowIgnore.set(win.id, ignore);',
      indent + '  // DSH_PET_POINTER_AWAY：窗口变穿透时让渲染端收起悬浮名（主进程兜底轮询也能触发）。',
      indent + "  if (ignore && prev !== true && !win.isDestroyed()) {",
      indent + "    win.webContents.executeJavaScript('window.__dshPetHideTip && window.__dshPetHideTip()').catch(() => {});",
      indent + '  }',
      indent + '}'
    ].join('\n'));
    report.pointerAway.windowsPatched = writeIfChanged(windowsFile, src, true);
  } else {
    report.pointerAway.windowsAlready = true;
  }
  report.pointerAway.windowsFile = path.relative(pkg, windowsFile);
}

{
  let src = read(rendererFile);
  if (!src.includes('DSH_PET_POINTER_AWAY')) {
    const re = /^([ \t]*)this\.tipOn = false;[ \t]*$/m;
    if (!re.test(src)) {
      throw new Error('未找到 tipOn 初始化；dsh-pet 版本可能已变化，请手动检查：' + rendererFile);
    }
    src = src.replace(re, (m, indent) => [
      indent + 'this.tipOn = false;',
      indent + '// DSH_PET_POINTER_AWAY：供主进程在光标离开窗口/穿透翻转时收起悬浮名。',
      indent + 'window.__dshPetHideTip = () => this.setTip(false);'
    ].join('\n'));
    report.pointerAway.rendererPatched = writeIfChanged(rendererFile, src, true);
  } else {
    report.pointerAway.rendererAlready = true;
  }
  report.pointerAway.rendererFile = path.relative(pkg, rendererFile);
}

// 7) 悬浮名不要淡出：移开即消失
{
  let src = read(sharedCore);
  if (!src.includes('DSH_PET_TOOLTIP_INSTANT')) {
    const needle = 'opacity:0;transition:opacity .12s ease;pointer-events:none;z-index:2}';
    if (!src.includes(needle)) {
      throw new Error('未找到 pet-tooltip 样式；dsh-pet 版本可能已变化，请手动检查：' + sharedCore);
    }
    src = src.replace(needle, 'opacity:0;transition:none;pointer-events:none;z-index:2} /* DSH_PET_TOOLTIP_INSTANT */');
    report.tooltipInstant.cssPatched = writeIfChanged(sharedCore, src, true);
  } else {
    report.tooltipInstant.cssAlready = true;
  }
  report.tooltipInstant.cssFile = path.relative(pkg, sharedCore);
}

// 9) 置顶级别降到常规 floating，避免压过截图/录屏工具
{
  let src = read(topmostWatchdog);
  if (!src.includes('DSH_PET_TOPMOST_FLOATING')) {
    const re = /function topmostLevel\(platform\) \{\n\s*return platform === 'darwin' \? 'floating' : 'screen-saver';\n\}/;
    if (!re.test(src)) {
      throw new Error('未找到 topmostLevel 模板；dsh-pet 版本可能已变化，请手动检查：' + topmostWatchdog);
    }
    src = src.replace(re, [
      'function topmostLevel(platform) {',
      '  // DSH_PET_TOPMOST_FLOATING：桌面宠物只用常规置顶（floating），不要压过截图/录屏工具。',
      "  return 'floating';",
      '}'
    ].join('\n'));
    report.topmostLevel.patched = writeIfChanged(topmostWatchdog, src, true);
  } else {
    report.topmostLevel.already = true;
  }
  report.topmostLevel.file = path.relative(pkg, topmostWatchdog);
}

// 10) 光标从身体区域移到外面时收起悬浮名（窗口早就是穿透态也能触发）
{
  let src = read(windowsFile);
  if (!src.includes('DSH_PET_POINTER_ZONE')) {
    const mapRe = /(^|\n)([ \t]*)const offBodyMs = new Map\(\);/;
    if (!mapRe.test(src)) {
      throw new Error('未找到 offBodyMs 定义；dsh-pet 版本可能已变化，请手动检查：' + windowsFile);
    }
    src = src.replace(mapRe, (m, lead, indent) => [
      lead + indent + 'const offBodyMs = new Map();',
      indent + '/** DSH_PET_POINTER_ZONE：上一拍光标分区，用于在离开身体时收起悬浮名 */',
      indent + 'const lastPointerZone = new Map();'
    ].join('\n'));

    const zoneRe = /(^|\n)([ \t]*)const zone = pointerZone\((bounds|b), point, (margin|mg)\);/;
    if (!zoneRe.test(src)) {
      throw new Error('未找到 pointerZone 调用；dsh-pet 版本可能已变化，请手动检查：' + windowsFile);
    }
    src = src.replace(zoneRe, (m, lead, indent, boundsArg, marginArg) => [
      lead + indent + 'const zone = pointerZone(' + boundsArg + ', point, ' + marginArg + ');',
      indent + '// DSH_PET_POINTER_ZONE：光标从身体区域移到外面时立即收起悬浮名（不等窗口穿透状态变化）。',
      indent + 'const prevZone = lastPointerZone.get(win.id);',
      indent + 'lastPointerZone.set(win.id, zone);',
      indent + "if (prevZone === 'body' && zone !== 'body' && !win.isDestroyed()) {",
      indent + "  win.webContents.executeJavaScript('window.__dshPetHideTip && window.__dshPetHideTip()').catch(() => {});",
      indent + '}'
    ].join('\n'));

    const cleanupRe = /(^|\n)([ \t]*)offBodyMs\.delete\(win\.id\);/;
    if (!cleanupRe.test(src)) {
      throw new Error('未找到 offBodyMs 清理；dsh-pet 版本可能已变化，请手动检查：' + windowsFile);
    }
    src = src.replace(cleanupRe, (m, lead, indent) => [
      lead + indent + 'offBodyMs.delete(win.id);',
      indent + 'lastPointerZone.delete(win.id);'
    ].join('\n'));

    report.pointerZone.patched = writeIfChanged(windowsFile, src, true);
  } else {
    report.pointerZone.already = true;
  }
  report.pointerZone.file = path.relative(pkg, windowsFile);
}

console.log(JSON.stringify(report, null, 2));
