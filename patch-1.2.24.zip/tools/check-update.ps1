﻿# Claude 工作台 —— 版本检测与一键更新
# 兼容 Windows PowerShell 5.1（系统自带）和 PowerShell 7。
#
# 用法：
#   检查更新.cmd                         双击运行
#   powershell -File check-update.ps1 -InstallDir "D:\AI_Claude" -CheckOnly
#   powershell -File check-update.ps1 -Manifest "https://.../latest.json" -DryRun -NoGui
#
# 安全：只接受 https / file / 本地路径；下载后必须通过清单里的 SHA256 校验；
#       补丁包解压时拒绝跳出安装目录的路径，并保留 claude-gui\data 用户数据。

param(
  [string]$InstallDir = '',
  [string]$Manifest = '',
  [switch]$CheckOnly,
  [switch]$DryRun,
  [switch]$Yes,
  [switch]$NoGui,
  [switch]$NoLaunch,
  [switch]$NoSuccessInfo
)

$ErrorActionPreference = 'Stop'
$script:ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:Gui = $true
if ($NoGui -or $env:CLAUDE_UPDATE_NOGUI -eq '1') { $script:Gui = $false }

function Log([string]$msg) {
  Write-Host ("[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $msg)
}

function Show-Info([string]$msg) {
  Log $msg
  if ($script:Gui) {
    try {
      Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
      [void][System.Windows.Forms.MessageBox]::Show($msg, 'Claude 工作台更新',
        [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
    } catch { }
  }
}

function Show-ErrorAndExit([string]$msg) {
  Log ("错误：" + $msg)
  if ($script:Gui) {
    try {
      Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
      [void][System.Windows.Forms.MessageBox]::Show($msg, 'Claude 工作台更新',
        [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    } catch { }
  }
  exit 1
}

function Ask-YesNo([string]$msg) {
  if ($Yes) { return $true }
  if ($script:Gui) {
    try {
      Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
      $r = [System.Windows.Forms.MessageBox]::Show($msg, 'Claude 工作台更新',
        [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
      return ($r -eq [System.Windows.Forms.DialogResult]::Yes)
    } catch { }
  }
  $a = Read-Host ($msg + ' [y/N]')
  return ($a -match '^(y|yes|是|好)$')
}

function Find-InstallDir([string]$hint) {
  $candidates = New-Object System.Collections.Generic.List[string]
  if ($hint) { $candidates.Add($hint) }
  if ($script:ScriptDir) {
    $candidates.Add((Split-Path -Parent $script:ScriptDir))
  }
  if ($env:LOCALAPPDATA) {
    $candidates.Add((Join-Path $env:LOCALAPPDATA 'Programs\AI_Claude'))
  }
  if ($env:USERPROFILE) {
    $candidates.Add((Join-Path $env:USERPROFILE 'AI_Claude'))
  }
  # 手动解压/绿色版常见放在各盘根目录
  foreach ($drive in @('C', 'D', 'E', 'F')) {
    $candidates.Add(('{0}:\AI_Claude' -f $drive))
  }
  $regKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\{69C6605A-8A3A-4C8D-BDB7-780404135C1E}_is1'
  try {
    $loc = (Get-ItemProperty -Path $regKey -ErrorAction Stop).InstallLocation
    if ($loc) { $candidates.Add([string]$loc) }
  } catch { }
  foreach ($c in $candidates) {
    if (-not $c) { continue }
    try {
      $full = [IO.Path]::GetFullPath($c)
      if (Test-Path -LiteralPath (Join-Path $full 'claude-gui\server.js')) { return $full }
    } catch { }
  }
  return $null
}

function Get-LocalVersion([string]$dir) {
  $f = Join-Path $dir 'claude-gui\version.json'
  if (-not (Test-Path -LiteralPath $f)) { return $null }
  try {
    $j = Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json
    return [string]$j.version
  } catch { return $null }
}

function Get-DshPetVersion([string]$dir) {
  $f = Join-Path $dir 'dsh-pet\node_modules\dsh-pet\package.json'
  if (-not (Test-Path -LiteralPath $f)) { return $null }
  try {
    $j = Get-Content -LiteralPath $f -Raw -Encoding UTF8 | ConvertFrom-Json
    return [string]$j.version
  } catch { return $null }
}

function Compare-Version([string]$a, [string]$b) {
  try {
    $va = [version]$a
    $vb = [version]$b
    return $va.CompareTo($vb)
  } catch {
    if ($a -eq $b) { return 0 }
    if ($a -gt $b) { return 1 }
    return -1
  }
}

function Get-ManifestSource([string]$dir, [string]$override) {
  if ($override) { return $override }

  $cfgPaths = @(
    (Join-Path $dir 'claude-gui\update-config.json'),
    (Join-Path $dir 'tools\update-config.json')
  )
  foreach ($cfgPath in $cfgPaths) {
    if (-not (Test-Path -LiteralPath $cfgPath)) { continue }
    try {
      $cfg = Get-Content -LiteralPath $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
      if ($cfg.manifestUrl) {
        $u = [string]$cfg.manifestUrl
        if ($u -match '^[a-zA-Z][a-zA-Z0-9+.-]*://') { return $u }
        return [IO.Path]::GetFullPath((Join-Path (Split-Path -Parent $cfgPath) $u))
      }
    } catch { }
  }

  $locals = @(
    (Join-Path $dir 'latest.json'),
    (Join-Path $dir 'update\latest.json'),
    (Join-Path $script:ScriptDir 'latest.json'),
    (Join-Path (Split-Path -Parent $script:ScriptDir) 'latest.json')
  )
  foreach ($p in $locals) {
    if (Test-Path -LiteralPath $p) { return [IO.Path]::GetFullPath($p) }
  }
  return $null
}

function Read-TextFrom([string]$src) {
  if ($src -match '^https?://') {
    $r = Invoke-WebRequest -Uri $src -UseBasicParsing -TimeoutSec 40
    try {
      if ($r.RawContentStream) {
        return [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
      }
    } catch { }
    return [string]$r.Content
  }
  $p = $src
  if ($src -match '^file://') { $p = ([Uri]$src).LocalPath }
  return (Get-Content -LiteralPath $p -Raw -Encoding UTF8)
}

function Resolve-Ref([string]$manifestSource, [string]$ref) {
  if (-not $ref) { return $null }
  if ($ref -match '^[a-zA-Z][a-zA-Z0-9+.-]*://') { return $ref }
  if ($manifestSource -match '^https?://') {
    return ([Uri]::new([Uri]$manifestSource, $ref)).AbsoluteUri
  }
  $p = $manifestSource
  if ($p -match '^file://') { $p = ([Uri]$p).LocalPath }
  $baseDir = Split-Path -Parent ([IO.Path]::GetFullPath($p))
  return [IO.Path]::GetFullPath((Join-Path $baseDir $ref))
}

function Test-HttpUrl([string]$url) {
  return ($url -match '^https?://')
}

function Get-DownloadCandidates([string]$url) {
  $list = New-Object System.Collections.Generic.List[string]
  $list.Add($url)
  if ($url -match '^https://ghfast\.top/(https?://.+)$') {
    $direct = $Matches[1]
    if (-not $list.Contains($direct)) { $list.Add($direct) }
  } elseif ($url -match '^https://raw\.githubusercontent\.com/.+') {
    $mirror = 'https://ghfast.top/' + $url
    if (-not $list.Contains($mirror)) { $list.Add($mirror) }
  }
  return $list
}

function Download-File([string]$url, [string]$dest, $item = $null) {
  $dir = Split-Path -Parent $dest
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $bits = $null
  if (Test-HttpUrl $url) {
    $bits = Get-Command Start-BitsTransfer -ErrorAction SilentlyContinue
  }
  $lastError = ''
  foreach ($src in (Get-DownloadCandidates $url)) {
    for ($attempt = 1; $attempt -le 2; $attempt++) {
      try {
        if (Test-HttpUrl $src) {
          if ($attempt -eq 1 -and $bits) {
            try {
              Log ('使用 BITS 下载：' + $src)
              Start-BitsTransfer -Source $src -Destination $dest -Description 'Claude 工作台更新' -ErrorAction Stop
              if ($item) { Test-Downloaded $dest $item }
              return
            } catch {
              $lastError = $_.Exception.Message
              Log ('BITS 下载失败，改用 HTTP 方式：' + $lastError)
              if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue }
            }
          }
          Log ("正在下载（第 $attempt 次）：" + $src)
          Invoke-WebRequest -Uri $src -OutFile $dest -UseBasicParsing
          if ($item) { Test-Downloaded $dest $item }
          return
        }
        $local = $src
        if ($src -match '^file://') { $local = ([Uri]$src).LocalPath }
        Log ('从本地复制：' + $local)
        Copy-Item -LiteralPath $local -Destination $dest -Force
        if ($item) { Test-Downloaded $dest $item }
        return
      } catch {
        $lastError = $_.Exception.Message
        Log ('下载失败：' + $src + '：' + $lastError)
        if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue }
        if ($attempt -lt 2) { Start-Sleep -Seconds 2 }
      }
    }
  }
  throw ('下载失败（已尝试镜像和重试）：' + $url + '；最后错误：' + $lastError)
}

function Test-Downloaded([string]$path, $item) {
  if (-not (Test-Path -LiteralPath $path)) { throw '下载失败，文件不存在' }
  if ($item.size) {
    $actual = (Get-Item -LiteralPath $path).Length
    if ([long]$actual -ne [long]$item.size) {
      throw ("文件大小不一致：期望 " + $item.size + "，实际 " + $actual)
    }
  }
  if ($item.sha256) {
    $h = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower()
    if ($h -ne ([string]$item.sha256).ToLower()) {
      throw 'SHA256 校验失败，文件可能不完整或被篡改'
    }
    Log 'SHA256 校验通过'
  } else {
    Log '警告：清单没有提供 SHA256，跳过校验'
  }
}

function Stop-Client([string]$dir) {
  $full = [IO.Path]::GetFullPath($dir).TrimEnd('\') + '\'
  $procs = @()
  try {
    $procs = Get-CimInstance Win32_Process | Where-Object {
      $_.ExecutablePath -and ([IO.Path]::GetFullPath($_.ExecutablePath)).StartsWith($full, [StringComparison]::OrdinalIgnoreCase)
    }
  } catch { }

  $killed = 0
  $oldEap = $ErrorActionPreference
  try {
    # 进程可能刚好已经退出，taskkill 的 "not found" 在 Stop 模式下会中断更新。
    # 这里临时降为 SilentlyContinue，同时保留 taskkill /T 的整棵进程树清理能力。
    $ErrorActionPreference = 'SilentlyContinue'
    foreach ($p in $procs) {
      if ($p.Name -match '^(electron|electron-workbench)\.exe$') {
        Log ("关闭工作台进程 PID " + $p.ProcessId)
        & taskkill.exe /PID $p.ProcessId /T /F 2>&1 | Out-Null
        $killed++
      }
    }
    Start-Sleep -Milliseconds 900
    foreach ($p in $procs) {
      if ($p.Name -match '^(node|electron|electron-workbench)\.exe$') {
        # 第一轮已经关掉的 PID 再处理一次是正常情况，不会再报错。
        & taskkill.exe /PID $p.ProcessId /T /F 2>&1 | Out-Null
        $killed++
      }
    }
  } finally {
    $ErrorActionPreference = $oldEap
  }
  if ($killed -eq 0) { Log '工作台没有在运行（或未找到进程）' }
  Start-Sleep -Milliseconds 500
}

function Apply-Patch([string]$zipPath, [string]$dir, [string]$expectedVersion) {
  Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction Stop
  $full = [IO.Path]::GetFullPath($dir).TrimEnd('\') + '\'
  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  $backup = Join-Path $dir ('update-backup\' + $stamp)
  $archive = [IO.Compression.ZipFile]::OpenRead($zipPath)
  try {
    $count = 0
    foreach ($e in $archive.Entries) {
      if ([string]::IsNullOrEmpty($e.Name)) { continue }
      $rel = $e.FullName -replace '/', '\'
      if ($rel -match '^(?i)claude-gui\\data\\') { continue }
      if ($rel -match '^(?i)tools\\update-config\.json$') { continue }
      if ($rel -match '^(?i)_test-profile\\') { continue }

      $target = [IO.Path]::GetFullPath((Join-Path $dir $rel))
      if (-not $target.StartsWith($full, [StringComparison]::OrdinalIgnoreCase)) {
        throw ('压缩包里有不安全的路径：' + $e.FullName)
      }
      if (Test-Path -LiteralPath $target) {
        $b = Join-Path $backup $rel
        New-Item -ItemType Directory -Force -Path (Split-Path $b -Parent) | Out-Null
        Copy-Item -LiteralPath $target -Destination $b -Force
      }
      New-Item -ItemType Directory -Force -Path (Split-Path $target -Parent) | Out-Null
      [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $target, $true)
      $count++
    }
    Log ("已替换 $count 个文件；旧文件备份在 " + $backup)
  } finally {
    $archive.Dispose()
  }

  $now = Get-LocalVersion $dir
  if ($expectedVersion -and $now -and (Compare-Version $now $expectedVersion) -ne 0) {
    Log ("警告：更新后版本是 " + $now + "，清单写的是 " + $expectedVersion)
  }
}

function Run-Installer([string]$exe) {
  Log '正在运行安装程序（静默升级，保留对话和 API Key）…'
  $p = Start-Process -FilePath $exe -ArgumentList '/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART' -Wait -PassThru
  if ($p.ExitCode -ne 0) { throw ('安装程序返回代码 ' + $p.ExitCode) }
}

# 桌宠补丁：更新包只带 bridge\patch-dsh-pet.js，安装后按当前 dsh-pet 版本重打补丁。
# 这样 0.3.8 / 0.4.7 都能兼容，也不会把已升级的 0.4.7 helper 降级成旧版。
function Update-DshPetPatch([string]$dir) {
  $bridge = Join-Path $dir 'dsh-pet\bridge\patch-dsh-pet.js'
  if (-not (Test-Path -LiteralPath $bridge)) { return }
  $node = Join-Path $dir 'dsh-pet\runtime\node.exe'
  if (-not (Test-Path -LiteralPath $node)) {
    $node = Join-Path $dir 'claude-gui\runtime\node.exe'
  }
  if (-not (Test-Path -LiteralPath $node)) {
    Log '桌宠补丁跳过：找不到可用的 node.exe'
    return
  }
  Log '正在重打桌宠集成补丁…'
  try {
    $out = & $node $bridge 2>&1
    foreach ($line in @($out)) {
      if ($line) { Log ('  ' + [string]$line) }
    }
    if ($LASTEXITCODE -ne 0) { Log ('桌宠补丁返回代码 ' + $LASTEXITCODE) }
  } catch {
    Log ('桌宠补丁失败：' + $_.Exception.Message)
  }
}

function Get-WorkbenchLaunchTargets([string]$dir) {
  $desktopDir = Join-Path $dir 'claude-gui\desktop'
  return [pscustomobject]@{
    DesktopDir = $desktopDir
    Exe = Join-Path $desktopDir 'node_modules\electron\dist\electron.exe'
    Vbs = Join-Path $dir 'claude-gui\启动界面.vbs'
    Icon = Join-Path $desktopDir 'icon.ico'
  }
}

# 旧版桌面/开始菜单快捷方式指向 启动工作台.cmd，会先开一个 cmd 窗口，
# Electron 附在上面：关掉窗口会连工作台一起退出，部分系统还会报内存错误。
# 更新时顺手把已有的快捷方式改成直接指向 electron.exe。
function Repair-Shortcuts([string]$dir) {
  $t = Get-WorkbenchLaunchTargets $dir
  if (-not (Test-Path -LiteralPath $t.Exe)) { return }

  $paths = New-Object System.Collections.Generic.List[string]
  $desktop = [Environment]::GetFolderPath('Desktop')
  if ($desktop) {
    $paths.Add((Join-Path $desktop 'Claude 工作台.lnk'))
    $paths.Add((Join-Path $desktop 'Claude Code Workbench.lnk'))
  }
  $programs = [Environment]::GetFolderPath('Programs')
  if ($programs) {
    $paths.Add((Join-Path (Join-Path $programs 'Claude 工作台') 'Claude 工作台.lnk'))
  }

  $ws = $null
  try { $ws = New-Object -ComObject WScript.Shell } catch { return }
  foreach ($p in $paths) {
    if (-not (Test-Path -LiteralPath $p)) { continue }
    try {
      $s = $ws.CreateShortcut($p)
      $s.TargetPath = $t.Exe
      $s.Arguments = '"' + $t.DesktopDir + '"'
      $s.WorkingDirectory = $t.DesktopDir
      $s.IconLocation = $t.Icon + ',0'
      $s.Save()
      Log ('已修复快捷方式：' + $p)
    } catch {
      Log ('快捷方式更新失败：' + $p + ' — ' + $_.Exception.Message)
    }
  }
}

function Start-Workbench([string]$dir) {
  if ($NoLaunch) { Log '已按参数跳过启动'; return }
  $t = Get-WorkbenchLaunchTargets $dir
  if (Test-Path -LiteralPath $t.Vbs) {
    # wscript 没有控制台，能保证工作台不挂在更新窗口上。
    Log '正在重新启动工作台…'
    Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\wscript.exe') -ArgumentList '//nologo', ('"' + $t.Vbs + '"')
    return
  }
  if (Test-Path -LiteralPath $t.Exe) {
    Log '正在重新启动工作台…'
    Start-Process -FilePath $t.Exe -ArgumentList ('"' + $t.DesktopDir + '"') -WorkingDirectory $t.DesktopDir
    return
  }
  $launcher = Join-Path $dir '启动工作台.cmd'
  if (Test-Path -LiteralPath $launcher) {
    Log '正在重新启动工作台…'
    Start-Process -FilePath $launcher -WorkingDirectory $dir
  } else {
    Log '没找到 启动工作台.cmd，请手动打开工作台'
  }
}

function Main {
  if (-not $Manifest) { $Manifest = [string]$env:WORKBENCH_UPDATE_MANIFEST }
  $dir = Find-InstallDir $InstallDir
  if (-not $dir) {
    Show-ErrorAndExit "找不到 Claude 工作台安装目录。`n`n默认应该在：$env:LOCALAPPDATA\Programs\AI_Claude`n请把本工具放到安装目录，或用 -InstallDir 指定。"
  }
  Log ("安装目录：" + $dir)

  $localVer = Get-LocalVersion $dir
  if (-not $localVer) {
    Show-ErrorAndExit '读不到 claude-gui\version.json，安装可能不完整'
  }
  Log ("当前版本：" + $localVer)

  $src = Get-ManifestSource $dir $Manifest
  if (-not $src) {
    Show-ErrorAndExit "还没有配置更新地址。`n`n请让分享者把 latest.json 的链接填到：`n$dir\tools\update-config.json`n或者把 latest.json 放到安装目录/update 子目录。"
  }
  Log ("更新清单：" + $src)

  $text = Read-TextFrom $src
  $m = $text | ConvertFrom-Json
  if ($m.app -and [string]$m.app -ne 'claude-workbench') {
    throw ('清单的 app 不是 claude-workbench：' + $m.app)
  }
  $remoteVer = [string]$m.version
  if (-not $remoteVer) { throw '清单缺少 version 字段' }
  Log ("最新版本：" + $remoteVer)

  if ((Compare-Version $localVer $remoteVer) -ge 0) {
    if (-not $NoSuccessInfo) { Show-Info ("已经是最新版本 " + $localVer) }
    return
  }

  $notes = [string]$m.notes
  $msg = "发现新版本 $remoteVer`n当前版本：$localVer`n"
  if ($notes) { $msg += "`n更新内容：`n$notes`n" }
  $msg += "`n现在更新吗？"

  if ($CheckOnly) {
    Show-Info $msg
    return
  }
  if (-not (Ask-YesNo $msg)) { Log '已取消'; return }

  $patch = $m.patch
  $full = $m.full
  $usePatch = $false
  if ($patch -and $patch.url) {
    $usePatch = $true
    if ($patch.fromVersion) {
      if ((Compare-Version $localVer ([string]$patch.fromVersion)) -lt 0) {
        Log ('当前版本低于补丁的起始版本 ' + $patch.fromVersion + '，改用完整安装包')
        $usePatch = $false
      }
    }
  }

  $item = $null
  $kind = ''
  if ($usePatch) { $item = $patch; $kind = 'patch' }
  elseif ($full -and $full.url) { $item = $full; $kind = 'full' }
  else { throw '清单里没有可用的更新文件（patch/full 都为空）' }

  $url = Resolve-Ref $src ([string]$item.url)
  Log ("更新方式：" + $(if ($kind -eq 'patch') { '增量补丁' } else { '完整安装包' }))
  Log ("下载地址：" + $url)

  # 桌宠单独打包：本地已经是清单版本就跳过；否则和客户端补丁一起下载、一起应用。
  $dshPet = $m.dshPet
  $needDshPet = $false
  $dshPetUrl = ''
  if ($dshPet -and $dshPet.url -and $dshPet.version) {
    $localDsh = Get-DshPetVersion $dir
    if (-not $localDsh -or (Compare-Version $localDsh ([string]$dshPet.version)) -lt 0) {
      $needDshPet = $true
      $dshPetUrl = Resolve-Ref $src ([string]$dshPet.url)
      Log ("桌宠版本：" + $(if ($localDsh) { $localDsh } else { '未知' }) +
        "，将一并更新到 " + $dshPet.version)
      Log ("桌宠更新包：" + $dshPetUrl)
    } else {
      Log ("桌宠已是最新：" + $localDsh)
    }
  }

  if ($DryRun) {
    $dry = "演练模式：将下载`n$url`n`n然后" + $(if ($kind -eq 'patch') { '替换程序文件' } else { '运行安装程序' })
    if ($needDshPet) { $dry += "`n`n再应用桌宠更新包`n$dshPetUrl" }
    Show-Info $dry
    return
  }

  $tempRoot = Join-Path $env:TEMP ('ClaudeWorkbenchUpdate\' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force -Path $tempRoot | Out-Null
  $fileName = ''
  try { $fileName = [IO.Path]::GetFileName(([Uri]$url).AbsolutePath) } catch { $fileName = '' }
  if (-not $fileName) { $fileName = [IO.Path]::GetFileName($url) }
  if (-not $fileName) { $fileName = 'update.bin' }
  $dest = Join-Path $tempRoot $fileName

  Download-File $url $dest $item

  $dshDest = $null
  if ($needDshPet) {
    $dshName = ''
    try { $dshName = [IO.Path]::GetFileName(([Uri]$dshPetUrl).AbsolutePath) } catch { $dshName = '' }
    if (-not $dshName) { $dshName = [IO.Path]::GetFileName($dshPetUrl) }
    if (-not $dshName) { $dshName = 'dsh-pet.zip' }
    $dshDest = Join-Path $tempRoot $dshName
    Download-File $dshPetUrl $dshDest $dshPet
  }

  Stop-Client $dir

  if ($kind -eq 'patch') {
    Log '正在应用增量补丁…'
    Apply-Patch $dest $dir $remoteVer
  } else {
    Run-Installer $dest
  }

  if ($needDshPet -and $dshDest) {
    Log ('正在应用桌宠更新 ' + [string]$dshPet.version + '…')
    Apply-Patch $dshDest $dir ''
    $nowDsh = Get-DshPetVersion $dir
    if ($nowDsh) { Log ("桌宠更新后版本：" + $nowDsh) }
    if ($nowDsh -and (Compare-Version $nowDsh ([string]$dshPet.version)) -ne 0) {
      Log ("警告：桌宠版本是 " + $nowDsh + "，清单写的是 " + $dshPet.version)
    }
  }

  Update-DshPetPatch $dir

  $now = Get-LocalVersion $dir
  if ($now) { Log ("更新后版本：" + $now) }
  Repair-Shortcuts $dir

  # 客户端内更新（更新按钮/manual 检查更新）默认也会检查 Chrome；一键更新包用
  # -NoGui 调用本脚本，随后由一键更新.cmd 单独运行 tools\setup-chrome.ps1。
  if ($script:Gui) {
    $chromeSetup = Join-Path $dir 'claude-gui\tools\setup-chrome.ps1'
    if (Test-Path -LiteralPath $chromeSetup) {
      Log '正在检查/配置 Chrome…'
      $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
      try {
        & $psExe -NoProfile -ExecutionPolicy Bypass -File $chromeSetup -InstallDir $dir
      } catch {
        Log ('Chrome 配置失败：' + $_.Exception.Message)
      }
    }
  }

  if (-not $NoSuccessInfo) {
    Show-Info ("更新完成，当前版本 " + $(if ($now) { $now } else { $remoteVer }))
  }
  Start-Workbench $dir
}

try {
  Main
} catch {
  Show-ErrorAndExit $_.Exception.Message
}
