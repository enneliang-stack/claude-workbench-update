'use strict';

/**
 * Claude 工作台 —— 真实 Chrome 启动/聚焦
 *
 * 1. 使用专用 profile 启动本机真实 Chrome（保持登录态）；
 * 2. 开启 CDP 9222；
 * 3. 以 msedge 会话名 attach，后续 playwright-cli 命令照旧可用。
 *
 * 默认后台：AI 网页任务不抢焦点、不盖住用户当前应用，遮挡状态下也能操作和截图。
 * --focus：置前（顶栏浏览器按钮、用户要求打开给他看）。
 * --alert：置前 + 任务栏闪烁 + 提示音（登录/验证码/权限确认等需要用户介入）。
 *
 * 幂等：Chrome 已在跑、会话已 attach 时直接返回。
 * 输出最后一行 JSON，供工作台主服务解析。
 */

const fs = require('fs');
const path = require('path');
const { spawn, spawnSync } = require('child_process');

const PORT = Number(process.env.CHROME_DEBUG_PORT || 9222);
const SESSION = process.env.WORKBENCH_CHROME_SESSION || 'msedge';
const PROFILE = path.resolve(process.env.CHROME_PROFILE_DIR ||
  path.join(process.env.LOCALAPPDATA || '', 'ClaudeWorkbenchChrome'));
const CLI_CWD = path.join(__dirname, '..');
const CHROME_CONFIG = path.join(__dirname, 'data', 'chrome-path.json');

// 默认后台：窗口可见但不抢焦点，AI 任务不应该打断用户。
// --focus：置前（顶栏按钮、用户要求打开给我看）。
// --alert：置前 + 任务栏闪烁 + 提示音（登录/验证码/权限确认等需要用户介入）。
// 兼容：旧版顶栏按钮调用本脚本时不带参数，仍应置前；AI 会话由工作台注入
// WORKBENCH_CHROME_BROWSER 环境变量，无参数时仍走后台。
const ARGV = process.argv.slice(2).map(arg => String(arg).toLowerCase());
const ALERT = ARGV.includes('--alert');
const EXPLICIT_BACKGROUND = ARGV.includes('--background');
const EXPLICIT_FOCUS = ALERT || ARGV.includes('--focus') || ARGV.includes('--foreground');
const FOCUS = EXPLICIT_FOCUS ||
  (!EXPLICIT_BACKGROUND && ARGV.length === 0 && !process.env.WORKBENCH_CHROME_BROWSER);

// 后台窗口被遮挡时别让 Chrome 降低定时器/rAF 频率，否则个别站点会变慢或截到空白。
const LAUNCH_FLAGS = [
  '--disable-backgrounding-occluded-windows',
  '--disable-renderer-backgrounding',
  '--disable-background-timer-throttling',
  '--disable-features=CalculateNativeWinOcclusion'
];

function readChromeConfig() {
  try {
    const data = JSON.parse(fs.readFileSync(CHROME_CONFIG, 'utf8'));
    if (!data || typeof data !== 'object') return null;
    const pathValue = typeof data.path === 'string' ? data.path.trim() : '';
    const dirValue = typeof data.dir === 'string' ? data.dir.trim() : '';
    return pathValue || dirValue ? { path: pathValue, dir: dirValue } : null;
  } catch {
    return null;
  }
}

// 用户可能选择 chrome.exe，也可能选择 Application / Google\Chrome / 便携版目录。
function resolveChromeExe(input) {
  if (!input) return '';
  const candidates = [input];
  try {
    if (fs.statSync(input).isDirectory()) {
      candidates.push(
        path.join(input, 'chrome.exe'),
        path.join(input, 'Application', 'chrome.exe'),
        path.join(input, 'chrome-win64', 'chrome.exe'),
        path.join(input, 'chrome-win32', 'chrome.exe')
      );
    }
  } catch { /* 不存在时只按文件路径判断 */ }
  return candidates.find(file => {
    try { return fs.statSync(file).isFile(); } catch { return false; }
  }) || '';
}

function findChrome() {
  const config = readChromeConfig();
  const configured = config ? resolveChromeExe(config.path || config.dir) : '';
  if (configured) return configured;

  const chromeRoots = [
    process.env.LOCALAPPDATA || '',
    process.env.PROGRAMFILES || '',
    process.env['PROGRAMFILES(X86)'] || ''
  ].filter(Boolean);
  const chromeChannels = ['Chrome', 'Chrome Beta', 'Chrome Dev', 'Chrome SxS'];
  const candidates = [
    process.env.CHROME_PATH,
    ...chromeRoots.flatMap(root => chromeChannels.map(channel =>
      path.join(root, 'Google', channel, 'Application', 'chrome.exe')))
  ].filter(Boolean);
  return candidates.map(resolveChromeExe).find(Boolean) || '';
}

function findCli() {
  const fromEnv = process.env.PLAYWRIGHT_CLI;
  if (fromEnv && fs.existsSync(fromEnv)) return fromEnv;

  const exts = process.platform === 'win32' ? ['.cmd', '.exe', ''] : [''];
  const dirs = (process.env.PATH || '').split(path.delimiter).filter(Boolean);
  const known = [
    path.join(__dirname, 'tools', 'playwright-cli'),
    path.join(process.env.APPDATA || '', 'npm')
  ].filter(Boolean);

  for (const dir of [...dirs, ...known]) {
    for (const ext of exts) {
      const candidate = path.join(dir, 'playwright-cli' + ext);
      try {
        if (fs.existsSync(candidate)) return candidate;
      } catch { /* ignore */ }
    }
  }
  return 'playwright-cli';
}

function runCli(args, timeout = 60000) {
  const cli = findCli();
  const command = /\s/.test(cli) ? `"${cli}"` : cli;
  const result = spawnSync(command, args, {
    cwd: CLI_CWD,
    windowsHide: true,
    shell: process.platform === 'win32',
    encoding: 'utf8',
    timeout
  });
  return {
    code: typeof result.status === 'number' ? result.status : -1,
    out: result.stdout || '',
    err: result.stderr || (result.error ? result.error.message : '')
  };
}

function parseJsonObject(text) {
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('无法解析 playwright-cli 输出');
  return JSON.parse(text.slice(start, end + 1));
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// 把任意字符串安全地嵌入 PowerShell 单引号字符串。
function psLiteral(value) {
  return `'${String(value).replace(/'/g, "''")}'`;
}

// 按专用 profile 完整路径匹配 Chrome 进程，避免误伤用户自己的其他 Chrome 实例。
function chromeProcessFilter() {
  return `$procs = Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" | Where-Object { $_.CommandLine -and $_.CommandLine.IndexOf(${psLiteral(PROFILE)}, [System.StringComparison]::OrdinalIgnoreCase) -ge 0 };`;
}

async function getJson(url, timeout = 1500) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok) return null;
    return await response.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function chromeVersion() {
  const version = await getJson(`http://127.0.0.1:${PORT}/json/version`);
  if (!version) return null;
  return /Chrome\//i.test(version.Browser || '') ? version : null;
}

function listSessions() {
  const result = runCli(['list', '--json'], 8000);
  if (result.code !== 0) return [];
  try {
    const data = parseJsonObject(result.out);
    return Array.isArray(data.browsers) ? data.browsers : [];
  } catch {
    return [];
  }
}

function closeSession() {
  try { runCli(['-s=' + SESSION, 'close'], 15000); } catch { /* ignore */ }
}

function detachSession() {
  try { runCli(['-s=' + SESSION, 'detach'], 15000); } catch { /* ignore */ }
}

function sessionWorks() {
  const result = runCli(['-s=' + SESSION, 'tab-list'], 8000);
  return result.code === 0 && /(^|\n)-\s*\d+:/.test(result.out);
}

function attachSession() {
  const result = runCli([
    'attach',
    `--cdp=http://127.0.0.1:${PORT}`,
    `--session=${SESSION}`
  ], 60000);

  if (result.code === 0) return { ok: true, out: result.out };

  const detail = (result.err || result.out || '').trim();
  const sessions = listSessions();
  const attached = sessions.find(s => s.name === SESSION && s.attached && s.status === 'open');
  if (attached) return { ok: true, out: result.out };

  return { ok: false, error: detail || `attach 退出码 ${result.code}` };
}

async function waitForChrome(timeout = 30000) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    const version = await chromeVersion();
    if (version) return version;
    await sleep(300);
  }
  return null;
}

function captureForegroundWindow() {
  // Chrome 尚未启动时，先记住用户当前的前台窗口，启动后把焦点还回去。
  if (process.platform !== 'win32') return 0;
  try {
    const ps = `Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public class WbFg { [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow(); }'; [WbFg]::GetForegroundWindow().ToInt64()`;
    const result = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], {
      windowsHide: true,
      encoding: 'utf8',
      timeout: 5000
    });
    return Number(String(result.stdout || '').trim()) || 0;
  } catch {
    return 0;
  }
}

function clearChromeSessionState() {
  // 冷启动前清掉“恢复上次会话”的数据：每次从新标签页开始，不恢复旧窗口/标签。
  // 只动 session 相关文件，Cookies、登录态、历史、书签都不受影响。
  try {
    const defaultDir = path.join(PROFILE, 'Default');
    for (const name of ['Current Session', 'Current Tabs', 'Last Session', 'Last Tabs']) {
      try { fs.rmSync(path.join(defaultDir, name), { force: true }); } catch { /* ignore */ }
    }
    for (const name of ['Sessions', 'Sessions_Encrypted']) {
      try { fs.rmSync(path.join(defaultDir, name), { recursive: true, force: true }); } catch { /* ignore */ }
    }
    const prefsPath = path.join(defaultDir, 'Preferences');
    if (!fs.existsSync(prefsPath)) return;
    const prefs = JSON.parse(fs.readFileSync(prefsPath, 'utf8'));
    prefs.session = prefs.session || {};
    prefs.session.restore_on_startup = 5; // 5 = 打开新标签页
    prefs.session.startup_urls = [];
    prefs.profile = prefs.profile || {};
    prefs.profile.exit_type = 'Normal';
    prefs.profile.exited_cleanly = true;
    fs.writeFileSync(prefsPath, JSON.stringify(prefs));
  } catch { /* 清理失败不阻塞启动 */ }
}

function quoteWinArg(value) {
  const arg = String(value);
  if (!/[\s"]/.test(arg)) return arg;
  return '"' + arg.replace(/(\\*)"/g, '$1$1\\"').replace(/(\\+)$/, '$1$1') + '"';
}

function launchChromeNoActivate(chromePath) {
  // 用 CreateProcess + SW_SHOWMINNOACTIVE 启动 Chrome：先最小化出现，避免窗口在前的闪现；
  // showChromeWithoutActivating 会立即恢复它并压到最底层，不抢前台。
  // 配合每次冷启动清空会话恢复，避免 Chrome 恢复旧窗口时自己跳到前台。
  if (process.platform !== 'win32') return { ok: false };
  try {
    const argsList = [
      `--remote-debugging-port=${PORT}`,
      `--user-data-dir=${PROFILE}`,
      '--no-first-run',
      '--no-default-browser-check',
      '--remote-allow-origins=*',
      '--hide-crash-restore-bubble',
      ...LAUNCH_FLAGS
    ];
    const cmdLine = [chromePath, ...argsList].map(quoteWinArg).join(' ');
    const script = [
      `$ErrorActionPreference = 'Stop'`,
      `Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; using System.Text; public class WbLaunch { [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] public struct STARTUPINFO { public int cb; public string lpReserved; public string lpDesktop; public string lpTitle; public int dwX; public int dwY; public int dwXSize; public int dwYSize; public int dwXCountChars; public int dwYCountChars; public int dwFillAttribute; public int dwFlags; public short wShowWindow; public short cbReserved2; public IntPtr lpReserved2; public IntPtr hStdInput; public IntPtr hStdOutput; public IntPtr hStdError; } [StructLayout(LayoutKind.Sequential)] public struct PROCESS_INFORMATION { public IntPtr hProcess; public IntPtr hThread; public int dwProcessId; public int dwThreadId; } [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] public static extern bool CreateProcess(string lpApplicationName, StringBuilder lpCommandLine, IntPtr lpProcessAttributes, IntPtr lpThreadAttributes, bool bInheritHandles, uint dwCreationFlags, IntPtr lpEnvironment, string lpCurrentDirectory, ref STARTUPINFO lpStartupInfo, out PROCESS_INFORMATION lpProcessInformation); [DllImport("kernel32.dll", SetLastError = true)] public static extern bool CloseHandle(IntPtr hObject); }';`,
      `$exe = ${psLiteral(chromePath)}`,
      `$cmdLine = ${psLiteral(cmdLine)}`,
      `$si = New-Object WbLaunch+STARTUPINFO`,
      `$si.cb = [System.Runtime.InteropServices.Marshal]::SizeOf([type][WbLaunch+STARTUPINFO])`,
      `$si.dwFlags = 1`,
      `$si.wShowWindow = 7`,
      `$pi = New-Object WbLaunch+PROCESS_INFORMATION`,
      `$ok = [WbLaunch]::CreateProcess($exe, (New-Object System.Text.StringBuilder($cmdLine)), [IntPtr]::Zero, [IntPtr]::Zero, $false, 0x208, [IntPtr]::Zero, (Split-Path $exe), [ref]$si, [ref]$pi)`,
      `if (-not $ok) { Write-Output ('CREATE_FAILED=' + [System.Runtime.InteropServices.Marshal]::GetLastWin32Error()); exit 1 }`,
      `[WbLaunch]::CloseHandle($pi.hThread) | Out-Null`,
      `[WbLaunch]::CloseHandle($pi.hProcess) | Out-Null`,
      `Write-Output ('PID=' + $pi.dwProcessId)`
    ].join('\n');
    const encoded = Buffer.from(script, 'utf16le').toString('base64');
    const result = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', encoded], {
      windowsHide: true,
      encoding: 'utf8',
      timeout: 15000
    });
    const pid = /PID=(\d+)/.exec(result.stdout || '');
    if (result.status === 0 && pid) return { ok: true, pid: Number(pid[1]) };
    return { ok: false, error: (result.stderr || result.stdout || '').trim() };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
}

async function showChromeWithoutActivating(previousHandle, launcherPid) {
  // 后台模式冷启动：Chrome 自己会抢一次前台，这里把焦点还给原来的窗口。
  // 只恢复前台焦点，不最小化窗口（最小化会触发 Chrome 的后台节流）。
  // 等待恢复完成再退出，避免独立子进程被调用方一起结束。
  // 优先用启动时拿到的 Chrome PID 找窗口，避免 CIM 查询的延迟。
  if (process.platform !== 'win32' || !previousHandle) return { restored: false, raised: false, wasMinimized: false };
  const candidatePid = Number(launcherPid) || 0;
  try {
    const ps = [
      `$prev = [IntPtr]::new([Int64]${previousHandle});`,
      `$candidatePid = ${candidatePid};`,
      `Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public class WbBg { [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow(); [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId); [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId(); [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach); [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd); [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd); [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags); [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow); [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hWnd); [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd); }';`,
      `$hwnd = [IntPtr]::Zero;`,
      `$firstSeen = $null;`,
      `$started = Get-Date;`,
      `$triedCim = $false;`,
      `$deadline = (Get-Date).AddSeconds(6);`,
      `$restored = 0;`,
      `$raisedPrev = $false;`,
      `$unminimized = $false;`,
      `$wasMinimized = $false;`,
      `while ((Get-Date) -lt $deadline -and $restored -lt 2) {`,
      `  if ($hwnd -eq [IntPtr]::Zero) {`,
      `    if ($candidatePid -gt 0) {`,
      `      $cw = Get-Process -Id $candidatePid -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1;`,
      `      if ($cw) { $hwnd = $cw.MainWindowHandle; $firstSeen = Get-Date }`,
      `    };`,
      `    if ($hwnd -eq [IntPtr]::Zero -and -not $triedCim -and ((Get-Date) - $started).TotalMilliseconds -gt 1500) {`,
      `      $triedCim = $true;`,
      `      ${chromeProcessFilter()}`,
      `      $w = $procs | ForEach-Object { Get-Process -Id $_.ProcessId -ErrorAction SilentlyContinue } | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1;`,
      `      if ($w) { $hwnd = $w.MainWindowHandle; $firstSeen = Get-Date }`,
      `    }`,
      `  };`,
      `  if ($hwnd -ne [IntPtr]::Zero -and -not $unminimized) {`,
      `    if ([WbBg]::IsIconic($hwnd)) {`,
      `      $wasMinimized = $true;`,
      `      [WbBg]::ShowWindow($hwnd, 4) | Out-Null;`,
      `      [WbBg]::SetWindowPos($hwnd, [IntPtr](1), 0, 0, 0, 0, 0x0013) | Out-Null`,
      `    };`,
      `    $unminimized = $true`,
      `  };`,
      `  if ($hwnd -ne [IntPtr]::Zero) {`,
      `    if ([WbBg]::GetForegroundWindow() -eq $hwnd -and [WbBg]::IsWindow($prev)) {`,
      `      [WbBg]::ShowWindow($hwnd, 4) | Out-Null;`,
      `      [WbBg]::SetWindowPos($hwnd, [IntPtr](-2), 0, 0, 0, 0, 0x0053) | Out-Null;`,
      `      for ($attempt = 0; $attempt -lt 4 -and ([WbBg]::GetForegroundWindow() -ne $prev); $attempt++) {`,
      `        $fgPid = 0;`,
      `        $fgThread = [WbBg]::GetWindowThreadProcessId([WbBg]::GetForegroundWindow(), [ref]$fgPid);`,
      `        $myThread = [WbBg]::GetCurrentThreadId();`,
      `        [WbBg]::AttachThreadInput($myThread, $fgThread, $true) | Out-Null;`,
      `        [WbBg]::SetWindowPos($prev, [IntPtr](-1), 0, 0, 0, 0, 0x0043) | Out-Null;`,
      `        [WbBg]::SetWindowPos($prev, [IntPtr](-2), 0, 0, 0, 0, 0x0043) | Out-Null;`,
      `        [WbBg]::BringWindowToTop($prev) | Out-Null;`,
      `        [WbBg]::SetForegroundWindow($prev) | Out-Null;`,
      `        [WbBg]::AttachThreadInput($myThread, $fgThread, $false) | Out-Null;`,
      `        if ([WbBg]::GetForegroundWindow() -ne $prev) { Start-Sleep -Milliseconds 40 }`,
      `      };`,
      `      if ([WbBg]::GetForegroundWindow() -eq $prev) {`,
      `        $restored++;`,
      `        Start-Sleep -Milliseconds 150;`,
      `        break`,
      `      };`,
      `      Start-Sleep -Milliseconds 50`,
      `    } else {`,
      `      if (-not $raisedPrev -and [WbBg]::GetForegroundWindow() -eq $prev -and [WbBg]::IsWindow($prev)) {`,
      `        [WbBg]::SetWindowPos($prev, [IntPtr]::Zero, 0, 0, 0, 0, 0x0013) | Out-Null;`,
      `        $raisedPrev = $true`,
      `      };`,
      `      if ($firstSeen -and ((Get-Date) - $firstSeen).TotalMilliseconds -gt 1200) { break };`,
      `      Start-Sleep -Milliseconds 50`,
      `    }`,
      `  } else { Start-Sleep -Milliseconds 100 }`,
      `}`,
      `Write-Output ('RESTORED=' + $restored)`,
      `Write-Output ('RAISED=' + [int]$raisedPrev)`,
      `Write-Output ('WAS_MINIMIZED=' + [int]$wasMinimized)`
    ].join(' ');
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], {
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'ignore']
    });
    let out = '';
    if (child.stdout) child.stdout.on('data', d => { out += d; });
    await new Promise(resolve => {
      const timer = setTimeout(() => {
        try { child.kill(); } catch { /* ignore */ }
        resolve();
      }, 6000);
      child.on('close', () => { clearTimeout(timer); resolve(); });
      child.on('error', () => { clearTimeout(timer); resolve(); });
    });
    const restored = Number((/RESTORED=(\d+)/.exec(out) || [])[1] || 0) > 0;
    const raised = Number((/RAISED=(\d+)/.exec(out) || [])[1] || 0) > 0;
    const wasMinimized = Number((/WAS_MINIMIZED=(\d+)/.exec(out) || [])[1] || 0) > 0;
    return { restored, raised, wasMinimized };
  } catch {
    return { restored: false, raised: false, wasMinimized: false };
  }
}

async function bringChromeToFront(alert = false) {
  // 恢复并置前专用 profile 的 Chrome 窗口。
  // 单纯 SetForegroundWindow 会被 Windows 前台锁拦住，这里用 AttachThreadInput + 短暂 topmost 绕过。
  // alert=true 时再闪烁任务栏并播放提示音，用于登录/验证码等需要用户介入的场景。
  try {
    const ps = [
      `${chromeProcessFilter()}`,
      `$w = $procs | ForEach-Object { Get-Process -Id $_.ProcessId -ErrorAction SilentlyContinue } | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1;`,
      `if ($w) {`,
      `Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public class WbFocus { [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow(); [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId); [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId(); [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach); [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow); [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd); [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd); [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags); [DllImport("user32.dll")] public static extern bool FlashWindowEx(ref FLASHWINFO pwfi); [StructLayout(LayoutKind.Sequential)] public struct FLASHWINFO { public uint cbSize; public IntPtr hwnd; public uint dwFlags; public uint uCount; public uint dwTimeout; } }';`,
      `$fg = [WbFocus]::GetForegroundWindow();`,
      `$fgPid = 0;`,
      `$fgThread = [WbFocus]::GetWindowThreadProcessId($fg, [ref]$fgPid);`,
      `$myThread = [WbFocus]::GetCurrentThreadId();`,
      `[WbFocus]::AttachThreadInput($myThread, $fgThread, $true) | Out-Null;`,
      `[WbFocus]::ShowWindow($w.MainWindowHandle, 9) | Out-Null;`,
      `[WbFocus]::SetWindowPos($w.MainWindowHandle, [IntPtr](-1), 0, 0, 0, 0, 0x0043) | Out-Null;`,
      `[WbFocus]::SetWindowPos($w.MainWindowHandle, [IntPtr](-2), 0, 0, 0, 0, 0x0043) | Out-Null;`,
      `[WbFocus]::BringWindowToTop($w.MainWindowHandle) | Out-Null;`,
      `[WbFocus]::SetForegroundWindow($w.MainWindowHandle) | Out-Null;`,
      `[WbFocus]::AttachThreadInput($myThread, $fgThread, $false) | Out-Null;`,
      alert
        ? `$fi = New-Object WbFocus+FLASHWINFO; $fi.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf([type][WbFocus+FLASHWINFO]); $fi.hwnd = $w.MainWindowHandle; $fi.dwFlags = [uint32]15; $fi.uCount = [uint32]0; $fi.dwTimeout = [uint32]0; [WbFocus]::FlashWindowEx([ref]$fi) | Out-Null; [System.Media.SystemSounds]::Exclamation.Play()`
        : '',
      `}`
    ].filter(Boolean).join(' ');
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], {
      windowsHide: true,
      stdio: 'ignore'
    });
    await new Promise(resolve => {
      const timer = setTimeout(resolve, 2500);
      child.on('close', () => { clearTimeout(timer); resolve(); });
      child.on('error', () => { clearTimeout(timer); resolve(); });
    });
  } catch { /* ignore */ }
}

async function main() {
  if (!fs.existsSync(PROFILE)) {
    try { fs.mkdirSync(PROFILE, { recursive: true }); } catch { /* ignore */ }
  }

  let launched = false;
  let previousForeground = 0;
  let restoreTask = null;
  let launchMode = 'reused';
  let focusRestored = false;
  let focusRaised = false;
  let focusMinimized = false;
  let version = await chromeVersion();

  if (!version) {
    const chromePath = findChrome();
    if (!chromePath) {
      const error = new Error('没有找到本机 Chrome（chrome.exe）');
      error.code = 'CHROME_NOT_FOUND';
      throw error;
    }

    if (!FOCUS) previousForeground = captureForegroundWindow();
    clearChromeSessionState();

    let launchedPid = 0;
    let launchedNoActivate = false;
    if (!FOCUS) {
      const noActivate = launchChromeNoActivate(chromePath);
      if (noActivate.ok) {
        launchedNoActivate = true;
        launchedPid = noActivate.pid;
        launchMode = 'no-activate';
      } else {
        launchMode = 'spawn-fallback';
      }
    } else {
      launchMode = 'spawn';
    }

    if (!launchedNoActivate) {
      const child = spawn(chromePath, [
        `--remote-debugging-port=${PORT}`,
        `--user-data-dir=${PROFILE}`,
        '--no-first-run',
        '--no-default-browser-check',
        '--remote-allow-origins=*',
        '--hide-crash-restore-bubble',
        ...LAUNCH_FLAGS
      ], {
        detached: true,
        stdio: 'ignore',
        windowsHide: false
      });
      child.unref();
      launchedPid = child.pid;
    }
    launched = true;

    // 万一 Chrome 还是抢到前台（例如启动参数被忽略），立即把焦点还给用户。
    if (!FOCUS && launchedPid) restoreTask = showChromeWithoutActivating(previousForeground, launchedPid);

    version = await waitForChrome(30000);
    if (!version) {
      throw new Error(`真实 Chrome 已启动，但 CDP ${PORT} 端口未就绪；请检查是否有其他 Chrome 占用了专用 profile`);
    }
  } else if (!/Chrome\//i.test(version.Browser || '')) {
    throw new Error(`端口 ${PORT} 被其他浏览器占用：${version.Browser || '未知'}`);
  }

  const sessions = listSessions();
  const existing = sessions.find(s => s.name === SESSION && s.status === 'open');

  if (existing && existing.attached && sessionWorks()) {
    if (FOCUS) await bringChromeToFront(ALERT);
    else if (launched && restoreTask) {
      const result = await restoreTask;
      focusRestored = !!(result && result.restored);
      focusRaised = !!(result && result.raised);
      focusMinimized = !!(result && result.wasMinimized);
    }
    return {
      ok: true, session: SESSION, port: PORT, launched, reused: true, focused: FOCUS,
      launchMode: launched ? launchMode : 'reused',
      focusRestored, focusRaised, focusMinimized,
      restoreFrom: launched && !FOCUS ? previousForeground : undefined,
      browser: version.Browser
    };
  }

  if (existing) {
    // 旧会话可能已失效（例如 Chrome 重启过）；断开后再接。
    if (existing.attached) detachSession();
    else closeSession();
    await sleep(600);
  }

  let attached = attachSession();
  if (!attached.ok) {
    // 可能是旧会话状态未清理，重试一次。
    detachSession();
    await sleep(500);
    attached = attachSession();
  }
  if (!attached.ok) {
    throw new Error(attached.error || '无法把真实 Chrome 接入 msedge 会话');
  }

  if (FOCUS) {
    await bringChromeToFront(ALERT);
  } else if (launched && restoreTask) {
    // 启动时已经开始监听前台，这里等它结束（通常不到 1 秒）。
    const result = await restoreTask;
    focusRestored = !!(result && result.restored);
    focusRaised = !!(result && result.raised);
    focusMinimized = !!(result && result.wasMinimized);
  }
  return {
    ok: true, session: SESSION, port: PORT, launched, focused: FOCUS,
    launchMode: launched ? launchMode : 'reused',
    focusRestored, focusRaised, focusMinimized,
    restoreFrom: launched && !FOCUS ? previousForeground : undefined,
    browser: version.Browser
  };
}

main()
  .then(result => {
    process.stdout.write(JSON.stringify(result) + '\n');
    process.exit(0);
  })
  .catch(error => {
    const message = String(error && error.message ? error.message : error);
    process.stderr.write((error && error.code ? error.code + ': ' : '') + message + '\n');
    process.exit(1);
  });
