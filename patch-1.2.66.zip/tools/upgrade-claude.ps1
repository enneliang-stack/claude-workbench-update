﻿# Claude Code CLI 手动升级脚本
#
# 用法：
#   powershell -NoProfile -ExecutionPolicy Bypass -File upgrade-claude.ps1 -Version 2.1.332 -InstallDir "D:\AI_Claude" -Yes
#   powershell -NoProfile -ExecutionPolicy Bypass -File upgrade-claude.ps1 -Version 2.1.332 -CheckOnly
#
# 只做“官方旧版 → 官方新版”的完整升级；不修改 CLI 内容。
# WinGet 安装用 winget upgrade，native 安装用 claude install <版本> --force，npm 安装用 npm install -g。

param(
  [string]$Version = '',
  [string]$InstallDir = '',
  [switch]$Yes,
  [switch]$NoRestart,
  [switch]$CheckOnly
)

$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

$script:LogPath = Join-Path $env:TEMP ('ClaudeCodeUpgrade-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')
$script:NeedRestart = $false

function Log([string]$msg) {
  $line = '[' + (Get-Date -Format 'HH:mm:ss') + '] ' + $msg
  Write-Host $line
  try { Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8 } catch { }
}

function Show-Msg([string]$text, [string]$title, [string]$icon = 'Information') {
  try {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
    [void][System.Windows.Forms.MessageBox]::Show(
      $text,
      $title,
      [System.Windows.Forms.MessageBoxButtons]::OK,
      [System.Windows.Forms.MessageBoxIcon]::$icon
    )
  } catch {
    Write-Host $text
  }
}

function Ask-YesNo([string]$text, [string]$title) {
  if ($Yes) { return $true }
  try {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
    $r = [System.Windows.Forms.MessageBox]::Show(
      $text,
      $title,
      [System.Windows.Forms.MessageBoxButtons]::YesNo,
      [System.Windows.Forms.MessageBoxIcon]::Question
    )
    return ($r -eq [System.Windows.Forms.DialogResult]::Yes)
  } catch {
    $a = Read-Host ($text + ' [y/N]')
    return ($a -match '^(y|yes|是|好)$')
  }
}

function Get-VersionNumber([string]$raw) {
  $m = [regex]::Match([string]$raw, '\d+\.\d+\.\d+')
  if ($m.Success) { return $m.Value }
  return ''
}

function Compare-Ver([string]$a, [string]$b) {
  try {
    return ([version]$a).CompareTo([version]$b)
  } catch {
    return 999
  }
}

function Resolve-Claude {
  $cmd = Get-Command claude.exe -ErrorAction SilentlyContinue
  if (-not $cmd) { $cmd = Get-Command claude -ErrorAction SilentlyContinue }
  if (-not $cmd) { throw '找不到 claude 命令，请确认 Claude Code 已安装' }
  if ($cmd.Source) { return [string]$cmd.Source }
  return [string]$cmd.Path
}

function Detect-Method([string]$claude) {
  $p = ([string]$claude).Replace('/', '\').ToLowerInvariant()
  if ($p -match '\\winget\\links\\' -or $p -match '\\winget\\packages\\') { return 'winget' }
  if ($p -match '\\\.local\\bin\\') { return 'native' }
  if ($p -match '\\claude\.(cmd|ps1)$') { return 'npm' }
  if ($p -match '\\npm\\' -or $p -match '\\node_modules\\') { return 'npm' }
  return 'unknown'
}

function Stop-WorkbenchProcesses {
  Log '正在停止工作台和 CLI 进程…'
  $procs = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue
  foreach ($p in $procs) {
    $name = [string]$p.Name
    $cmd = [string]$p.CommandLine
    $kill = $false
    if ($name -ieq 'claude.exe' -and $cmd -match '--input-format\s+stream-json') { $kill = $true }
    if ($name -match '^(electron|electron-workbench)\.exe$' -and $cmd -match 'claude-gui|AI_Claude') { $kill = $true }
    if ($name -ieq 'node.exe' -and $cmd -match 'server\.js' -and $cmd -match 'claude-gui|AI_Claude') { $kill = $true }
    if ($kill) {
      Log ('停止进程 ' + $name + ' PID ' + $p.ProcessId)
      Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
    }
  }
  Start-Sleep -Seconds 2
}

function Restart-Workbench {
  if ($NoRestart) { return }
  $root = $InstallDir
  if (-not $root) {
    $leaf = Split-Path -Leaf $PSScriptRoot
    if ($leaf -ieq 'tools') {
      $root = Split-Path -Parent $PSScriptRoot
    } elseif ($leaf -ieq 'update' -and (Split-Path -Leaf (Split-Path -Parent $PSScriptRoot)) -ieq 'deploy') {
      $root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
    } else {
      $root = Split-Path -Parent $PSScriptRoot
    }
  }
  $vbs = Join-Path $root '启动界面.vbs'
  $cmd = Join-Path $root '启动工作台.cmd'
  try {
    if (Test-Path -LiteralPath $vbs) {
      Log '正在重新启动工作台…'
      Start-Process -FilePath 'wscript.exe' -ArgumentList ('"' + $vbs + '"') -WorkingDirectory $root -WindowStyle Hidden
    } elseif (Test-Path -LiteralPath $cmd) {
      Log '正在重新启动工作台…'
      Start-Process -FilePath $cmd -WorkingDirectory $root -WindowStyle Normal
    } else {
      Log ('没有找到启动器：' + $root)
    }
  } catch {
    Log ('重新启动工作台失败：' + $_.Exception.Message)
  }
}

function Run-Upgrade([string]$claude, [string]$method, [string]$target) {
  if ($method -eq 'winget') {
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $winget) { throw '找不到 winget.exe' }
    Log '使用 WinGet 升级 Claude Code…'
    $out = & $winget.Source upgrade --id Anthropic.ClaudeCode --accept-source-agreements --accept-package-agreements --disable-interactivity 2>&1
    $rc = $LASTEXITCODE
    $out | ForEach-Object { Log ([string]$_) }
    if ($rc -ne 0) { throw ('WinGet 升级失败，退出码 ' + $rc) }
    return
  }

  if ($method -eq 'npm') {
    $npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
    if (-not $npm) { $npm = Get-Command npm -ErrorAction SilentlyContinue }
    if (-not $npm) { throw '找不到 npm' }
    Log '使用 npm 升级 Claude Code…'
    $out = & $npm.Source install -g ('@anthropic-ai/claude-code@' + $target) 2>&1
    $rc = $LASTEXITCODE
    $out | ForEach-Object { Log ([string]$_) }
    if ($rc -ne 0) { throw ('npm 升级失败，退出码 ' + $rc) }
    return
  }

  Log '使用 claude install 升级 Claude Code…'
  $out = & $claude install $target --force 2>&1
  $rc = $LASTEXITCODE
  $out | ForEach-Object { Log ([string]$_) }
  if ($rc -ne 0) { throw ('claude install 失败，退出码 ' + $rc) }
}

try {
  Log ('日志：' + $script:LogPath)
  $claude = Resolve-Claude
  $method = Detect-Method $claude
  Log ('claude：' + $claude)
  Log ('安装方式：' + $method)

  $raw = & $claude --version 2>&1 | Out-String
  $current = Get-VersionNumber $raw
  if (-not $current) { throw ('读不到当前版本：' + $raw.Trim()) }
  Log ('当前版本：' + $current)

  if (-not $Version) {
    Log '正在获取最新版本…'
    try {
      $Version = (Invoke-WebRequest -UseBasicParsing -Uri 'https://downloads.claude.ai/claude-code-releases/latest' -TimeoutSec 20).Content.Trim()
    } catch {
      throw ('获取最新版本失败：' + $_.Exception.Message)
    }
  }
  if ($Version -notmatch '^\d+\.\d+\.\d+$') { throw ('版本号无效：' + $Version) }
  Log ('目标版本：' + $Version)

  if ((Compare-Ver $current $Version) -ge 0) {
    $msg = 'Claude Code CLI 已是最新版本：' + $current
    Log $msg
    if (-not $CheckOnly) { Show-Msg $msg 'Claude Code CLI' 'Information' }
    exit 0
  }

  if ($CheckOnly) {
    Log ('可升级：' + $current + ' -> ' + $Version + '（' + $method + '）')
    exit 0
  }

  $warn = "将升级 Claude Code CLI：$current -> $Version`n`n安装方式：$method`n下载约 403MB，国内直连可能 25–50 分钟。`n升级期间工作台会关闭，完成后自动重新打开。`n`n继续？"
  if (-not (Ask-YesNo $warn 'Claude Code CLI 升级')) {
    Log '用户取消升级'
    exit 0
  }

  $script:NeedRestart = $true
  Start-Sleep -Seconds 2
  Stop-WorkbenchProcesses
  Run-Upgrade $claude $method $Version

  Log '正在校验升级结果…'
  $claude2 = Resolve-Claude
  $raw2 = & $claude2 --version 2>&1 | Out-String
  $after = Get-VersionNumber $raw2
  Log ('升级后版本：' + $after)
  if ($after -ne $Version) {
    throw ('升级后版本是 ' + $after + '，期望 ' + $Version)
  }

  $ok = 'Claude Code CLI 已升级到 ' + $after
  Log $ok
  Restart-Workbench
  Show-Msg ($ok + "`n`n日志：`n" + $script:LogPath) 'Claude Code CLI 升级完成' 'Information'
  exit 0
} catch {
  $msg = 'Claude Code CLI 升级失败：' + $_.Exception.Message
  Log $msg
  if ($script:NeedRestart) { Restart-Workbench }
  Show-Msg ($msg + "`n`n日志：`n" + $script:LogPath) 'Claude Code CLI 升级失败' 'Error'
  exit 1
}
