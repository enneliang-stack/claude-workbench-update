#!/usr/bin/env node
'use strict';

/**
 * dsh-pet 工作台集成补丁：
 *  1. 桌面 helper 不创建系统托盘图标（由 claude-gui 顶栏控制）；
 *  2. 右键菜单「查看余额」改走工作台 sidecar，避免 standalone 没有 balance provider 时提示不可用。
 *
 * 升级 dsh-pet（npm install dsh-pet@...）后重新运行本脚本即可。补丁文件会保留 .bak-dsh-pet-integration 备份。
 */

const fs = require('fs');
const path = require('path');

const pkg = path.join(__dirname, '..', 'node_modules', 'dsh-pet');
const helper = path.join(pkg, 'runtime', 'electron-helper', 'main.js');
const constants = path.join(pkg, 'runtime', 'electron-helper', 'constants.js');
const sprite = path.join(pkg, 'runtime', 'electron-helper', 'sprite.js');

function read(file) {
  try { return fs.readFileSync(file, 'utf8'); }
  catch (e) { throw new Error('找不到 dsh-pet 文件：' + file); }
}

function backup(file) {
  const bak = file + '.bak-dsh-pet-integration';
  try {
    if (!fs.existsSync(bak)) fs.copyFileSync(file, bak);
  } catch { /* ignore */ }
}

const report = { ok: true, helper: {}, constants: {}, sprite: {} };

let helperSrc = read(helper);
let helperChanged = false;

// 1) 关闭系统托盘
if (!helperSrc.includes('DSH_PET_NO_TRAY')) {
  const needle = 'async function startTray() {\n  try {';
  if (!helperSrc.includes(needle)) {
    throw new Error('未找到 startTray 模板；dsh-pet 版本可能已变化，请手动检查：' + helper);
  }
  helperSrc = helperSrc.replace(needle, [
    'async function startTray() {',
    '  // 本集成由 claude-gui 的桌宠按钮控制显示；不需要额外的系统托盘图标。',
    "  if (process.env.DSH_PET_NO_TRAY === '1') return;",
    '  try {'
  ].join('\n'));
  helperChanged = true;
}

// 2) 右键「查看余额」→ 工作台 sidecar
if (!helperSrc.includes('DSH_PET_SIDECAR_BALANCE')) {
  const anchor = '  const url = new URL(request.url); // dsh-pet-bridge://dsh-pet/dsh-pet-7340/...';
  if (!helperSrc.includes(anchor)) {
    throw new Error('未找到 handleBridgeRequest 模板；dsh-pet 版本可能已变化，请手动检查：' + helper);
  }
  const route = [
    '  // DSH_PET_SIDECAR_BALANCE：右键菜单「查看余额」走工作台 sidecar 的余额接口。',
    '  // standalone 本身没有 balance provider，直接打 /dsh-pet-7340/balance 会提示不可用。',
    '  if (url.pathname === "/sidecar-balance") {',
    '    for (let port = 4780; port <= 4789; port += 1) {',
    '      const ctrl = new AbortController();',
    '      const timer = setTimeout(() => ctrl.abort(), 12000);',
    '      try {',
    '        const resp = await fetch("http://127.0.0.1:" + port + "/api/balance?refresh=1", { signal: ctrl.signal });',
    '        const text = await resp.text();',
    '        let data = null;',
    '        try { data = JSON.parse(text); } catch { /* ignore */ }',
    '        if (resp.ok && data && data.ok) {',
    '          return new Response(text, {',
    '            status: 200,',
    '            headers: { "content-type": "application/json", "access-control-allow-origin": "*" }',
    '          });',
    '        }',
    '      } catch { /* try next port */ }',
    '      finally { clearTimeout(timer); }',
    '    }',
    '    return new Response(JSON.stringify({ ok: false, error: "桌宠服务未连接，请先打开工作台桌宠" }), {',
    '      status: 502,',
    '      headers: { "content-type": "application/json", "access-control-allow-origin": "*" }',
    '    });',
    '  }'
  ].join('\n');
  helperSrc = helperSrc.replace(anchor, anchor + '\n\n' + route);
  helperChanged = true;
}

if (helperChanged) {
  backup(helper);
  fs.writeFileSync(helper, helperSrc, 'utf8');
  report.helper.patched = true;
} else {
  report.helper.already = true;
}

let constantsSrc = read(constants);
if (!constantsSrc.includes('SIDECAR_BALANCE_URL')) {
  const needle = "const BALANCE_URL = BASE + '/balance'; // 余额刷新动作（POST，写 S；数据本身从 /state 读）";
  if (!constantsSrc.includes(needle)) {
    throw new Error('未找到 BALANCE_URL 定义；dsh-pet 版本可能已变化，请手动检查：' + constants);
  }
  constantsSrc = constantsSrc.replace(
    needle,
    needle + "\nconst SIDECAR_BALANCE_URL = BRIDGE ? 'dsh-pet-bridge://dsh-pet/sidecar-balance' : BALANCE_URL;"
  );
  backup(constants);
  fs.writeFileSync(constants, constantsSrc, 'utf8');
  report.constants.patched = true;
} else {
  report.constants.already = true;
}

let spriteSrc = read(sprite);
if (!spriteSrc.includes('SIDECAR_BALANCE_URL')) {
  const needle = 'S.postAction(BALANCE_URL)';
  if (!spriteSrc.includes(needle)) {
    throw new Error('未找到 show-balance 菜单动作；dsh-pet 版本可能已变化，请手动检查：' + sprite);
  }
  spriteSrc = spriteSrc.replace(needle, 'S.postAction(SIDECAR_BALANCE_URL)');
  backup(sprite);
  fs.writeFileSync(sprite, spriteSrc, 'utf8');
  report.sprite.patched = true;
} else {
  report.sprite.already = true;
}

console.log(JSON.stringify(report));
