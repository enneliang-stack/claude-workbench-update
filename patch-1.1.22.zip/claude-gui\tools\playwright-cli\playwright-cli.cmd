@echo off
setlocal
set "NODE=%~dp0..\..\..\runtime\node.exe"
if not exist "%NODE%" set "NODE=%LOCALAPPDATA%\Jinxiaoman\codex-node\node-v22.23.4-win-x64\node.exe"
if not exist "%NODE%" set "NODE=node"
"%NODE%" "%~dp0playwright-cli.js" %*
