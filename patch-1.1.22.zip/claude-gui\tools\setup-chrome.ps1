﻿# Claude 工作台 —— Chrome 检测 / 安装目录配置
#
# 一键更新包在更新完客户端后调用；也可以单独运行：
#   powershell -NoProfile -ExecutionPolicy Bypass -File setup-chrome.ps1
#   powershell -NoProfile -ExecutionPolicy Bypass -File setup-chrome.ps1 -InstallDir "D:\AI_Claude"
#
# 已安装 Chrome 时让用户确认或改选安装目录；没有 Chrome 时可以下载
# Chrome for Testing 便携版到用户选择的目录，供工作台顶栏和 playwright-cli 使用。

param(
  [string]$InstallDir = '',
  [switch]$CheckOnly,
  [switch]$NoGui,
  [switch]$UseDetected
)

$ErrorActionPreference = 'Stop'
$script:Gui = -not $NoGui

function Log([string]$msg) {
  Write-Host ("[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $msg)
}

function Show-Message([string]$msg, [string]$icon = 'Information') {
  if (-not $script:Gui) { return }
  try {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
    $kind = [System.Windows.Forms.MessageBoxIcon]::Information
    if ($icon -eq 'Error') { $kind = [System.Windows.Forms.MessageBoxIcon]::Error }
    elseif ($icon -eq 'Question') { $kind = [System.Windows.Forms.MessageBoxIcon]::Question }
    [void][System.Windows.Forms.MessageBox]::Show($msg, 'Claude 工作台 - Chrome',
      [System.Windows.Forms.MessageBoxButtons]::OK, $kind)
  } catch { }
}

function Ask-YesNo([string]$msg) {
  if ($UseDetected) { return $true }
  if ($script:Gui) {
    try {
      Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
      $r = [System.Windows.Forms.MessageBox]::Show($msg, 'Claude 工作台 - Chrome',
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question,
        [System.Windows.Forms.MessageBoxDefaultButton]::Button1)
      return ($r -eq [System.Windows.Forms.DialogResult]::Yes)
    } catch { }
  }
  $a = Read-Host ($msg + ' [Y/n]')
  return ($a -notmatch '^(n|no|否|不)$')
}

function Select-Folder([string]$description) {
  if ($script:Gui) {
    try {
      Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
      $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
      $dialog.Description = $description
      $dialog.ShowNewFolderButton = $true
      if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        return $dialog.SelectedPath
      }
      return ''
    } catch { }
  }
  $p = Read-Host ($description + '（直接回车取消）')
  if ($p) { return $p }
  return ''
}

function Find-InstallDir([string]$hint) {
  $candidates = New-Object System.Collections.Generic.List[string]
  if ($hint) { $candidates.Add($hint) }
  if ($env:CLAUDE_WORKBENCH_DIR) { $candidates.Add($env:CLAUDE_WORKBENCH_DIR) }
  if ($PSScriptRoot) { $candidates.Add((Split-Path -Parent $PSScriptRoot)) }
  if ($env:LOCALAPPDATA) { $candidates.Add((Join-Path $env:LOCALAPPDATA 'Programs\AI_Claude')) }
  $candidates.Add('E:\AI_Claude')
  $candidates.Add('D:\AI_Claude')
  $candidates.Add('C:\AI_Claude')
  $regKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\{69C6605A-8A3A-4C8D-BDB7-780404135C1E}_is1'
  try {
    $loc = (Get-ItemProperty -Path $regKey -ErrorAction Stop).InstallLocation
    if ($loc) { $candidates.Add([string]$loc) }
  } catch { }
  foreach ($c in $candidates) {
    if (-not $c) { continue }
    try {
      $full = [IO.Path]::GetFullPath($c)
      if (Test-Path -LiteralPath (Join-Path $full 'claude-gui\server.js')) { return $full }
    } catch { }
  }
  return ''
}

function Resolve-ChromeExe([string]$inputPath) {
  if (-not $inputPath) { return '' }
  $candidates = @($inputPath)
  if (Test-Path -LiteralPath $inputPath -PathType Container) {
    $candidates += @(
      (Join-Path $inputPath 'chrome.exe'),
      (Join-Path $inputPath 'Application\chrome.exe'),
      (Join-Path $inputPath 'chrome-win64\chrome.exe'),
      (Join-Path $inputPath 'chrome-win32\chrome.exe')
    )
  }
  foreach ($c in $candidates) {
    if (Test-Path -LiteralPath $c -PathType Leaf) {
      try { return (Resolve-Path -LiteralPath $c).Path } catch { return $c }
    }
  }
  return ''
}

function Get-ChromeConfigPath([string]$dir) {
  return (Join-Path $dir 'claude-gui\data\chrome-path.json')
}

function Read-ChromeConfig([string]$dir) {
  $file = Get-ChromeConfigPath $dir
  if (-not (Test-Path -LiteralPath $file)) { return $null }
  try {
    return (Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json)
  } catch { return $null }
}

function Find-Chrome([string]$dir) {
  $cfg = Read-ChromeConfig $dir
  if ($cfg) {
    $fromConfig = Resolve-ChromeExe ([string]$cfg.path)
    if (-not $fromConfig) { $fromConfig = Resolve-ChromeExe ([string]$cfg.dir) }
    if ($fromConfig) { return $fromConfig }
  }
  $candidates = @(
    $env:CHROME_PATH,
    (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:PROGRAMFILES 'Google\Chrome\Application\chrome.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe')
  )
  foreach ($c in $candidates) {
    if (-not $c) { continue }
    $exe = Resolve-ChromeExe $c
    if ($exe) { return $exe }
  }
  return ''
}

function Save-ChromePath([string]$dir, [string]$exe, [string]$source) {
  $file = Get-ChromeConfigPath $dir
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $file) | Out-Null
  $data = [ordered]@{
    path = $exe
    dir = (Split-Path -Parent $exe)
    source = $source
    updatedAt = (Get-Date).ToString('o')
  }
  $json = $data | ConvertTo-Json
  [IO.File]::WriteAllText($file, $json, (New-Object System.Text.UTF8Encoding($false)))
  Log ('已保存 Chrome 路径：' + $exe)
}

function Install-ChromeForTesting([string]$targetDir) {
  $metaUrl = 'https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json'
  Log '正在读取 Chrome for Testing 版本信息…'
  $meta = Invoke-RestMethod -Uri $metaUrl -UseBasicParsing -TimeoutSec 60
  $stable = $meta.channels.Stable
  if (-not $stable -or -not $stable.version) { throw '版本信息里没有 Stable 通道' }
  $download = $stable.downloads.chrome | Where-Object { $_.platform -eq 'win64' } | Select-Object -First 1
  if (-not $download -or -not $download.url) { throw '没有找到 win64 下载地址' }

  $zip = Join-Path $env:TEMP ('chrome-for-testing-' + [guid]::NewGuid().ToString('N') + '.zip')
  try {
    Log ('正在下载 Chrome for Testing ' + $stable.version + '（约 150MB）…')
    Invoke-WebRequest -Uri $download.url -OutFile $zip -UseBasicParsing -TimeoutSec 1800
    Log ('正在解压到：' + $targetDir)
    New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
    Expand-Archive -LiteralPath $zip -DestinationPath $targetDir -Force
  } finally {
    Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
  }

  $exe = Resolve-ChromeExe $targetDir
  if (-not $exe) { throw '解压完成，但没有在目标目录里找到 chrome.exe' }
  return $exe
}

# ------------------------------------------------------------------ 主流程

$dir = Find-InstallDir $InstallDir
if (-not $dir) {
  Show-Message '找不到 Claude 工作台安装目录。请选择包含 claude-gui 文件夹的安装目录。' 'Error'
  $dir = Select-Folder '选择 Claude 工作台安装目录（包含 claude-gui 文件夹）'
  if (-not $dir -or -not (Test-Path -LiteralPath (Join-Path $dir 'claude-gui\server.js'))) {
    Log '没有找到工作台安装目录，跳过 Chrome 配置。'
    exit 1
  }
}
Log ('工作台安装目录：' + $dir)

$chrome = Find-Chrome $dir
if ($chrome) {
  Log ('检测到 Chrome：' + $chrome)
  if ($CheckOnly) { exit 0 }

  if ($UseDetected -or (Ask-YesNo ("检测到 Chrome：`n" + $chrome + "`n`n直接使用这个 Chrome 吗？选择「否」可以指定其他安装目录。"))) {
    Save-ChromePath $dir $chrome 'detected'
    exit 0
  }

  $picked = Select-Folder '选择 Chrome 安装目录（chrome.exe 所在目录或其上层目录）'
  $pickedExe = Resolve-ChromeExe $picked
  if ($pickedExe) {
    Save-ChromePath $dir $pickedExe 'selected'
    exit 0
  }
  Show-Message '所选目录里没有 chrome.exe，已保留原来的 Chrome 路径。' 'Error'
  exit 1
}

if ($CheckOnly) {
  Log '没有检测到 Chrome。'
  exit 1
}

$wantDownload = Ask-YesNo '没有检测到 Chrome。是否下载 Chrome for Testing 便携版到您选择的目录？'
if ($wantDownload) {
  $target = Select-Folder '选择 Chrome 安装目录（会把 Chrome for Testing 解压到这里）'
  if (-not $target) {
    Log '已取消选择 Chrome 安装目录。'
    exit 1
  }
  try {
    $chrome = Install-ChromeForTesting $target
    Save-ChromePath $dir $chrome 'chrome-for-testing'
    Show-Message ('Chrome 已安装到：`n' + $chrome + "`n`n工作台顶栏的浏览器按钮和 playwright-cli 会使用它。")
    exit 0
  } catch {
    Log ('下载/安装 Chrome 失败：' + $_.Exception.Message)
    Show-Message ('自动下载 Chrome 失败：' + $_.Exception.Message + "`n`n可以手动安装 Chrome：https://www.google.com/chrome/`n安装后重新运行本脚本，或在工作台顶栏点浏览器按钮选择安装目录。") 'Error'
    exit 1
  }
}

$picked = Select-Folder '选择已安装的 Chrome 安装目录（chrome.exe 所在目录或其上层目录）'
$pickedExe = Resolve-ChromeExe $picked
if ($pickedExe) {
  Save-ChromePath $dir $pickedExe 'selected'
  exit 0
}

Log '没有配置 Chrome。之后可以在工作台顶栏点浏览器按钮，选择 Chrome 安装目录。'
Show-Message "没有配置 Chrome。`n`n请先安装 Chrome：https://www.google.com/chrome/`n装好后点工作台顶栏的浏览器按钮，选择 Chrome 安装目录即可。"
exit 0
