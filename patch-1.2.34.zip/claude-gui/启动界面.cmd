@echo off
chcp 65001 >nul
cd /d "%~dp0"

rem 优先用 wscript 启动：不创建控制台窗口，关闭启动窗口也不会结束工作台。
rem Prefer the runtimes bundled with this installation.
set "PATH=%USERPROFILE%\.local\bin;%~dp0..\runtime;%~dp0..\git\cmd;%PATH%"
set "CLAUDE_CODE_GIT_BASH_PATH=%~dp0..\git\bin\bash.exe"

if not exist "desktop\node_modules\electron\dist\electron.exe" if not exist "desktop\node_modules\electron\dist\electron-workbench.exe" (
  echo.
  echo   Electron 未安装，请重新运行安装包。
  echo.
  pause
  exit /b 1
)

if exist "%~dp0启动界面.vbs" (
  wscript.exe //nologo "%~dp0启动界面.vbs"
) else (
  start "Claude Workbench" "%~dp0desktop\node_modules\electron\dist\electron.exe" "%~dp0desktop"
)
