'use strict';

/**
 * Claude 工作台 —— 真实 Chrome 启动/聚焦
 *
 * 顶栏浏览器按钮：
 *   1. 使用专用 profile 启动本机真实 Chrome（保持登录态）；
 *   2. 开启 CDP 9222；
 *   3. 以 msedge 会话名 attach，后续 playwright-cli 命令照旧可用。
 *
 * 幂等：Chrome 已在跑、会话已 attach 时直接返回并聚焦窗口。
 * 输出最后一行 JSON，供工作台主服务解析。
 */

const fs = require('fs');
const path = require('path');
const { spawn, spawnSync } = require('child_process');

const PORT = Number(process.env.CHROME_DEBUG_PORT || 9222);
const SESSION = 'msedge';
const PROFILE = process.env.CHROME_PROFILE_DIR ||
  path.join(process.env.LOCALAPPDATA || '', 'ClaudeWorkbenchChrome');
const CLI_CWD = path.join(__dirname, '..');
const CHROME_CONFIG = path.join(__dirname, 'data', 'chrome-path.json');

function readChromeConfig() {
  try {
    const data = JSON.parse(fs.readFileSync(CHROME_CONFIG, 'utf8'));
    if (!data || typeof data !== 'object') return null;
    const pathValue = typeof data.path === 'string' ? data.path.trim() : '';
    const dirValue = typeof data.dir === 'string' ? data.dir.trim() : '';
    return pathValue || dirValue ? { path: pathValue, dir: dirValue } : null;
  } catch {
    return null;
  }
}

// 用户可能选择 chrome.exe，也可能选择 Application / Google\Chrome / 便携版目录。
function resolveChromeExe(input) {
  if (!input) return '';
  const candidates = [input];
  try {
    if (fs.statSync(input).isDirectory()) {
      candidates.push(
        path.join(input, 'chrome.exe'),
        path.join(input, 'Application', 'chrome.exe'),
        path.join(input, 'chrome-win64', 'chrome.exe'),
        path.join(input, 'chrome-win32', 'chrome.exe')
      );
    }
  } catch { /* 不存在时只按文件路径判断 */ }
  return candidates.find(file => {
    try { return fs.statSync(file).isFile(); } catch { return false; }
  }) || '';
}

function findChrome() {
  const config = readChromeConfig();
  const configured = config ? resolveChromeExe(config.path || config.dir) : '';
  if (configured) return configured;

  const chromeRoots = [
    process.env.LOCALAPPDATA || '',
    process.env.PROGRAMFILES || '',
    process.env['PROGRAMFILES(X86)'] || ''
  ].filter(Boolean);
  const chromeChannels = ['Chrome', 'Chrome Beta', 'Chrome Dev', 'Chrome SxS'];
  const candidates = [
    process.env.CHROME_PATH,
    ...chromeRoots.flatMap(root => chromeChannels.map(channel =>
      path.join(root, 'Google', channel, 'Application', 'chrome.exe')))
  ].filter(Boolean);
  return candidates.map(resolveChromeExe).find(Boolean) || '';
}

function findCli() {
  const fromEnv = process.env.PLAYWRIGHT_CLI;
  if (fromEnv && fs.existsSync(fromEnv)) return fromEnv;

  const exts = process.platform === 'win32' ? ['.cmd', '.exe', ''] : [''];
  const dirs = (process.env.PATH || '').split(path.delimiter).filter(Boolean);
  const known = [
    path.join(__dirname, 'tools', 'playwright-cli'),
    path.join(process.env.APPDATA || '', 'npm')
  ].filter(Boolean);

  for (const dir of [...dirs, ...known]) {
    for (const ext of exts) {
      const candidate = path.join(dir, 'playwright-cli' + ext);
      try {
        if (fs.existsSync(candidate)) return candidate;
      } catch { /* ignore */ }
    }
  }
  return 'playwright-cli';
}

function runCli(args, timeout = 60000) {
  const cli = findCli();
  const command = /\s/.test(cli) ? `"${cli}"` : cli;
  const result = spawnSync(command, args, {
    cwd: CLI_CWD,
    windowsHide: true,
    shell: process.platform === 'win32',
    encoding: 'utf8',
    timeout
  });
  return {
    code: typeof result.status === 'number' ? result.status : -1,
    out: result.stdout || '',
    err: result.stderr || (result.error ? result.error.message : '')
  };
}

function parseJsonObject(text) {
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('无法解析 playwright-cli 输出');
  return JSON.parse(text.slice(start, end + 1));
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function getJson(url, timeout = 1500) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok) return null;
    return await response.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function chromeVersion() {
  const version = await getJson(`http://127.0.0.1:${PORT}/json/version`);
  if (!version) return null;
  return /Chrome\//i.test(version.Browser || '') ? version : null;
}

function listSessions() {
  const result = runCli(['list', '--json'], 8000);
  if (result.code !== 0) return [];
  try {
    const data = parseJsonObject(result.out);
    return Array.isArray(data.browsers) ? data.browsers : [];
  } catch {
    return [];
  }
}

function closeSession() {
  try { runCli(['-s=' + SESSION, 'close'], 15000); } catch { /* ignore */ }
}

function detachSession() {
  try { runCli(['-s=' + SESSION, 'detach'], 15000); } catch { /* ignore */ }
}

function sessionWorks() {
  const result = runCli(['-s=' + SESSION, 'tab-list'], 8000);
  return result.code === 0 && /(^|\n)-\s*\d+:/.test(result.out);
}

function attachSession() {
  const result = runCli([
    'attach',
    `--cdp=http://127.0.0.1:${PORT}`,
    `--session=${SESSION}`
  ], 60000);

  if (result.code === 0) return { ok: true, out: result.out };

  const detail = (result.err || result.out || '').trim();
  const sessions = listSessions();
  const attached = sessions.find(s => s.name === SESSION && s.attached && s.status === 'open');
  if (attached) return { ok: true, out: result.out };

  return { ok: false, error: detail || `attach 退出码 ${result.code}` };
}

async function waitForChrome(timeout = 30000) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    const version = await chromeVersion();
    if (version) return version;
    await sleep(300);
  }
  return null;
}

async function bringChromeToFront() {
  // 恢复并置前专用 profile 的 Chrome 窗口。
  // 单纯 SetForegroundWindow 会被 Windows 前台锁拦住，这里用 AttachThreadInput + 短暂 topmost 绕过。
  try {
    const ps = [
      `$procs = Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" | Where-Object { $_.CommandLine -like '*ClaudeWorkbenchChrome*' };`,
      `$w = $procs | ForEach-Object { Get-Process -Id $_.ProcessId -ErrorAction SilentlyContinue } | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1;`,
      `if ($w) {`,
      `Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public class WbFocus { [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow(); [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId); [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId(); [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach); [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow); [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd); [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd); [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags); }';`,
      `$fg = [WbFocus]::GetForegroundWindow();`,
      `$fgPid = 0;`,
      `$fgThread = [WbFocus]::GetWindowThreadProcessId($fg, [ref]$fgPid);`,
      `$myThread = [WbFocus]::GetCurrentThreadId();`,
      `[WbFocus]::AttachThreadInput($myThread, $fgThread, $true) | Out-Null;`,
      `[WbFocus]::ShowWindow($w.MainWindowHandle, 9) | Out-Null;`,
      `[WbFocus]::SetWindowPos($w.MainWindowHandle, [IntPtr](-1), 0, 0, 0, 0, 0x0043) | Out-Null;`,
      `[WbFocus]::SetWindowPos($w.MainWindowHandle, [IntPtr](-2), 0, 0, 0, 0, 0x0043) | Out-Null;`,
      `[WbFocus]::BringWindowToTop($w.MainWindowHandle) | Out-Null;`,
      `[WbFocus]::SetForegroundWindow($w.MainWindowHandle) | Out-Null;`,
      `[WbFocus]::AttachThreadInput($myThread, $fgThread, $false) | Out-Null`,
      `}`
    ].join(' ');
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], {
      windowsHide: true,
      stdio: 'ignore'
    });
    await new Promise(resolve => {
      const timer = setTimeout(resolve, 2500);
      child.on('close', () => { clearTimeout(timer); resolve(); });
      child.on('error', () => { clearTimeout(timer); resolve(); });
    });
  } catch { /* ignore */ }
}

async function main() {
  if (!fs.existsSync(PROFILE)) {
    try { fs.mkdirSync(PROFILE, { recursive: true }); } catch { /* ignore */ }
  }

  let launched = false;
  let version = await chromeVersion();

  if (!version) {
    const chromePath = findChrome();
    if (!chromePath) {
      const error = new Error('没有找到本机 Chrome（chrome.exe）');
      error.code = 'CHROME_NOT_FOUND';
      throw error;
    }

    const child = spawn(chromePath, [
      `--remote-debugging-port=${PORT}`,
      `--user-data-dir=${PROFILE}`,
      '--no-first-run',
      '--no-default-browser-check',
      '--remote-allow-origins=*',
      '--restore-last-session'
    ], {
      detached: true,
      stdio: 'ignore',
      windowsHide: false
    });
    child.unref();
    launched = true;

    version = await waitForChrome(30000);
    if (!version) {
      throw new Error(`真实 Chrome 已启动，但 CDP ${PORT} 端口未就绪；请检查是否有其他 Chrome 占用了专用 profile`);
    }
  } else if (!/Chrome\//i.test(version.Browser || '')) {
    throw new Error(`端口 ${PORT} 被其他浏览器占用：${version.Browser || '未知'}`);
  }

  const sessions = listSessions();
  const existing = sessions.find(s => s.name === SESSION && s.status === 'open');

  if (existing && existing.attached && sessionWorks()) {
    await bringChromeToFront();
    return { ok: true, session: SESSION, port: PORT, launched, reused: true, browser: version.Browser };
  }

  if (existing) {
    // 旧会话可能已失效（例如 Chrome 重启过）；断开后再接。
    if (existing.attached) detachSession();
    else closeSession();
    await sleep(600);
  }

  let attached = attachSession();
  if (!attached.ok) {
    // 可能是旧会话状态未清理，重试一次。
    detachSession();
    await sleep(500);
    attached = attachSession();
  }
  if (!attached.ok) {
    throw new Error(attached.error || '无法把真实 Chrome 接入 msedge 会话');
  }

  await bringChromeToFront();
  return { ok: true, session: SESSION, port: PORT, launched, browser: version.Browser };
}

main()
  .then(result => {
    process.stdout.write(JSON.stringify(result) + '\n');
    process.exit(0);
  })
  .catch(error => {
    const message = String(error && error.message ? error.message : error);
    process.stderr.write((error && error.code ? error.code + ': ' : '') + message + '\n');
    process.exit(1);
  });
