@echo off
setlocal
set "NODE=%~dp0..\..\..\runtime\node.exe"
if not exist "%NODE%" set "NODE=node"
"%NODE%" "%~dp0playwright-cli.js" %*
