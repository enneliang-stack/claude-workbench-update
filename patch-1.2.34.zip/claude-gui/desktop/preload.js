'use strict';

/**
 * 渲染进程与桌面客户端之间的桥。
 * 目前只用于输入框右键菜单里的原生编辑命令（剪切/复制/粘贴/全选），
 * 这样粘贴图片时也能走 Chromium 的原生剪贴板事件。
 */

const { contextBridge, ipcRenderer, webUtils } = require('electron');

const COMMANDS = new Set(['cut', 'copy', 'paste', 'selectAll']);

contextBridge.exposeInMainWorld('guiDesktop', {
  // 拖入文件/文件夹时拿到绝对路径（Electron 32+ 用 webUtils，旧版回退到 File.path）
  getPathForFile(file) {
    try {
      if (webUtils && typeof webUtils.getPathForFile === 'function') {
        return webUtils.getPathForFile(file) || '';
      }
    } catch { /* ignore */ }
    return (file && file.path) || '';
  },
  startUpdate(data) {
    if (!data || typeof data !== 'object') return Promise.resolve({ ok: false, error: '参数错误' });
    return ipcRenderer.invoke('gui:start-update', {
      manifestUrl: String(data.manifestUrl || ''),
      version: String(data.version || ''),
      notes: String(data.notes || ''),
      confirmed: !!data.confirmed
    });
  },
  pickReference(kind) {
    return ipcRenderer.invoke('gui:pick-reference', kind === 'folder' ? 'folder' : 'files');
  },
  pickChrome() {
    return ipcRenderer.invoke('gui:pick-chrome');
  },
  edit(cmd) {
    if (COMMANDS.has(cmd)) ipcRenderer.send('gui:edit', cmd);
  },
  setBusy(busy) {
    ipcRenderer.send('gui:busy', !!busy);
  },
  setAttention(count, summary) {
    ipcRenderer.send('gui:attention', { count: Number(count) || 0, summary: String(summary || '') });
  },
  notify(data) {
    if (!data || typeof data !== 'object') return;
    ipcRenderer.send('gui:notify', {
      title: String(data.title || ''),
      body: String(data.body || ''),
      convId: String(data.convId || '')
    });
  },
  onOpenConversation(callback) {
    if (typeof callback !== 'function') return;
    ipcRenderer.on('gui:open-conv', (_event, id) => {
      if (typeof id === 'string' && id) callback(id);
    });
  }
});
