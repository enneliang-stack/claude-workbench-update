@echo off
chcp 65001 >nul
cd /d "%~dp0"

rem 让工作台和 Claude Code 优先使用本安装包自带的组件，不污染其他环境。
set "PATH=%USERPROFILE%\.local\bin;%~dp0runtime;%~dp0git\cmd;%PATH%"
set "CLAUDE_CODE_GIT_BASH_PATH=%~dp0git\bin\bash.exe"

if not exist "%~dp0claude-gui\启动界面.vbs" if not exist "%~dp0claude-gui\启动界面.cmd" (
  echo.
  echo   找不到 claude-gui，安装可能不完整。
  echo.
  pause
  exit /b 1
)

rem 用 wscript 启动，避免把 Electron 挂在这个控制台窗口上：
rem 关闭这个窗口不会退出工作台，也不会出现 cmd 的报错提示。
if exist "%~dp0claude-gui\启动界面.vbs" (
  wscript.exe //nologo "%~dp0claude-gui\启动界面.vbs"
) else (
  start "Claude Workbench" "%~dp0claude-gui\启动界面.cmd"
)
