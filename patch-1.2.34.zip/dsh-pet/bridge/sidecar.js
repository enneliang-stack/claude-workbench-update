'use strict';

/**
 * dsh-pet sidecar —— 独立于 claude-gui 的桌宠管理服务。
 *
 * 职责：
 *   1. 按需启动 / 停止 dsh-pet standalone（透明置顶桌面宠物窗）。
 *   2. 接收 Claude Code hook 发来的状态，转发到 dsh-pet 的 /work-status。
 *   3. 给 claude-gui 前端提供 /api/pet/* 接口（仅本机、仅 localhost CORS）。
 *
 * 只使用 Node 内置模块，和 claude-gui 一样零依赖。
 */

const http = require('http');
const net = require('net');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn, spawnSync } = require('child_process');

const APP_DIR = path.resolve(__dirname, '..');
const PET_PKG_DIR = path.join(APP_DIR, 'node_modules', 'dsh-pet');
const PET_SCRIPT = path.join(PET_PKG_DIR, 'lib', 'standalone.js');
const ELECTRON_EXE = process.env.DSH_PET_ELECTRON_PATH || path.join(APP_DIR, 'runtime', 'electron', 'electron.exe');
const DSH_HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh');
const RUNTIME_DIR = path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'dsh-pet-bridge');
const RUNTIME_FILE = path.join(RUNTIME_DIR, 'runtime.json');
const LOG_FILE = path.join(RUNTIME_DIR, 'sidecar.log');
const PET_RUNTIME_FILE = path.join(DSH_HOME, 'dsh-pet', 'standalone-runtime.json');

const APP_NAME = 'dsh-pet-bridge';
const BASE_PORT = 4780;
const PORT_TRIES = 10;
const PET_PORT_START = 3090;
const PET_PORT_TRIES = 20;
const PET_ROUTE = '/dsh-pet-7340';
const WORK_STATES = new Set(['thinking', 'working', 'result', 'waiting', 'success', 'error']);

// Claude Code hook 事件 → 桌宠状态。HTTP hook 直接把原始事件 POST 到这里，
// 由 sidecar 解析，省掉每个事件启一次 node/powershell 的进程开销。
const HOOK_EVENTS = new Set([
  'UserPromptSubmit', 'PreToolUse', 'PostToolUse', 'PostToolUseFailure',
  'Stop', 'StopFailure', 'Notification', 'SessionEnd',
  'SubagentStart', 'SubagentStop'
]);

const HOOK_STATE = {
  UserPromptSubmit: 'thinking',
  PreToolUse: 'working',
  PostToolUse: 'result',
  PostToolUseFailure: 'error',
  Stop: 'success',
  StopFailure: 'error',
  SessionEnd: 'clear',
  SubagentStart: 'working',
  SubagentStop: 'result'
};

const HOOK_TOOL_LABEL = {
  Bash: '敲命令',
  PowerShell: '敲命令',
  Read: '翻文件',
  Write: '改代码',
  Edit: '改代码',
  MultiEdit: '改代码',
  Glob: '搜文件',
  Grep: '搜文件',
  WebSearch: '上网查',
  WebFetch: '上网查',
  Task: '开小差',
  Agent: '开小差'
};

// claude-gui 本地服务端口范围（server.js 从 4711 起最多试 24 个）。
const CLIENT_PORT_START = 4711;
const CLIENT_PORT_TRIES = 24;
const CLIENT_POLL_MS = 2000;
const CLIENT_GONE_MS = 5000;

let serverPort = null;
let petProc = null;
let petPort = null;
let petToken = null;
let petStarting = null;
let lastState = null;
let stateQueue = Promise.resolve();
let balanceCache = null;
let shuttingDown = false;

// 客户端生命周期：claude-gui 关掉后 sidecar 也跟着退出（桌宠随之结束）。
let clientPort = null;
let clientSeenAt = 0;
let clientLastSeenAt = 0;
let clientGoneHandled = false;
let clientWatchTimer = null;

function log(...args) {
  const line = `[${new Date().toISOString()}] ${args.map(String).join(' ')}`;
  try {
    fs.mkdirSync(RUNTIME_DIR, { recursive: true });
    fs.appendFileSync(LOG_FILE, line + '\n');
  } catch { /* ignore */ }
  try { console.log(line); } catch { /* ignore */ }
}

function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

function requestJson(url, options = {}) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(url); } catch (e) { reject(e); return; }
    const body = options.body === undefined ? null : Buffer.from(JSON.stringify(options.body));
    const req = http.request({
      hostname: u.hostname,
      port: u.port || 80,
      path: u.pathname + u.search,
      method: options.method || 'GET',
      headers: {
        ...(body ? { 'content-type': 'application/json', 'content-length': body.length } : {}),
        ...(options.headers || {})
      },
      timeout: options.timeout || 1500
    }, res => {
      const chunks = [];
      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString('utf8') }));
    });
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

function sendJson(res, obj, code = 200) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'content-length': Buffer.byteLength(body)
  });
  res.end(body);
}

function applyCors(req, res) {
  const origin = req.headers.origin;
  if (origin && /^http:\/\/(?:127\.0\.0\.1|localhost):\d+$/.test(origin)) {
    res.setHeader('access-control-allow-origin', origin);
    res.setHeader('vary', 'Origin');
  }
  res.setHeader('access-control-allow-methods', 'GET,POST,OPTIONS');
  res.setHeader('access-control-allow-headers', 'Content-Type');
}

function readBody(req, limit = 8 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', chunk => {
      size += chunk.length;
      if (size > limit) { reject(new Error('body too large')); req.destroy(); return; }
      chunks.push(chunk);
    });
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw.trim()) { resolve({}); return; }
      try { resolve(JSON.parse(raw)); } catch { reject(new Error('invalid JSON')); }
    });
    req.on('error', reject);
  });
}

// hook 的 body 可能带很大的 tool_input / tool_response（Write 全文、Read 结果）。
// 只保留开头一小段用于取字段，其余读完即丢，避免每个事件都 JSON.parse 几 MB。
function readHookBody(req, limit = 64 * 1024) {
  return new Promise(resolve => {
    let head = '';
    req.setEncoding('utf8');
    req.on('data', chunk => {
      if (head.length < limit) head += chunk.slice(0, limit - head.length);
    });
    req.on('end', () => resolve(head));
    req.on('error', () => resolve(head));
  });
}

function jsonStringField(raw, name) {
  const m = new RegExp('"' + name + '"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"').exec(raw);
  if (!m) return '';
  try { return JSON.parse('"' + m[1] + '"'); } catch { return m[1]; }
}

function jsonBoolField(raw, name) {
  const m = new RegExp('"' + name + '"\\s*:\\s*(true|false)').exec(raw);
  return !!m && m[1] === 'true';
}

function decideHookState(event, payload) {
  if (event === 'Notification') {
    const kind = String(payload.notification_type || payload.type || '');
    // 只把“需要你处理”的通知映射成 waiting，避免闲置提醒也弹等待。
    if (!/permission|approval|elicitation|question|input/i.test(kind)) return null;
    return 'waiting';
  }
  if (event === 'Stop' && payload.stop_hook_active === true) return null;
  return HOOK_STATE[event] || null;
}

async function isSidecarOn(port) {
  try {
    const r = await requestJson(`http://127.0.0.1:${port}/api/health`, { timeout: 400 });
    if (r.status !== 200) return false;
    return JSON.parse(r.body).app === APP_NAME;
  } catch { return false; }
}

async function findExistingSidecar() {
  for (let p = BASE_PORT; p < BASE_PORT + PORT_TRIES; p += 1) {
    if (await isSidecarOn(p)) return p;
  }
  return null;
}

async function isClaudeGui(port) {
  try {
    const r = await requestJson(`http://127.0.0.1:${port}/api/ping`, { timeout: 500 });
    if (r.status !== 200) return false;
    const data = JSON.parse(r.body);
    return !!(data && data.app === 'claude-gui');
  } catch { return false; }
}

async function findClaudeGui() {
  if (clientPort && await isClaudeGui(clientPort)) return clientPort;
  for (let p = CLIENT_PORT_START; p < CLIENT_PORT_START + CLIENT_PORT_TRIES; p += 1) {
    if (await isClaudeGui(p)) { clientPort = p; return p; }
  }
  clientPort = null;
  return null;
}

function startClientWatch() {
  if (clientWatchTimer) return;
  clientWatchTimer = setInterval(async () => {
    if (shuttingDown) return;
    const port = await findClaudeGui();
    const now = Date.now();
    if (port) {
      if (!clientSeenAt) log(`claude-gui client detected on port ${port}`);
      if (clientGoneHandled) log('claude-gui client back; sidecar ready');
      clientGoneHandled = false;
      clientSeenAt = clientSeenAt || now;
      clientLastSeenAt = now;
      return;
    }
    if (clientSeenAt && !clientGoneHandled && now - clientLastSeenAt > CLIENT_GONE_MS) {
      clientGoneHandled = true;
      log('claude-gui client gone; stopping pet (sidecar stays for next client)');
      stopPet().catch(() => {});
    }
  }, CLIENT_POLL_MS);
  clientWatchTimer.unref?.();
}

function findFreePort(start, tries) {
  return new Promise((resolve, reject) => {
    let port = start;
    const attempt = () => {
      if (port >= start + tries) { reject(new Error('找不到空闲端口')); return; }
      const srv = net.createServer();
      srv.unref();
      srv.once('error', () => { port += 1; attempt(); });
      srv.once('listening', () => {
        const actual = srv.address().port;
        srv.close(() => resolve(actual));
      });
      srv.listen(port, '127.0.0.1');
    };
    attempt();
  });
}

async function petHealth(port) {
  if (!port) return false;
  try {
    const r = await requestJson(`http://127.0.0.1:${port}/health`, { timeout: 600 });
    return r.status === 200;
  } catch { return false; }
}

function petStatus() {
  return {
    running: !!petPort,
    port: petPort,
    pid: petProc ? petProc.pid : null,
    lastState
  };
}

async function fetchPetConfig() {
  if (!petPort) return null;
  try {
    const headers = petToken ? { 'x-dsh-pet-token': petToken } : {};
    const r = await requestJson(`http://127.0.0.1:${petPort}${PET_ROUTE}/config`, { timeout: 1000, headers });
    if (r.status !== 200) return null;
    return JSON.parse(r.body);
  } catch { return null; }
}

function petEntry(cfg) {
  const pets = cfg && cfg.main && Array.isArray(cfg.main.pets)
    ? cfg.main.pets
    : (Array.isArray(cfg && cfg.pets) ? cfg.pets : []);
  return pets.find(p => p && p.id === 'main') || pets[0] || null;
}

async function petDisplay() {
  const pet = petEntry(await fetchPetConfig());
  return pet ? String(pet.display || '') : null;
}

async function setPetDisplay(display) {
  if (!petPort) return { ok: false, reason: 'pet-not-running' };
  if (!petToken) return { ok: false, reason: 'pet-token-missing' };
  try {
    const r = await requestJson(`http://127.0.0.1:${petPort}${PET_ROUTE}/pet-display`, {
      method: 'POST',
      body: { id: 'main', display },
      headers: { 'x-dsh-pet-token': petToken },
      timeout: 2000
    });
    let data = null;
    try { data = JSON.parse(r.body || '{}'); } catch { /* ignore */ }
    if (r.status >= 200 && r.status < 300 && (!data || data.ok !== false) && !(data && data.error)) {
      return { ok: true, display };
    }
    return { ok: false, reason: (data && (data.reason || data.error)) || `pet-http-${r.status}` };
  } catch (e) {
    return { ok: false, reason: e.message };
  }
}

function readDeepSeekKey() {
  try {
    const settings = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.claude', 'settings.json'), 'utf8'));
    const env = settings && settings.env ? settings.env : {};
    const key = env.ANTHROPIC_AUTH_TOKEN || env.ANTHROPIC_API_KEY || env.DEEPSEEK_API_KEY;
    if (key) return String(key);
  } catch { /* fall through */ }
  return process.env.DEEPSEEK_API_KEY ? String(process.env.DEEPSEEK_API_KEY) : '';
}

function formatBalanceShort(result) {
  const info = result && Array.isArray(result.balances) ? result.balances[0] : null;
  if (!info) return result && result.isAvailable === false ? 'DeepSeek 余额不可用' : 'DeepSeek 余额暂时查不到';
  const symbol = info.currency === 'CNY' ? '¥' : info.currency === 'USD' ? '$' : '';
  return `DeepSeek 余额 ${symbol}${info.total_balance}`;
}

// dsh-pet 内置 DeepSeek provider 的「满额」基准，用来把余额换算成已用百分比。
// 与 node_modules/dsh-pet/lib/standalone.js 的 DEEPSEEK_FULL_BALANCE 保持一致。
const BALANCE_FULL = { CNY: 20, USD: 5 };

// 动作库的余额档位（按已用百分比分档）。真正播放的名字优先从桌宠 /config 的
// animations.events.balance 读取；这里只是配置缺失/数组变短时的兜底。
const BALANCE_TIER_FALLBACK = [
  '余额-钱袋满溢',
  '余额-金袋叮当',
  '余额-钱袋如常',
  '余额-数金皱眉',
  '余额-袋空如洗',
  '余额-分文不剩'
];

function balanceUsedPercent(result) {
  const list = result && Array.isArray(result.balances) ? result.balances : [];
  let remaining = 0;
  let based = 0;
  for (const info of list) {
    const currency = String((info && info.currency) || '').toUpperCase();
    const full = BALANCE_FULL[currency];
    const total = Number(info && info.total_balance);
    if (!Number.isFinite(total) || !Number.isFinite(full) || full <= 0) continue;
    remaining += total / full;
    based += 1;
  }
  if (based === 0) return undefined;
  return Math.max(0, Math.min(100, 100 - (remaining / based) * 100));
}

function balanceTierIndex(percent) {
  if (percent === 100) return 5;
  return Math.min(4, Math.floor(percent / 20));
}

function pickAnimationName(slot) {
  if (Array.isArray(slot)) {
    const candidates = slot.filter(name => typeof name === 'string' && name.trim() !== '');
    if (candidates.length === 0) return null;
    return candidates[Math.floor(Math.random() * candidates.length)];
  }
  return typeof slot === 'string' && slot.trim() !== '' ? slot : null;
}

async function showBalanceTierAnimation(result) {
  if (!petPort || !petToken) return;
  const cfg = await fetchPetConfig();
  const pet = petEntry(cfg);
  const display = pet ? String(pet.display || '') : '';
  if (display !== 'desktop' && display !== 'both') return;
  const percent = balanceUsedPercent(result);
  if (percent === undefined) return;
  const idx = balanceTierIndex(percent);
  const pool = cfg && cfg.main && cfg.main.animations && cfg.main.animations.events
    ? cfg.main.animations.events.balance
    : undefined;
  const slot = Array.isArray(pool) && pool[idx] !== undefined ? pool[idx] : BALANCE_TIER_FALLBACK[idx];
  const name = pickAnimationName(slot);
  if (!name) return;
  const petId = pet && pet.id ? String(pet.id) : 'main';
  try {
    const r = await requestJson(`http://127.0.0.1:${petPort}${PET_ROUTE}/anim?pet=${encodeURIComponent(petId)}&surface=desktop`, {
      method: 'POST',
      body: { name },
      headers: { 'x-dsh-pet-token': petToken },
      timeout: 2500
    });
    let data = null;
    try { data = JSON.parse(r.body || '{}'); } catch { /* ignore */ }
    const failed = r.status < 200 || r.status >= 300 || (data && data.ok === false);
    if (failed) {
      const reason = data && (data.reason || data.message || data.error);
      log(`balance tier anim failed: ${r.status} ${reason || String(r.body || '').slice(0, 120)}`);
    } else {
      log(`balance tier anim: p=${percent.toFixed(1)} -> ${name}`);
    }
  } catch (e) {
    log('balance tier anim error: ' + e.message);
  }
}

async function fetchBalance(force = false) {
  if (!force && balanceCache && Date.now() - balanceCache.at < 30e3) return balanceCache.data;
  const key = readDeepSeekKey();
  if (!key) return { ok: false, error: '未找到 DeepSeek API key（~/.claude/settings.json 的 ANTHROPIC_AUTH_TOKEN）' };

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  try {
    const res = await fetch('https://api.deepseek.com/user/balance', {
      headers: { authorization: `Bearer ${key}`, accept: 'application/json' },
      signal: ctrl.signal
    });
    if (!res.ok) return { ok: false, error: `余额接口 HTTP ${res.status}` };
    const data = await res.json();
    const balances = Array.isArray(data.balance_infos)
      ? data.balance_infos.map(info => ({
        currency: info.currency,
        total_balance: info.total_balance,
        granted_balance: info.granted_balance,
        topped_up_balance: info.topped_up_balance
      }))
      : [];
    const result = {
      ok: true,
      isAvailable: data.is_available !== false,
      balances,
      fetchedAt: Date.now()
    };
    balanceCache = { at: Date.now(), data: result };
    return result;
  } catch (e) {
    return { ok: false, error: e.name === 'AbortError' ? '余额接口超时' : `余额接口失败: ${e.message}` };
  } finally {
    clearTimeout(timer);
  }
}

async function showBalanceBubble(result) {
  if (!petPort || !petToken) return;
  const display = await petDisplay();
  if (display !== 'desktop' && display !== 'both') return;
  try {
    const r = await requestJson(`http://127.0.0.1:${petPort}${PET_ROUTE}/broadcast?pet=main&surface=desktop`, {
      method: 'POST',
      body: { text: formatBalanceShort(result), duration: 8000 },
      headers: { 'x-dsh-pet-token': petToken },
      timeout: 2000
    });
    let data = null;
    try { data = JSON.parse(r.body || '{}'); } catch { /* ignore */ }
    const failed = r.status < 200 || r.status >= 300 || (data && data.ok === false);
    if (failed) {
      const reason = data && (data.reason || data.message || data.error);
      log(`balance bubble failed: ${r.status} ${reason || String(r.body || '').slice(0, 120)}`);
    } else {
      log('balance bubble shown');
    }
  } catch (e) {
    log('balance bubble error: ' + e.message);
  }
}

function parsePetPort(chunk) {
  const match = /127\.0\.0\.1:(\d+)\/dsh-pet-7340/.exec(String(chunk || ''));
  if (!match) return;
  const port = Number(match[1]);
  if (Number.isInteger(port) && port > 0) petPort = port;
}

function readPetRuntime() {
  try {
    const data = JSON.parse(fs.readFileSync(PET_RUNTIME_FILE, 'utf8'));
    return data && typeof data === 'object' ? data : null;
  } catch { return null; }
}

async function attachPetRuntime(expectedPid) {
  for (let i = 0; i < 20; i += 1) {
    const runtime = readPetRuntime();
    if (runtime && runtime.token && (!expectedPid || runtime.pid === expectedPid)) {
      if (runtime.port) petPort = runtime.port;
      petToken = runtime.token;
      return true;
    }
    await sleep(100);
  }
  log('pet runtime token not found');
  return false;
}

// 先把状态记下来并立即返回，转发给桌宠放到串行队列里做，避免网络慢时拖住 hook。
function queueState(state, task) {
  const clean = task ? String(task).slice(0, 60) : null;
  lastState = { state, task: clean, at: Date.now() };
  const run = () => pushState(state, clean);
  stateQueue = stateQueue.then(run, run).catch(() => {});
  return stateQueue;
}

async function pushState(state, task) {
  if (!petPort) return { ok: false, reason: 'pet-not-running' };
  if (!petToken) return { ok: false, reason: 'pet-token-missing' };
  const url = `http://127.0.0.1:${petPort}${PET_ROUTE}/work-status`;
  const headers = { 'x-dsh-pet-token': petToken };
  try {
    if (state === 'clear') {
      const r = await requestJson(url, { method: 'DELETE', timeout: 1200, headers });
      if (r.status >= 200 && r.status < 300) {
        return { ok: true, state: 'clear' };
      }
      return { ok: false, reason: `pet-http-${r.status}` };
    }
    const payload = { state };
    if (task) payload.task = String(task).slice(0, 60);
    const r = await requestJson(url, { method: 'POST', body: payload, timeout: 1200, headers });
    if (r.status >= 200 && r.status < 300) {
      return { ok: true, state, task: payload.task || null };
    }
    return { ok: false, reason: `pet-http-${r.status}` };
  } catch (e) {
    return { ok: false, reason: e.message };
  }
}

function killTree(pid) {
  try {
    spawnSync('taskkill', ['/PID', String(pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
  } catch { /* ignore */ }
}

async function stopPet() {
  const proc = petProc;
  const port = petPort;
  const token = petToken;
  petProc = null;
  petPort = null;
  petToken = null;
  if (proc && proc.pid) {
    killTree(proc.pid);
    await sleep(300);
    log(`pet stopped (pid ${proc.pid})`);
  } else if (port) {
    try {
      await requestJson(`http://127.0.0.1:${port}/shutdown`, {
        method: 'POST',
        timeout: 1200,
        headers: token ? { 'x-dsh-pet-token': token } : {}
      });
    } catch { /* ignore */ }
    log(`pet stop requested on port ${port}`);
  }
  return { running: false };
}

async function startPet() {
  if (petProc && petProc.exitCode !== null) { petProc = null; petPort = null; }
  if (petProc) return petStatus();
  if (petStarting) return petStarting;

  petStarting = (async () => {
    // 已经有人手动开了一只 dsh-pet 时直接接管，不再开第二只。
    for (let p = PET_PORT_START; p < PET_PORT_START + PET_PORT_TRIES; p += 1) {
      if (await petHealth(p)) {
        const runtime = readPetRuntime();
        if (!runtime || runtime.port !== p || !runtime.token) {
          log(`existing dsh-pet on port ${p} has no usable runtime token; starting a fresh one`);
          continue;
        }
        petPort = p;
        petToken = runtime.token;
        log(`adopted existing dsh-pet on port ${p}`);
        if (lastState && lastState.state !== 'clear' && Date.now() - lastState.at < 10 * 60e3) {
          await pushState(lastState.state, lastState.task);
        }
        return petStatus();
      }
    }

    const port = await findFreePort(PET_PORT_START, PET_PORT_TRIES);
    petPort = port;
    let stderr = '';
    const env = { ...process.env, DSH_PET_ELECTRON_PATH: ELECTRON_EXE, DSH_HOME, DSH_PET_NO_TRAY: '1' };
    delete env.ELECTRON_RUN_AS_NODE;

    log(`starting dsh-pet on port ${port}`);
    const child = spawn(process.execPath, [PET_SCRIPT, '--port', String(port)], {
      cwd: PET_PKG_DIR,
      env,
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true
    });
    petProc = child;
    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    child.stdout.on('data', chunk => {
      parsePetPort(chunk);
      log('[pet] ' + chunk.trim());
    });
    child.stderr.on('data', chunk => {
      stderr = (stderr + chunk).slice(-4000);
      log('[pet:err] ' + chunk.trim());
    });
    child.on('exit', (code, signal) => {
      log(`pet exited code=${code} signal=${signal}`);
      if (petProc === child) { petProc = null; petPort = null; petToken = null; }
    });

    const deadline = Date.now() + 30000;
    while (Date.now() < deadline) {
      if (child.exitCode !== null) {
        petProc = null;
        petPort = null;
        petToken = null;
        throw new Error('桌宠进程提前退出: ' + (stderr.trim() || `code ${child.exitCode}`));
      }
      if (await petHealth(petPort)) {
        log(`pet ready on port ${petPort}`);
        await attachPetRuntime(child.pid);
        if (lastState && lastState.state !== 'clear' && Date.now() - lastState.at < 10 * 60e3) {
          await pushState(lastState.state, lastState.task);
        }
        return petStatus();
      }
      await sleep(300);
    }
    if (child.pid) killTree(child.pid);
    petProc = null;
    petPort = null;
    throw new Error('桌宠启动超时');
  })().finally(() => { petStarting = null; });

  return petStarting;
}

function cleanupRuntimeFile() {
  try {
    const raw = JSON.parse(fs.readFileSync(RUNTIME_FILE, 'utf8'));
    if (raw.pid === process.pid) fs.unlinkSync(RUNTIME_FILE);
  } catch { /* ignore */ }
}

async function shutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  await stopPet().catch(() => {});
  cleanupRuntimeFile();
  try { server.close(); } catch { /* ignore */ }
  setTimeout(() => process.exit(0), 80);
}

const server = http.createServer(async (req, res) => {
  applyCors(req, res);
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  let url;
  try { url = new URL(req.url, 'http://127.0.0.1'); } catch { sendJson(res, { error: 'bad url' }, 400); return; }

  try {
    if (url.pathname === '/api/health' && req.method === 'GET') {
      return sendJson(res, { ok: true, app: APP_NAME, pid: process.pid, port: serverPort, pet: petStatus() });
    }

    if (url.pathname === '/api/pet/status' && req.method === 'GET') {
      const alive = await petHealth(petPort);
      if (!alive && !petProc) petPort = null;
      const display = alive ? await petDisplay() : null;
      const visible = !!(alive && (display === 'desktop' || display === 'both'));
      return sendJson(res, { ok: true, ...petStatus(), running: alive, display, visible });
    }

    if (url.pathname === '/api/pet/toggle' && req.method === 'POST') {
      if (petStarting) await petStarting.catch(() => {});
      const alive = await petHealth(petPort);
      if (alive) {
        const display = await petDisplay();
        if (display === 'desktop' || display === 'both') {
          await stopPet();
          return sendJson(res, { ok: true, running: false, visible: false, display: null });
        }
        // 进程在跑但被隐藏（display=none/web）：这一次点击应该是“叫出来”。
        const shown = await setPetDisplay('desktop');
        if (!shown.ok) {
          return sendJson(res, {
            ok: false,
            error: '桌宠已启动但显示失败: ' + shown.reason,
            running: true,
            visible: false
          }, 502);
        }
        return sendJson(res, { ok: true, running: true, visible: true, display: 'desktop' });
      }
      const status = await startPet();
      // 配置本来就是桌面显示时不要再写一次，否则会多触发一次 helper 重启（启动闪烁）
      const current = await petDisplay();
      if (current !== 'desktop' && current !== 'both') {
        const shown = await setPetDisplay('desktop');
        if (!shown.ok) {
          return sendJson(res, {
            ok: false,
            error: '桌宠已启动但显示失败: ' + shown.reason,
            running: true,
            visible: false
          }, 502);
        }
      }
      return sendJson(res, { ok: true, running: true, visible: true, display: 'desktop', ...status });
    }

    // 显式显示：已经开着就确保桌面显示，没开就拉起来；不做“切换”语义，避免并发时把桌宠关掉
    if (url.pathname === '/api/pet/show' && req.method === 'POST') {
      if (petStarting) await petStarting.catch(() => {});
      try {
        const alive = await petHealth(petPort);
        if (!alive) await startPet();
      } catch (e) {
        return sendJson(res, { ok: false, error: e.message }, 502);
      }
      const current = await petDisplay();
      if (current !== 'desktop' && current !== 'both') {
        const shown = await setPetDisplay('desktop');
        if (!shown.ok) {
          return sendJson(res, {
            ok: false,
            error: '桌宠已启动但显示失败: ' + shown.reason,
            running: true,
            visible: false
          }, 502);
        }
      }
      return sendJson(res, { ok: true, running: true, visible: true, display: 'desktop', ...petStatus() });
    }

    // 只停桌宠，sidecar 继续隐藏待命。
    // 默认只在“客户端已经不在了”时停：桌面客户端关窗口收进托盘时也会调这里，
    // 那时 claude-gui 服务还活着，桌宠应该继续留着。
    // 真正退出（托盘「退出」）由客户端带 ?force=1 调用。
    if (url.pathname === '/api/pet/stop' && req.method === 'POST') {
      const force = url.searchParams.get('force') === '1';
      if (!force && await findClaudeGui()) {
        return sendJson(res, { ok: true, running: petStatus().running, ignored: 'client-alive' });
      }
      if (petStarting) await petStarting.catch(() => {});
      await stopPet();
      return sendJson(res, { ok: true, running: false, visible: false });
    }

    // Claude Code 的 HTTP hook：零进程启动，body 是原始 hook 事件。
    // 读完 body 立刻回 204，转发桌宠放进串行队列，不拖慢工具调用。
    if (url.pathname.startsWith('/api/hook/') && req.method === 'POST') {
      const event = decodeURIComponent(url.pathname.slice('/api/hook/'.length));
      const head = await readHookBody(req);
      if (HOOK_EVENTS.has(event)) {
        const payload = {
          tool_name: jsonStringField(head, 'tool_name'),
          notification_type: jsonStringField(head, 'notification_type') || jsonStringField(head, 'type'),
          stop_hook_active: jsonBoolField(head, 'stop_hook_active')
        };
        const state = decideHookState(event, payload);
        if (state) {
          const task = payload.tool_name
            ? (HOOK_TOOL_LABEL[payload.tool_name] || String(payload.tool_name))
            : undefined;
          queueState(state, task);
        }
      }
      res.writeHead(204);
      res.end();
      return;
    }

    if (url.pathname === '/api/state' && req.method === 'POST') {
      const body = await readBody(req);
      const state = body && body.state;
      const task = body && body.task;
      if (state !== 'clear' && !WORK_STATES.has(state)) {
        return sendJson(res, { error: 'invalid state' }, 400);
      }
      if (task !== undefined && typeof task !== 'string') {
        return sendJson(res, { error: 'invalid task' }, 400);
      }
      queueState(state, task);
      return sendJson(res, { ok: true, queued: true, pet: petStatus() });
    }

    if (url.pathname === '/api/balance' && req.method === 'GET') {
      const force = url.searchParams.get('refresh') === '1';
      const result = await fetchBalance(force);
      if (!result.ok) return sendJson(res, result, 502);
      // 气泡和档位动画分开：客户端服务器的余额代理会带 bubble=0（避免重复气泡），
      // 但用户手动刷新（refresh=1）仍应触发桌宠的余额档位动画。
      if (url.searchParams.get('bubble') !== '0') showBalanceBubble(result);
      if (url.searchParams.get('refresh') === '1') showBalanceTierAnimation(result);
      return sendJson(res, result);
    }

    if (url.pathname === '/api/shutdown' && req.method === 'POST') {
      sendJson(res, { ok: true });
      setTimeout(() => { shutdown(); }, 50);
      return;
    }

    sendJson(res, { error: 'not found' }, 404);
  } catch (e) {
    log('api error:', e.message);
    if (!res.headersSent) sendJson(res, { error: e.message }, 500);
    else res.end();
  }
});

// sidecar 每次启动时先按当前 dsh-pet 版本重打一次集成补丁。
// 这样即使客户端用的是旧更新器（1.2.2 及以前没有安装后补丁步骤），
// 更新到新包后新 sidecar 启动也能把 helper 补丁补上；脚本本身幂等。
function applyPetPatchOnStartup() {
  const bridge = path.join(__dirname, 'patch-dsh-pet.js');
  const pkgJson = path.join(PET_PKG_DIR, 'package.json');
  if (!fs.existsSync(bridge) || !fs.existsSync(pkgJson)) return;
  try {
    const r = spawnSync(process.execPath, [bridge], { windowsHide: true, stdio: 'ignore', timeout: 20000 });
    if (r.error) log('pet patch error: ' + r.error.message);
    else if (r.status !== 0) log('pet patch failed: exit ' + r.status);
    else log('pet patch applied/verified');
  } catch (e) {
    log('pet patch error: ' + e.message);
  }
}

async function main() {
  applyPetPatchOnStartup();
  const existing = await findExistingSidecar();
  if (existing) {
    log(`sidecar already running on port ${existing}; exit`);
    return;
  }

  const port = await findFreePort(BASE_PORT, PORT_TRIES);
  serverPort = port;
  server.listen(port, '127.0.0.1', () => {
    fs.mkdirSync(RUNTIME_DIR, { recursive: true });
    fs.writeFileSync(RUNTIME_FILE, JSON.stringify({ app: APP_NAME, port, pid: process.pid }, null, 2));
    log(`sidecar listening on 127.0.0.1:${port}`);
    startClientWatch();
  });
  server.on('error', err => log('server error:', err.message));
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
process.on('exit', () => {
  if (petProc && petProc.pid) killTree(petProc.pid);
  cleanupRuntimeFile();
});
process.on('uncaughtException', err => log('uncaught:', err.stack || err.message));
process.on('unhandledRejection', err => log('unhandled:', err && err.stack || String(err)));

main().catch(err => {
  log('startup failed:', err.message);
  process.exit(1);
});
