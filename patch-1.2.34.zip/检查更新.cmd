@echo off
chcp 65001 >nul
cd /d "%~dp0"

set "PS=powershell.exe"
where pwsh.exe >nul 2>nul && set "PS=pwsh.exe"

"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\check-update.ps1" -InstallDir "%~dp0"
if errorlevel 1 (
  echo.
  echo 更新没有完成，请把上面的信息发给分享者。
  pause
)
