'use strict';

// The CLI and its Playwright server share one process. Use the same context
// and target IDs as the bundled Chromium adapter, including empty contexts.
function chromiumContext(context) {
  const impl = context._connection.toImpl?.(context);
  if (impl?._browser.options.name !== 'chromium' || !impl._browser._session)
    throw new Error('This command requires the workbench Chromium CDP connection.');
  return impl;
}

async function createWindow(context) {
  const impl = chromiumContext(context);
  const session = impl._browser._session;
  const created = session.send('Target.createTarget', {
    url: 'about:blank',
    browserContextId: impl._browserContextId,
    newWindow: true,
    background: true
  });
  // Concurrent tabs and popups can arrive before the createTarget reply.
  const ownPage = context.waitForEvent('page', {
    predicate: async page => {
      const { targetId } = await created;
      if (page.isClosed())
        return false;
      try {
        return page._connection.toImpl(page).delegate._targetId === targetId;
      } catch {
        // A short-lived popup may already have lost its dispatcher.
        return false;
      }
    },
    timeout: 10000
  });
  try {
    const [, page] = await Promise.all([created, ownPage]);
    return page;
  } catch (error) {
    // If Chrome accepted the request but the page never attached, remove only
    // the target created by this call. Don't hold an error response indefinitely.
    void created.then(({ targetId }) => session.send('Target.closeTarget', { targetId })).catch(() => {});
    throw error;
  }
}

// One extra CDP session per opted-in default-profile page. Detaching releases
// its visibility override. Closing the target or the daemon also detaches it.
const renderSessions = new WeakMap();
const renderOperations = new WeakMap();

async function changeRendering(page, mode) {
  const existing = renderSessions.get(page);
  if (mode === 'on' && !existing) {
    const session = await page.context().newCDPSession(page);
    try {
      await session.send('Emulation.setFocusEmulationEnabled', { enabled: true });
    } catch (error) {
      await session.detach().catch(() => {});
      throw error;
    }
    renderSessions.set(page, session);
    session.once('close', () => {
      if (renderSessions.get(page) === session)
        renderSessions.delete(page);
    });
  }
  if (mode === 'off' && existing) {
    await existing.detach();
    renderSessions.delete(page);
  }
  return { rendering: mode, managedBy: 'workbench' };
}

async function setRendering(page, mode) {
  if (mode !== 'on' && mode !== 'off')
    throw new Error('Expected tab-render on or tab-render off.');
  const impl = chromiumContext(page.context());
  if (!impl._browser.options.noDefaults || impl._browser._defaultContext !== impl)
    return { rendering: 'on', managedBy: 'playwright' };
  const pending = renderOperations.get(page) || Promise.resolve();
  const operation = pending.catch(() => {}).then(() => changeRendering(page, mode));
  renderOperations.set(page, operation);
  return operation.finally(() => {
    if (renderOperations.get(page) === operation)
      renderOperations.delete(page);
  });
}

function isRendering(page) {
  return renderSessions.has(page) || renderOperations.has(page);
}

module.exports = { createWindow, isRendering, setRendering };
