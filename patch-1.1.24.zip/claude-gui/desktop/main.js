'use strict';

/**
 * Claude Code 工作台 —— 桌面客户端
 *
 * 启动时先找已经在跑的本地服务；没有就自己拉起一个（用 Electron 自带的 Node 运行
 * ../server.js），然后开一个原生窗口加载界面。关掉窗口时，如果是自己拉起的服务，
 * 会一并结束后台进程。
 */

const { app, BrowserWindow, Menu, shell, nativeTheme, dialog, ipcMain, Tray, nativeImage, Notification } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const http = require('http');
const { spawn } = require('child_process');

const APP_DIR = __dirname;
const CLIENT_DIR = path.join(APP_DIR, '..');
const APP_ROOT = path.join(APP_DIR, '..', '..');
const SERVER_JS = path.join(CLIENT_DIR, 'server.js');
const ICON = path.join(APP_DIR, 'icon.ico');
const TRAY_ICON = process.platform === 'win32' ? ICON : path.join(APP_DIR, 'icon.png');
const BASE_PORT = Number(process.env.WORKBENCH_PORT || 4711);
const PORT_TRIES = 24;

// 快捷方式可以直接启动 electron.exe（不再经过 cmd 窗口）。这样启动时缺少
// 启动脚本设置的环境变量，所以在这里补齐安装包自带的运行时目录。
(function setupBundledEnv() {
  const extra = [
    path.join(process.env.USERPROFILE || '', '.local', 'bin'),
    path.join(APP_ROOT, 'runtime'),
    path.join(APP_ROOT, 'git', 'cmd')
  ].filter(p => p && fs.existsSync(p));

  const current = (process.env.PATH || '').split(';').filter(Boolean);
  const missing = extra.filter(p => !current.some(x => x.toLowerCase() === p.toLowerCase()));
  if (missing.length) process.env.PATH = missing.concat(current).join(';');

  const bash = path.join(APP_ROOT, 'git', 'bin', 'bash.exe');
  if (fs.existsSync(bash)) process.env.CLAUDE_CODE_GIT_BASH_PATH = bash;
})();

// 桌宠 sidecar（E:\AI_Claude\dsh-pet\bridge\sidecar.js）：由客户端负责拉起；
// 关窗口收进托盘时桌宠不收起，只有托盘退出时才结束。
const PET_DIR = process.env.DSH_PET_DIR || path.join(APP_ROOT, 'dsh-pet');
const PET_SIDECAR = path.join(PET_DIR, 'bridge', 'sidecar.js');
const PET_NODE = path.join(PET_DIR, 'runtime', 'node.exe');
const PET_PORT_START = 4780;
const PET_PORT_TRIES = 10;

let serverChild = null;
let serverOwned = false;
let mainWindow = null;
let baseUrl = null;
let tray = null;
let hasRunningTask = false;
let isQuitting = false;
let quitPrompting = false;
let trayHintShown = false;

// 任务栏/托盘角标与通知
const ICON_PNG = path.join(APP_DIR, 'icon.png');
let attentionCount = 0;
let attentionSummary = '';
let badgeWindow = null;
let attentionQueue = Promise.resolve();
const badgeCache = new Map();
const liveNotifications = new Set();

// 桌宠生命周期状态
let petSidecarPort = null;
let petWanted = true;          // 上次退出时桌宠是否开着；下次启动自动恢复
let petQueue = Promise.resolve();

const sleep = ms => new Promise(r => setTimeout(r, ms));

// ------------------------------------------------------------ 本地服务

function ping(port) {
  return new Promise(resolve => {
    const req = http.get({ host: '127.0.0.1', port, path: '/api/ping', timeout: 600 }, res => {
      let body = '';
      res.on('data', d => { body += d; });
      res.on('end', () => {
        try { resolve(JSON.parse(body).app === 'claude-gui'); } catch { resolve(false); }
      });
    });
    req.on('error', () => resolve(false));
    req.on('timeout', () => { req.destroy(); resolve(false); });
  });
}

async function findServer() {
  for (let p = BASE_PORT; p < BASE_PORT + PORT_TRIES; p++) {
    if (await ping(p)) return p;
  }
  return null;
}

async function ensureServer() {
  const existing = await findServer();
  if (existing) return { port: existing, owned: false };

  serverChild = spawn(process.execPath, [SERVER_JS], {
    cwd: path.join(APP_DIR, '..'),
    env: {
      ...process.env,
      ELECTRON_RUN_AS_NODE: '1',
      NO_OPEN: '1',
      PORT: String(BASE_PORT)
    },
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true
  });
  serverOwned = true;

  serverChild.stdout.on('data', d => process.stdout.write('[server] ' + d.toString()));
  serverChild.stderr.on('data', d => process.stderr.write('[server] ' + d.toString()));
  serverChild.on('error', err => console.error('[server] 启动出错：', err.message));

  const deadline = Date.now() + 25000;
  while (Date.now() < deadline) {
    await sleep(250);
    if (serverChild.exitCode !== null) {
      throw new Error('本地服务启动失败，请检查 Node 环境或端口占用');
    }
    const p = await findServer();
    if (p) return { port: p, owned: true };
  }
  throw new Error('本地服务启动超时');
}

function stopServer() {
  if (!serverOwned || !serverChild) return;
  try { serverChild.kill(); } catch { /* ignore */ }
  serverChild = null;
  serverOwned = false;
}

// ------------------------------------------------------------ 桌宠 sidecar

function petStatePath() {
  return path.join(app.getPath('userData'), 'pet-state.json');
}

function loadPetWanted() {
  try {
    const s = JSON.parse(fs.readFileSync(petStatePath(), 'utf8'));
    if (s && typeof s.wanted === 'boolean') petWanted = s.wanted;
  } catch { /* 首次运行，默认开着 */ }
}

function savePetWanted() {
  try {
    fs.mkdirSync(path.dirname(petStatePath()), { recursive: true });
    fs.writeFileSync(petStatePath(), JSON.stringify({ wanted: !!petWanted }, null, 2), 'utf8');
  } catch { /* ignore */ }
}

/** 访问 sidecar 的 JSON 接口 */
function petHttp(port, pathname, options = {}, timeout = 1500) {
  return new Promise((resolve, reject) => {
    const body = options.body === undefined ? null : Buffer.from(JSON.stringify(options.body));
    const req = http.request({
      hostname: '127.0.0.1',
      port,
      path: pathname,
      method: options.method || 'GET',
      headers: body
        ? { 'content-type': 'application/json', 'content-length': body.length }
        : undefined,
      timeout
    }, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        let data = null;
        try { data = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { /* ignore */ }
        resolve({ status: res.statusCode, data });
      });
    });
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

async function findPetSidecar() {
  if (petSidecarPort) {
    try {
      const r = await petHttp(petSidecarPort, '/api/health', {}, 350);
      if (r.data && r.data.app === 'dsh-pet-bridge') return petSidecarPort;
    } catch { /* 端口可能已换 */ }
    petSidecarPort = null;
  }
  for (let p = PET_PORT_START; p < PET_PORT_START + PET_PORT_TRIES; p += 1) {
    try {
      const r = await petHttp(p, '/api/health', {}, 350);
      if (r.data && r.data.app === 'dsh-pet-bridge') {
        petSidecarPort = p;
        return p;
      }
    } catch { /* 试下一个 */ }
  }
  return null;
}

/** 客户端启动时确保 sidecar 在跑；这样不管从 cmd、桌面快捷方式还是任务栏打开都能用桌宠按钮 */
async function ensurePetSidecar() {
  if (await findPetSidecar()) return true;
  if (!fs.existsSync(PET_SIDECAR) || !fs.existsSync(PET_NODE)) return false;

  const env = { ...process.env };
  delete env.ELECTRON_RUN_AS_NODE;   // Electron 给 server 设过这个变量，sidecar 是纯 Node
  try {
    const child = spawn(PET_NODE, [PET_SIDECAR], {
      cwd: path.join(PET_DIR, 'bridge'),
      env,
      detached: true,
      stdio: 'ignore',
      windowsHide: true
    });
    child.unref();
  } catch (e) {
    console.error('[pet] sidecar 启动失败：', e.message);
    return false;
  }

  for (let i = 0; i < 25; i += 1) {
    await sleep(200);
    if (await findPetSidecar()) return true;
  }
  console.error('[pet] sidecar 启动超时');
  return false;
}

async function petStatus() {
  const port = await findPetSidecar();
  if (!port) return null;
  try {
    const r = await petHttp(port, '/api/pet/status', {}, 1500);
    return r.status === 200 && r.data && r.data.ok !== false ? r.data : null;
  } catch {
    return null;
  }
}

async function petShow() {
  const port = await findPetSidecar();
  if (!port) return false;
  try {
    const r = await petHttp(port, '/api/pet/show', { method: 'POST' }, 20000);
    return r.status >= 200 && r.status < 300 && r.data && r.data.ok !== false;
  } catch {
    return false;
  }
}

async function petStopNow(force = false) {
  const port = await findPetSidecar();
  if (!port) return false;
  try {
    const path = force ? '/api/pet/stop?force=1' : '/api/pet/stop';
    const r = await petHttp(port, path, { method: 'POST' }, 4000);
    return r.status >= 200 && r.status < 300;
  } catch {
    return false;
  }
}

/** 串行执行，避免“快速关窗再开窗”时 stop 和 show 交错 */
function queuePet(fn) {
  petQueue = petQueue.then(fn).catch(e => console.error('[pet]', e.message));
  return petQueue;
}

/** 退出时记录桌宠开关状态并立刻结束桌宠，不等 sidecar 的 5 秒轮询 */
async function settlePetOnQuit() {
  const st = await petStatus();
  if (st) petWanted = !!st.running;
  savePetWanted();
  if (st && st.running) await petStopNow(true);
}

/** 启动时恢复上次的桌宠开关（默认开着）。等窗口真正显示出来再开桌宠。 */
async function restorePetOnLaunch() {
  for (let i = 0; i < 40 && !isQuitting; i += 1) {
    if (mainWindow && mainWindow.isVisible()) break;
    await sleep(150);
  }
  if (!petWanted || isQuitting) return;
  if (!mainWindow || !mainWindow.isVisible()) return;
  const st = await petStatus();
  if (!st || (st.running && st.visible)) return;
  await petShow();
}

// ------------------------------------------------------------ 窗口状态

function statePath() {
  return path.join(app.getPath('userData'), 'window-state.json');
}

function loadWindowState() {
  try {
    const s = JSON.parse(fs.readFileSync(statePath(), 'utf8'));
    if (s && typeof s.width === 'number' && typeof s.height === 'number') return s;
  } catch { /* ignore */ }
  return null;
}

function saveWindowState() {
  if (!mainWindow) return;
  try {
    const b = mainWindow.getBounds();
    fs.mkdirSync(path.dirname(statePath()), { recursive: true });
    fs.writeFileSync(statePath(), JSON.stringify({
      x: b.x, y: b.y, width: b.width, height: b.height,
      maximized: mainWindow.isMaximized()
    }), 'utf8');
  } catch { /* ignore */ }
}

// ------------------------------------------------------------ 菜单

function buildMenu() {
  const template = [
    {
      label: '文件',
      submenu: [
        { label: '重新加载', accelerator: 'CmdOrCtrl+R', role: 'reload' },
        { type: 'separator' },
        { role: 'quit', label: '退出' }
      ]
    },
    {
      label: '编辑',
      submenu: [
        { role: 'undo', label: '撤销' },
        { role: 'redo', label: '重做' },
        { type: 'separator' },
        { role: 'cut', label: '剪切' },
        { role: 'copy', label: '复制' },
        { role: 'paste', label: '粘贴' },
        { role: 'selectAll', label: '全选' }
      ]
    },
    {
      label: '视图',
      submenu: [
        { role: 'forceReload', label: '强制重新加载' },
        { role: 'toggleDevTools', label: '开发者工具', accelerator: 'CmdOrCtrl+Shift+I' },
        { type: 'separator' },
        { role: 'resetZoom', label: '实际大小' },
        { role: 'zoomIn', label: '放大' },
        { role: 'zoomOut', label: '缩小' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: '全屏' }
      ]
    },
    {
      label: '帮助',
      submenu: [
        {
          label: '关于',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: '关于',
              message: 'Claude Code 工作台',
              detail: `桌面客户端 v${app.getVersion()}\n界面服务：${baseUrl || '未启动'}\n\n会话记录与终端里的 claude --resume 共用。`,
              buttons: ['好']
            });
          }
        }
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ------------------------------------------------------------ 编辑命令

// 输入框右键菜单 → 原生编辑命令，保留系统剪贴板行为（包括粘贴截图）
ipcMain.on('gui:edit', (event, cmd) => {
  const wc = event.sender;
  if (cmd === 'cut') wc.cut();
  else if (cmd === 'copy') wc.copy();
  else if (cmd === 'paste') wc.paste();
  else if (cmd === 'selectAll') wc.selectAll();
});

// ------------------------------------------------------------ 系统托盘

ipcMain.on('gui:busy', (event, busy) => {
  hasRunningTask = !!busy;
  updateTrayMenu();
});

function ensureTray() {
  if (tray) return;
  try {
    tray = new Tray(TRAY_ICON);
  } catch (e) {
    console.error('[tray] 创建失败：', e.message);
    return;
  }
  tray.on('click', showMainWindow);
  tray.on('double-click', showMainWindow);
  updateTrayMenu();
  if (attentionCount > 0) queueAttentionUpdate(attentionCount, attentionSummary);
}

const AUTO_START_NAME = 'ClaudeCodeWorkbench';

function autoStartOptions(extra = {}) {
  const opts = { name: AUTO_START_NAME, ...extra };
  if (!app.isPackaged) {
    opts.path = process.execPath;
    opts.args = [app.getAppPath()];
  }
  return opts;
}

function getAutoStart() {
  if (process.platform !== 'win32' && process.platform !== 'darwin') return false;
  try {
    const s = app.getLoginItemSettings(autoStartOptions());
    if (process.platform === 'win32') {
      return !!(s.launchItems || []).some(item =>
        item && item.name === AUTO_START_NAME && item.enabled !== false
      );
    }
    return !!s.openAtLogin;
  } catch {
    return false;
  }
}

function setAutoStart(enabled) {
  if (process.platform !== 'win32' && process.platform !== 'darwin') return false;
  try {
    app.setLoginItemSettings(autoStartOptions({ openAtLogin: !!enabled }));
    return getAutoStart() === !!enabled;
  } catch (e) {
    console.error('[autostart]', e.message);
    return false;
  }
}

function updateTrayMenu() {
  if (!tray) return;
  const tip = attentionCount > 0
    ? `Claude Code 工作台 · ${attentionCount} 个对话需要处理`
    : (hasRunningTask ? 'Claude Code 工作台 · 任务运行中' : 'Claude Code 工作台');
  tray.setToolTip(tip);
  const items = [
    { label: '显示工作台', click: showMainWindow }
  ];
  if (attentionCount > 0) {
    const detail = attentionSummary ? ` · ${attentionSummary}` : '';
    items.push({ label: `${attentionCount} 个对话需要处理${detail}`.slice(0, 120), enabled: false });
  }
  const canAutoStart = process.platform === 'win32' || process.platform === 'darwin';
  items.push(
    { label: hasRunningTask ? '任务运行中…' : '当前没有运行中的任务', enabled: false },
    { type: 'separator' },
    {
      label: '开机自启',
      type: 'checkbox',
      checked: canAutoStart && getAutoStart(),
      enabled: canAutoStart,
      click: item => {
        if (!canAutoStart) return;
        if (!setAutoStart(item.checked)) {
          item.checked = !item.checked;
          try {
            dialog.showErrorBox('开机自启设置失败', '系统没有接受这个设置，请检查权限或安全软件。');
          } catch { /* ignore */ }
        }
        updateTrayMenu();
      }
    },
    { label: '退出', click: requestQuit }
  );
  tray.setContextMenu(Menu.buildFromTemplate(items));
}

function showMainWindow() {
  if (!mainWindow) return;
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
}

// ------------------------------------------------------------ 任务栏/托盘角标

let baseIconB64 = null;

function badgeLabel(n) {
  return n > 9 ? '9+' : String(n);
}

async function ensureBadgeWindow() {
  if (badgeWindow && !badgeWindow.isDestroyed()) return badgeWindow;
  badgeWindow = new BrowserWindow({
    width: 64,
    height: 64,
    show: false,
    frame: false,
    transparent: true,
    skipTaskbar: true,
    focusable: false,
    resizable: false,
    webPreferences: { offscreen: true, sandbox: true, contextIsolation: true, nodeIntegration: false }
  });
  await badgeWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(
    '<!doctype html><html><body style="margin:0;background:transparent"><canvas id="c" width="64" height="64"></canvas></body></html>'
  ));
  return badgeWindow;
}

async function renderBadgePng(label, withBase) {
  const win = await ensureBadgeWindow();
  if (!baseIconB64) {
    try { baseIconB64 = fs.readFileSync(ICON_PNG).toString('base64'); } catch { baseIconB64 = ''; }
  }
  const script = `(async () => {
    const c = document.getElementById('c');
    const g = c.getContext('2d');
    g.clearRect(0, 0, 64, 64);
    ${withBase && baseIconB64 ? `
    const img = new Image();
    await new Promise((resolve) => { img.onload = resolve; img.onerror = resolve; img.src = 'data:image/png;base64,${baseIconB64}'; });
    if (img.width) g.drawImage(img, 0, 0, 64, 64);
    ` : ''}
    const text = ${JSON.stringify(label)};
    const big = ${withBase ? 'false' : 'true'};
    const cx = big ? 32 : 42;
    const cy = big ? 32 : 42;
    const r = big ? 25 : 21;
    g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2);
    g.fillStyle = '#e0533f'; g.fill();
    g.lineWidth = big ? 3 : 4; g.strokeStyle = 'rgba(11,13,16,.92)'; g.stroke();
    g.fillStyle = '#ffffff';
    g.textAlign = 'center'; g.textBaseline = 'middle';
    const size = text.length > 1 ? (big ? 21 : 17) : (big ? 30 : 25);
    g.font = 'bold ' + size + 'px "Segoe UI", "Microsoft YaHei UI", sans-serif';
    g.fillText(text, cx, cy + 1);
    return c.toDataURL('image/png');
  })()`;
  return win.webContents.executeJavaScript(script, true);
}

async function getBadgeImage(key, label, withBase) {
  if (badgeCache.has(key)) return badgeCache.get(key);
  const dataUrl = await renderBadgePng(label, withBase);
  const img = nativeImage.createFromDataURL(dataUrl);
  badgeCache.set(key, img);
  return img;
}

async function applyTrayBadge() {
  if (!tray) return;
  if (attentionCount > 0) {
    const label = badgeLabel(attentionCount);
    const img = await getBadgeImage('tray:' + label, label, true);
    tray.setImage(img);
    tray.setToolTip(`Claude Code 工作台 · ${attentionCount} 个对话需要处理`);
  } else {
    tray.setImage(TRAY_ICON);
    tray.setToolTip(hasRunningTask ? 'Claude Code 工作台 · 任务运行中' : 'Claude Code 工作台');
  }
}

function queueAttentionUpdate(count, summary) {
  attentionCount = count;
  attentionSummary = summary;
  console.log('[attention]', count, summary);
  attentionQueue = attentionQueue.then(async () => {
    const label = badgeLabel(attentionCount);
    if (mainWindow && !mainWindow.isDestroyed()) {
      if (attentionCount > 0) {
        const img = await getBadgeImage('overlay:' + label, label, false);
        mainWindow.setOverlayIcon(img, `${attentionCount} 个对话需要处理`);
      } else {
        mainWindow.setOverlayIcon(null, '');
      }
    }
    await applyTrayBadge();
    updateTrayMenu();
  }).catch(e => console.error('[attention]', e.message));
}

ipcMain.on('gui:attention', (event, data) => {
  const count = Math.max(0, Math.min(99, Math.floor(Number(data && data.count) || 0)));
  const summary = String((data && data.summary) || '').slice(0, 200);
  if (count === attentionCount && summary === attentionSummary) return;
  queueAttentionUpdate(count, summary);
});

ipcMain.on('gui:notify', (event, data) => {
  if (!Notification.isSupported()) return;
  const title = String((data && data.title) || 'Claude Code 工作台').slice(0, 80);
  const body = String((data && data.body) || '').slice(0, 300);
  const convId = data && typeof data.convId === 'string' ? data.convId : '';
  try {
    const n = new Notification({ title, body, icon: ICON_PNG });
    liveNotifications.add(n);
    const drop = () => liveNotifications.delete(n);
    n.on('click', () => {
      drop();
      showMainWindow();
      if (convId && mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('gui:open-conv', convId);
      }
    });
    n.on('close', drop);
    n.on('failed', drop);
    n.show();
    console.log('[notify]', title);
  } catch (e) {
    console.error('[notify]', e.message);
  }
});

// ------------------------------------------------------------ 应用内一键更新

ipcMain.handle('gui:start-update', async (event, data) => {
  if (isQuitting) return { ok: false, error: '客户端正在退出' };

  const manifestUrl = String((data && data.manifestUrl) || '').trim();
  const version = String((data && data.version) || '').trim().slice(0, 40);
  const notes = String((data && data.notes) || '').trim();
  // 新版界面已经用自定义小窗展示版本简介并确认过，不再重复弹系统确认框。
  const confirmed = !!(data && data.confirmed);
  if (!manifestUrl) return { ok: false, error: '还没有配置更新地址' };
  if (!/^(https?|file):\/\//i.test(manifestUrl) && !path.isAbsolute(manifestUrl)) {
    return { ok: false, error: '更新地址无效' };
  }

  const updaterCandidates = [
    path.join(APP_ROOT, 'tools', 'check-update.ps1'),
    // 开发目录里没有 tools\check-update.ps1 时，用 deploy 下的同名脚本
    path.join(APP_ROOT, 'deploy', 'update', 'check-update.ps1')
  ];
  let updater = '';
  for (const p of updaterCandidates) {
    try { if (fs.existsSync(p)) { updater = p; break; } } catch { }
  }
  if (!updater) return { ok: false, error: '找不到更新脚本，请用最新安装包补装一次' };

  if (!confirmed) {
    const title = version ? `发现新版本 v${version}` : '发现新版本';
    const detailParts = [];
    if (notes) detailParts.push(notes.slice(0, 3000));
    if (hasRunningTask) detailParts.push('当前有任务正在运行，继续更新会中断该任务。');
    detailParts.push('更新期间会打开一个更新窗口，请不要关闭它。');
    detailParts.push('更新会关闭工作台，完成后自动重新打开。');
    const dialogOpts = {
      type: 'info',
      title: 'Claude 工作台更新',
      message: title,
      detail: detailParts.join('\n\n'),
      buttons: ['立即更新', '稍后'],
      defaultId: 0,
      cancelId: 1,
      noLink: true
    };
    let response = 1;
    try {
      const r = (mainWindow && !mainWindow.isDestroyed())
        ? await dialog.showMessageBox(mainWindow, dialogOpts)
        : await dialog.showMessageBox(dialogOpts);
      response = r.response;
    } catch { response = 1; }
    if (response !== 0) return { ok: false, cancelled: true };
  }

  // 更新脚本里会 taskkill /T 关闭工作台。用一个临时 .cmd 交给系统外壳启动，
  // 让更新进程挂在 Explorer 下、不在 Electron 的进程树里，才能活到更新结束。
  const ps = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  const quote = s => "'" + String(s).replace(/'/g, "''") + "'";
  const tempDir = path.join(os.tmpdir(), 'ClaudeWorkbenchUpdate-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8));
  const launchPs1 = path.join(tempDir, 'launch.ps1');
  const launchCmd = path.join(tempDir, 'launch.cmd');
  try {
    fs.mkdirSync(tempDir, { recursive: true });
    fs.writeFileSync(launchPs1, '\ufeff' + [
      '$env:WORKBENCH_UPDATE_MANIFEST = ' + quote(manifestUrl),
      '& ' + quote(ps) + ' -NoProfile -ExecutionPolicy Bypass -File ' + quote(updater) + ' -InstallDir ' + quote(APP_ROOT) + ' -Yes -NoSuccessInfo',
      ''
    ].join('\r\n'), 'utf8');
    fs.writeFileSync(launchCmd, [
      '@echo off',
      'title Claude Workbench Update',
      'chcp 65001 >nul',
      '"' + ps + '" -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch.ps1"',
      ''
    ].join('\r\n'), 'ascii');
  } catch (e) {
    return { ok: false, error: '准备更新启动器失败：' + e.message };
  }
  const openErr = await shell.openPath(launchCmd);
  if (openErr) return { ok: false, error: '启动更新失败：' + openErr };

  isQuitting = true;
  setTimeout(() => {
    try { stopServer(); } catch { }
    app.quit();
  }, 800);
  return { ok: true };
});

// 输入框引用选择：图片/文件和文件夹分成两个原生对话框
ipcMain.handle('gui:pick-reference', async (event, kind) => {
  const parent = BrowserWindow.fromWebContents(event.sender) || mainWindow;
  const folderMode = kind === 'folder';
  const options = {
    title: folderMode ? '引用文件夹' : '引用图片/文件',
    properties: folderMode
      ? ['openDirectory', 'multiSelections']
      : ['openFile', 'multiSelections']
  };
  // 原生按钮无法随选中项动态改字：文件对话框用一个同时说明两种行为的静态标签，
  // 文件夹对话框仍然只写「引用」。
  options.buttonLabel = folderMode ? '引用文件夹' : '打开文件夹/引用';
  const result = parent
    ? await dialog.showOpenDialog(parent, options)
    : await dialog.showOpenDialog(options);
  if (result.canceled) return { canceled: true, items: [] };

  if (folderMode) {
    return {
      canceled: false,
      items: (result.filePaths || []).map(file => ({
        path: file,
        name: path.basename(file),
        isDir: true,
        isImage: false,
        mime: '',
        dataUrl: ''
      }))
    };
  }

  const IMAGE_MIME = {
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
    '.gif': 'image/gif'
  };
  const items = (result.filePaths || []).map(file => {
    let isImage = false;
    let mime = '';
    let dataUrl = '';
    try {
      const stat = fs.statSync(file);
      const ext = path.extname(file).toLowerCase();
      const imageMime = IMAGE_MIME[ext];
      if (stat.isFile() && imageMime && stat.size <= 20 * 1024 * 1024) {
        mime = imageMime;
        dataUrl = 'data:' + imageMime + ';base64,' + fs.readFileSync(file).toString('base64');
        isImage = true;
      }
    } catch { /* 读不到就按普通文件引用 */ }
    return { path: file, name: path.basename(file), isDir: false, isImage, mime, dataUrl };
  });
  return { canceled: false, items };
});

// Chrome 不在默认路径时，让用户直接选择安装目录（Application 或上层目录都可以）。
ipcMain.handle('gui:pick-chrome', async event => {
  const parent = BrowserWindow.fromWebContents(event.sender) || mainWindow;
  const options = {
    title: '选择 Chrome 安装目录',
    properties: ['openDirectory'],
    buttonLabel: '选择此目录'
  };
  const result = parent
    ? await dialog.showOpenDialog(parent, options)
    : await dialog.showOpenDialog(options);
  if (result.canceled || !result.filePaths || !result.filePaths[0]) {
    return { canceled: true, dir: '', path: '' };
  }

  const dir = result.filePaths[0];
  const candidates = [
    path.join(dir, 'chrome.exe'),
    path.join(dir, 'Application', 'chrome.exe'),
    path.join(dir, 'chrome-win64', 'chrome.exe'),
    path.join(dir, 'chrome-win32', 'chrome.exe')
  ];
  const chromeExe = candidates.find(file => {
    try { return fs.statSync(file).isFile(); } catch { return false; }
  }) || '';
  return {
    canceled: false,
    dir,
    path: chromeExe,
    error: chromeExe ? '' : '这个目录里没有 chrome.exe，请选择 Chrome 的 Application 目录'
  };
});

async function requestQuit() {
  if (isQuitting || quitPrompting) return;

  if (hasRunningTask) {
    quitPrompting = true;
    let response = 0;
    try {
      ({ response } = await dialog.showMessageBox({
        type: 'warning',
        title: '退出 Claude Code 工作台',
        message: '还有任务正在运行',
        detail: serverOwned
          ? '退出客户端会停止本地服务，正在运行的任务会被中断。'
          : '本地服务由其他窗口启动；退出客户端不会停止任务，但界面会断开。',
        buttons: ['继续运行', '仍然退出'],
        defaultId: 0,
        cancelId: 0,
        noLink: true
      }));
    } catch {
      response = 0;
    } finally {
      quitPrompting = false;
    }
    if (response !== 1) return;
  }

  isQuitting = true;
  try { await settlePetOnQuit(); } catch { /* ignore */ }
  app.quit();
}

// ------------------------------------------------------------ 窗口

function createWindow(port) {
  const state = loadWindowState();

  const win = new BrowserWindow({
    width: state ? Math.max(state.width, 920) : 1280,
    height: state ? Math.max(state.height, 620) : 860,
    x: state ? state.x : undefined,
    y: state ? state.y : undefined,
    minWidth: 920,
    minHeight: 620,
    show: false,
    title: 'Claude Code 工作台',
    icon: ICON,
    backgroundColor: '#0b0d10',
    darkTheme: true,
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      preload: path.join(APP_DIR, 'preload.js'),
      spellcheck: false
    }
  });

  baseUrl = `http://127.0.0.1:${port}/`;

  win.loadURL(baseUrl);

  win.once('ready-to-show', () => {
    if (state && state.maximized) win.maximize();
    win.show();

    // 仅用于开发时截图验证
    if (process.env.CAPTURE_PATH) {
      setTimeout(async () => {
        try {
          const img = await win.webContents.capturePage();
          fs.writeFileSync(process.env.CAPTURE_PATH, img.toPNG());
          console.log('[capture] saved', process.env.CAPTURE_PATH);
        } catch (e) {
          console.error('[capture] failed', e.message);
        }
        app.quit();
      }, 2500);
    }
  });

  // 桌宠不跟窗口显隐：关窗口收进托盘时桌宠继续留在桌面上，
  // 只有托盘「退出」或用户点鱼形按钮时才结束/切换桌宠。
  win.on('close', e => {
    saveWindowState();
    if (isQuitting) return;

    ensureTray();
    if (!tray) {
      // 托盘创建失败时退回普通退出流程（有任务会先确认）
      e.preventDefault();
      requestQuit();
      return;
    }

    // 关闭窗口只收进托盘，任务继续在后台运行
    e.preventDefault();
    win.hide();
    if (!trayHintShown) {
      trayHintShown = true;
      try {
        if (tray && typeof tray.displayBalloon === 'function') {
          tray.displayBalloon({
            title: 'Claude Code 工作台',
            content: hasRunningTask
              ? '任务在后台继续运行，可从系统托盘重新打开。'
              : '已最小化到系统托盘，可从托盘重新打开。'
          });
        }
      } catch { /* ignore */ }
    }
  });

  // 外部链接交给系统浏览器，应用内不允许被导航走
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith(baseUrl)) return { action: 'allow' };
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });

  win.webContents.on('will-navigate', (e, url) => {
    if (baseUrl && !url.startsWith(baseUrl)) {
      e.preventDefault();
      if (/^https?:/i.test(url)) shell.openExternal(url);
    }
  });

  return win;
}

// ------------------------------------------------------------ 生命周期

const gotLock = app.requestSingleInstanceLock();

if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show();
      mainWindow.focus();
    }
  });

  app.whenReady().then(async () => {
    nativeTheme.themeSource = 'dark';
    if (process.platform === 'win32') app.setAppUserModelId('com.local.claudeworkbench.orange');

    buildMenu();
    loadPetWanted();

    try {
      const { port } = await ensureServer();
      mainWindow = createWindow(port);
      mainWindow.on('closed', () => { mainWindow = null; });
      ensureTray();

      // 不管客户端从哪里启动，都自己把桌宠 sidecar 拉起来；上次开着的话自动恢复桌宠
      ensurePetSidecar()
        .then(ok => { if (ok) return queuePet(restorePetOnLaunch); })
        .catch(e => console.error('[pet]', e.message));
    } catch (err) {
      dialog.showErrorBox('Claude Code 工作台启动失败', String(err && err.message ? err.message : err));
      app.quit();
    }
  });

  // 关闭窗口后留在托盘，不退出应用
  app.on('window-all-closed', () => {});

  app.on('before-quit', e => {
    if (isQuitting) { stopServer(); return; }
    e.preventDefault();
    requestQuit();
  });

  app.on('will-quit', () => {
    if (tray) { tray.destroy(); tray = null; }
  });

  process.on('exit', stopServer);
  process.on('SIGINT', () => { stopServer(); process.exit(0); });
}
